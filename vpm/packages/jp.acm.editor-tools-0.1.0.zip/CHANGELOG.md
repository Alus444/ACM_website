# Changelog

## [0.1.0] - 2026-08-30

- Added the initial VPM package containing the ACM Editor tools.
- Included Vail as source code in the same package.
- Added migration handling for the legacy `Assets/ACM/Editor` installation.
