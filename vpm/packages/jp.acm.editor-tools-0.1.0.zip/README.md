# ACM Editor Tools

ACM Editor Tools は、Unity 2022.3向けのEditor拡張集です。VCCまたはALCOMからVPMパッケージとして導入できます。

## 収録ツール

- Editor Manager
- Align Selected Objects
- Active Object Editor
- Animation Root Rebinder
- Assets Pack Tool
- Cleanup Hidden Objects
- Dimension Overlay
- Folder Tabs
- Multibyte Character Destroyer
- Prefab Product Info
- Sync Folder
- Toggle Active Checkbox in Hierarchy
- Vail

各ツールは主に `Tools/ACM` メニューから開けます。Vailの詳しい操作は `Editor/Vail/Manual.md` を参照してください。

設定や生成物はパッケージ本体ではなく、必要に応じてプロジェクトの `Assets/ACM/Data`、`Assets/ACM/Export`、または `Library/ACM` に保存されます。パッケージを更新または削除しても、ユーザーが作成したデータは自動削除されません。

旧版を `Assets/ACM/Editor` に直接配置している場合、VPM版の初回インストール時に旧フォルダーが移行対象として削除されます。必要な独自変更がある場合は、インストール前に退避してください。

## English

ACM Editor Tools is a collection of Unity Editor extensions for Unity 2022.3. It can be installed as a VPM package through VCC or ALCOM.

Open the tools mainly from the `Tools/ACM` menu. See `Editor/Vail/Manual.md` for detailed Vail instructions.

Settings and generated assets are stored outside the package when required, under `Assets/ACM/Data`, `Assets/ACM/Export`, or `Library/ACM`. Updating or removing the package does not automatically delete user-created data.

When migrating from a legacy copy under `Assets/ACM/Editor`, VPM removes that legacy folder during the first installation. Back up any local modifications before installing the package.
