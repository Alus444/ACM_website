using System;
using System.Collections.Generic;
using UnityEngine;

namespace ACM
{
    [CreateAssetMenu(menuName = "ACM/Assets Pack/AssetsPack Preset", fileName = "AssetsPackPreset")]
    public sealed class AssetsPackPreset : ScriptableObject
    {
        public enum OutputRootMode
        {
            Preset,
            Auto,
            RuntimePick
        }

        public OutputRootMode outputRootMode = OutputRootMode.Preset;
        public enum DependencyMode
        {
            Off,
            IncludeMove,
            DuplicateCopy
        }

        [Serializable]
        public sealed class Rule
        {
            public string name = "Textures";
            public string outputSubFolder = "Textures";
            public List<string> extensions = new List<string> { ".png", ".jpg" };
        }

        [Header("Output")]
        public string outputRoot = "Assets/ACM_Pack";

        [Header("Auto Root")]
        public bool autoPreferPrefabFolder = true; // デフォルトON
        public List<string> autoExcludeFolders = new List<string> { "Assets/Temp", "Assets/_Work" };

        [Header("Rules")]
        public List<Rule> rules = new List<Rule>();

        [Header("Unmatched")]
        public bool moveUnmatchedToUncategorized = true;
        public string uncategorizedSubFolder = "Uncategorized";

        [Header("Dependencies")]
        public DependencyMode dependencyMode = DependencyMode.Off;

        [Header("Warnings")]
        public bool showWarnings = true;

        [Header("Blacklist (No-touch)")]
        public List<string> blacklistPathContains = new List<string>();

        public string ResolveCategorySubFolder(string assetPath)
        {
            string ext = System.IO.Path.GetExtension(assetPath);
            if (string.IsNullOrEmpty(ext))
                ext = "";

            ext = ext.ToLowerInvariant();

            foreach (var r in rules)
            {
                if (r == null) continue;
                if (r.extensions == null) continue;

                for (int i = 0; i < r.extensions.Count; i++)
                {
                    var e = r.extensions[i];
                    if (string.IsNullOrEmpty(e)) continue;
                    var ee = e.StartsWith(".") ? e.ToLowerInvariant() : ("." + e.ToLowerInvariant());
                    if (ext == ee)
                        return string.IsNullOrEmpty(r.outputSubFolder) ? r.name : r.outputSubFolder;
                }
            }

            return moveUnmatchedToUncategorized ? uncategorizedSubFolder : null;
        }

        public bool IsBlacklisted(string assetPath)
        {
            if (blacklistPathContains == null || blacklistPathContains.Count == 0) return false;
            for (int i = 0; i < blacklistPathContains.Count; i++)
            {
                var k = blacklistPathContains[i];
                if (string.IsNullOrEmpty(k)) continue;
                if (assetPath.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0)
                    return true;
            }
            return false;
        }
    }
}