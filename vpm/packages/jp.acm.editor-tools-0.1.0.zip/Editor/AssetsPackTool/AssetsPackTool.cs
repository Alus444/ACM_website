using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ACM
{
    public sealed class AssetsPackTool : EditorWindow
    {
        private const string PresetFolder = "Assets/ACM/Data";
        private const string WindowTitle = "AssetsPackTool";
        private const string LastPresetGuidKey = "ACM.AssetsPackTool.LastPresetGuid";

        [SerializeField] private AssetsPackPreset currentPreset;
        [SerializeField] private Vector2 scroll;

        [SerializeField] private string presetNameEdit = "";

        [MenuItem("Tools/ACM/AssetsPack/AssetsPackTool")]
        public static void OpenWindow()
        {
            var w = GetWindow<AssetsPackTool>();
            w.titleContent = new GUIContent(WindowTitle);
            w.minSize = new Vector2(520, 520);
            w.Show();
        }

        [MenuItem("Assets/ACM/AssetsPack/実行(Auto)", priority = 2200)]
        private static void RunAutoFromContext()
        {
            var preset = LoadLastOrFirstPreset();
            if (preset == null)
            {
                EditorUtility.DisplayDialog("AssetsPackTool", "プリセットが見つかりませんでした。プリセットを作成してください。", "OK");
                return;
            }

            RunWithMode(preset, RunMode.Auto);
        }

        [MenuItem("Assets/ACM/AssetsPack/実行(実行時パス指定)", priority = 2201)]
        private static void RunRuntimePathFromContext()
        {
            var preset = LoadLastOrFirstPreset();
            if (preset == null)
            {
                EditorUtility.DisplayDialog("AssetsPackTool", "プリセットが見つかりませんでした。プリセットを作成してください。", "OK");
                return;
            }

            RunWithMode(preset, RunMode.RuntimePickRoot);
        }

        [MenuItem("Assets/ACM/AssetsPack/プリセットから実行", priority = 2300)]
        private static void RunPresetPickFromContext()
        {
            var presets = FindAllPresets();
            if (presets.Count == 0)
            {
                EditorUtility.DisplayDialog("AssetsPackTool", "プリセットが見つかりませんでした。", "OK");
                return;
            }

            EditorApplication.delayCall += () =>
            {
                PresetPickerWindow.Open("プリセットから実行", presets, p =>
                {
                    SaveLastPresetGuid(p);
                    RunWithMode(p, ToRunMode(p.outputRootMode));
                });
            };
        }

        private void OnEnable()
        {
            if (currentPreset == null)
                currentPreset = LoadLastOrFirstPreset();

            if (currentPreset != null)
                presetNameEdit = currentPreset.name;
        }

        private void OnGUI()
        {
            EditorGUILayout.Space(6);

            using (new EditorGUILayout.HorizontalScope())
            {
                currentPreset = (AssetsPackPreset)EditorGUILayout.ObjectField("Preset", currentPreset, typeof(AssetsPackPreset), false);

                using (new EditorGUI.DisabledScope(currentPreset == null))
                {
                    if (GUILayout.Button("Save", GUILayout.Width(60)))
                    {
                        EditorUtility.SetDirty(currentPreset);
                        AssetDatabase.SaveAssets();
                        AssetDatabase.Refresh();
                        SaveLastPresetGuid(currentPreset);
                    }
                }
                if (GUILayout.Button("Find", GUILayout.Width(60)))
                {
                    var presets = FindAllPresets();
                    if (presets.Count == 0)
                    {
                        EditorUtility.DisplayDialog("AssetsPackTool", "プリセットが見つかりませんでした。プリセットを作成してください。", "OK");
                    }
                    else
                    {
                        ShowPresetMenu("プリセットを選択", presets, p =>
                        {
                            currentPreset = p;
                            SaveLastPresetGuid(currentPreset);
                            EditorGUIUtility.PingObject(currentPreset);
                        });
                    }
                }

                if (GUILayout.Button("新規作成", GUILayout.Width(80)))
                {
                    EnsurePresetFolder();
                    var name = EditorUtility.SaveFilePanelInProject("プリセットを作成します", "AssetsPackPreset", "asset", "プリセット名を入力してください。", PresetFolder);

                    if (string.IsNullOrEmpty(name)) return;

                    var path = name;
                    var preset = CreateInstance<AssetsPackPreset>();
                    InitDefaultPreset(preset);
                    AssetDatabase.CreateAsset(preset, path);
                    AssetDatabase.SaveAssets();
                    currentPreset = preset;
                    SaveLastPresetGuid(currentPreset);
                    EditorGUIUtility.PingObject(currentPreset);
                }
            }

            if (currentPreset == null)
            {
                EditorGUILayout.HelpBox("プリセットが未指定です。\"新規作成\" または ObjectField から指定してください。", MessageType.Info);
                DrawPresetImportExport(null);
                DrawDynamicPresetHint();
                return;
            }

            if (currentPreset != null)
            {
                if (string.IsNullOrEmpty(presetNameEdit))
                    presetNameEdit = currentPreset.name;

                using (new EditorGUILayout.HorizontalScope())
                {
                    presetNameEdit = EditorGUILayout.TextField("Preset Name", presetNameEdit);

                    using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(presetNameEdit)))
                    {
                        if (GUILayout.Button("Rename", GUILayout.Width(80)))
                        {
                            RenamePresetAsset(currentPreset, presetNameEdit);
                            presetNameEdit = currentPreset != null ? currentPreset.name : presetNameEdit;
                        }
                    }
                }
            }

            SaveLastPresetGuid(currentPreset);

            EditorGUILayout.Space(8);
            DrawPresetCore(currentPreset);

            EditorGUILayout.Space(10);
            DrawPresetImportExport(currentPreset);

            EditorGUILayout.Space(10);
            DrawManualRunButtons(currentPreset);

            EditorGUILayout.Space(10);
            DrawDynamicPresetHint();
        }

        private static RunMode ToRunMode(AssetsPackPreset.OutputRootMode m)
        {
            return m switch
            {
                AssetsPackPreset.OutputRootMode.Auto => RunMode.Auto,
                AssetsPackPreset.OutputRootMode.RuntimePick => RunMode.RuntimePickRoot,
                _ => RunMode.PresetRoot
            };
        }

        private static void DrawDynamicPresetHint()
        {
            EditorGUILayout.HelpBox(
                "Projectウィンドウでアセットを選択し、右クリック → ACM → Assets Pack から実行できます。",
                MessageType.None);
        }

        private void DrawPresetCore(AssetsPackPreset preset)
        {
            using (var sv = new EditorGUILayout.ScrollViewScope(scroll, GUILayout.Height(380)))
            {
                scroll = sv.scrollPosition;

                EditorGUI.BeginChangeCheck();

                EditorGUILayout.LabelField("Output", EditorStyles.boldLabel);
                preset.outputRootMode = (AssetsPackPreset.OutputRootMode)EditorGUILayout.EnumPopup("Root Mode", preset.outputRootMode);
                preset.outputRoot = EditorGUILayout.TextField("Output Root", preset.outputRoot);

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Auto Root", EditorStyles.boldLabel);
                preset.autoPreferPrefabFolder = EditorGUILayout.ToggleLeft("Auto時、Prefabが含まれる場合はPrefabの場所だけで収集位置を判定します", preset.autoPreferPrefabFolder);

                DrawStringList("Auto Exclude Folders", preset.autoExcludeFolders, "例: Assets/Temp");

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Rules", EditorStyles.boldLabel);

                if (preset.rules == null) preset.rules = new List<AssetsPackPreset.Rule>();
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("ルール追加", GUILayout.Width(90)))
                        preset.rules.Add(new AssetsPackPreset.Rule());

                    if (GUILayout.Button("デフォルト例を追加", GUILayout.Width(120)))
                        AddDefaultRules(preset);
                }

                for (int i = 0; i < preset.rules.Count; i++)
                {
                    var r = preset.rules[i];
                    if (r == null) { preset.rules[i] = new AssetsPackPreset.Rule(); r = preset.rules[i]; }

                    EditorGUILayout.Space(6);
                    using (new EditorGUILayout.VerticalScope("box"))
                    {
                        using (new EditorGUILayout.HorizontalScope())
                        {
                            r.name = EditorGUILayout.TextField("Category Name", r.name);
                            if (GUILayout.Button("削除", GUILayout.Width(60)))
                            {
                                preset.rules.RemoveAt(i);
                                break;
                            }
                        }
                        r.outputSubFolder = EditorGUILayout.TextField("Folder Name", r.outputSubFolder);
                        DrawStringList("Extensions", r.extensions, "例: .png");
                    }
                }

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Unmatched", EditorStyles.boldLabel);
                preset.moveUnmatchedToUncategorized = EditorGUILayout.ToggleLeft("未分類はUncategorizedへ送ります", preset.moveUnmatchedToUncategorized);
                using (new EditorGUI.DisabledScope(!preset.moveUnmatchedToUncategorized))
                    preset.uncategorizedSubFolder = EditorGUILayout.TextField("Uncategorized Sub Folder", preset.uncategorizedSubFolder);

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Dependencies", EditorStyles.boldLabel);
                preset.dependencyMode = (AssetsPackPreset.DependencyMode)EditorGUILayout.EnumPopup("Mode", preset.dependencyMode);

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Warnings", EditorStyles.boldLabel);
                preset.showWarnings = EditorGUILayout.ToggleLeft("警告と確認を表示します", preset.showWarnings);

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Blacklist", EditorStyles.boldLabel);
                DrawStringList("Path Contains", preset.blacklistPathContains, "指定した名前がパスに含まれる場合、その直下のファイルには何もしません");

                if (EditorGUI.EndChangeCheck())
                    EditorUtility.SetDirty(preset);
            }
        }

        private static void DrawManualRunButtons(AssetsPackPreset preset)
        {
            EditorGUILayout.LabelField("Run", EditorStyles.boldLabel);

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("選択からプレビュー(Auto)"))
                    RunWithMode(preset, RunMode.Auto);

                if (GUILayout.Button("選択からプレビュー(実行時パス指定)"))
                    RunWithMode(preset, RunMode.RuntimePickRoot);

                if (GUILayout.Button("選択からプレビュー(Preset)"))
                    RunWithMode(preset, RunMode.PresetRoot);
            }
        }

        private static void DrawPresetImportExport(AssetsPackPreset preset)
        {
            EditorGUILayout.LabelField("Preset Share", EditorStyles.boldLabel);

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(preset == null))
                {
                    if (GUILayout.Button("エクスポート(JSON)", GUILayout.Width(170)))
                    {
                        var defaultName = (preset != null ? preset.name : "AssetsPackPreset") + ".json";
                        var save = EditorUtility.SaveFilePanel("プリセットを書き出します", "", defaultName, "json");
                        if (!string.IsNullOrEmpty(save))
                        {
                            var json = JsonUtility.ToJson(preset, true);
                            File.WriteAllText(save, json, System.Text.Encoding.UTF8);
                            AssetDatabase.Refresh();
                        }
                    }
                }

                if (GUILayout.Button("インポート(JSON)", GUILayout.Width(170)))
                {
                    var open = EditorUtility.OpenFilePanel("プリセットを読み込みます", "", "json");
                    if (!string.IsNullOrEmpty(open))
                    {
                        EnsurePresetFolder();

                        var json = File.ReadAllText(open, System.Text.Encoding.UTF8);
                        var name = Path.GetFileNameWithoutExtension(open);
                        if (string.IsNullOrEmpty(name)) name = "AssetsPackPreset";

                        var assetPath = AssetDatabase.GenerateUniqueAssetPath($"{PresetFolder}/{name}.asset");
                        var presetNew = CreateInstance<AssetsPackPreset>();
                        InitDefaultPreset(presetNew);

                        JsonUtility.FromJsonOverwrite(json, presetNew);

                        AssetDatabase.CreateAsset(presetNew, assetPath);
                        AssetDatabase.SaveAssets();
                        AssetDatabase.Refresh();

                        SaveLastPresetGuid(presetNew);

                        var w = GetWindow<AssetsPackTool>();
                        w.currentPreset = presetNew;
                        EditorGUIUtility.PingObject(presetNew);
                    }
                }
            }

            EditorGUILayout.HelpBox("プリセットは Assets/ACM/Data に置く運用を想定しています。", MessageType.None);
        }

        private enum RunMode
        {
            Auto,
            RuntimePickRoot,
            PresetRoot
        }

        private sealed class PlanItem
        {
            public string assetPath;
            public string sourcePath;
            public string destPath;
            public string action;
            public string note;
            public bool isCollision;
            public bool isScript;
            public bool isPrefab;
            public bool isVariant;
            public string category;
            public bool enabled;
            public int index;
        }

        private sealed class Plan
        {
            public string modeLabel;
            public string outputRoot;
            public List<PlanItem> items = new List<PlanItem>();
            public int selectionCount;
            public int dependencyCount;
            public bool hasVariant;
            public bool duplicateEnabled;
        }

        private static void RunWithMode(AssetsPackPreset preset, RunMode mode)
        {
            if (preset == null) return;

            var selected = GatherSelectionPaths(out var selectionNotes);
            if (selected.Count == 0)
            {
                EditorUtility.DisplayDialog("AssetsPackTool", "対象が選択されていません。Projectでアセットまたはフォルダを選択してください。", "OK");
                return;
            }

            string outputRoot = preset.outputRoot;

            if (mode == RunMode.RuntimePickRoot)
            {
                var picked = EditorUtility.OpenFolderPanel("出力ルートを選択してください(Assets配下を推奨)", Application.dataPath, "");
                if (string.IsNullOrEmpty(picked))
                    return;

                var proj = Path.GetFullPath(Path.Combine(Application.dataPath, "..")).Replace('\\', '/');
                var full = Path.GetFullPath(picked).Replace('\\', '/');
                if (!full.StartsWith(proj, StringComparison.OrdinalIgnoreCase))
                {
                    EditorUtility.DisplayDialog("AssetsPackTool", "プロジェクト外のフォルダは指定できません。プロジェクト内のフォルダを選択してください。", "OK");
                    return;
                }

                var rel = full.Substring(proj.Length).TrimStart('/');
                outputRoot = rel;
            }
            else if (mode == RunMode.Auto)
            {
                outputRoot = ResolveAutoRoot(preset, selected, out var _, out var _);
                if (string.IsNullOrEmpty(outputRoot))
                    outputRoot = preset.outputRoot;
            }
            else
            {
                outputRoot = preset.outputRoot;
            }

            var plan = BuildPlan(preset, selected, selectionNotes, outputRoot, mode);
            AssetsPackPreviewWindow.Open(plan, preset);
        }

        private static Plan BuildPlan(
            AssetsPackPreset preset,
            List<string> selectedAssetPaths,
            Dictionary<string, string> selectionNotes,
            string outputRoot,
            RunMode mode)
        {
            var plan = new Plan();
            plan.outputRoot = outputRoot;
            plan.duplicateEnabled = (preset.dependencyMode == AssetsPackPreset.DependencyMode.DuplicateCopy);
            plan.modeLabel = mode switch
            {
                RunMode.Auto => "Auto",
                RunMode.RuntimePickRoot => "実行時パス指定",
                _ => "Preset"
            };

            var allTargets = new HashSet<string>(selectedAssetPaths);
            plan.selectionCount = allTargets.Count;

            if (preset.dependencyMode != AssetsPackPreset.DependencyMode.Off)
            {
                var prefabs = selectedAssetPaths.Where(IsPrefabPath).ToList();
                if (prefabs.Count > 0)
                {
                    var deps = new HashSet<string>();
                    foreach (var p in prefabs)
                    {
                        var d = AssetDatabase.GetDependencies(p, true);
                        for (int i = 0; i < d.Length; i++)
                        {
                            var dp = d[i];
                            if (string.Equals(dp, p, StringComparison.OrdinalIgnoreCase)) continue;
                            dp = NormalizeSubAssetToMain(dp);

                            if (!IsUnderAssets(dp)) continue;

                            deps.Add(dp);
                        }
                    }

                    foreach (var d in deps)
                    {
                        if (!allTargets.Contains(d))
                            allTargets.Add(d);
                    }

                    var materialPaths = deps.Where(IsMaterialPath).ToList();

                    var allowedTex = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    CollectTexturePathsFromMaterials(materialPaths, allowedTex);

                    deps.RemoveWhere(path =>
                    {
                        if (!IsTexturePath(path)) return false;
                        return !allowedTex.Contains(path);
                    });

                    plan.dependencyCount = Math.Max(0, allTargets.Count - plan.selectionCount);
                }
            }

            bool doCopy = preset.dependencyMode == AssetsPackPreset.DependencyMode.DuplicateCopy;
            string actionDefault = doCopy ? "Copy" : "Move";

            foreach (var p in allTargets)
            {
                if (AssetDatabase.IsValidFolder(p))
                    continue;

                var item = new PlanItem();
                item.sourcePath = p;
                item.assetPath = p;
                item.isPrefab = IsPrefabPath(p);
                item.isVariant = item.isPrefab && IsVariantPrefab(p);
                item.isScript = IsScriptPath(p);

                if (preset.IsBlacklisted(p))
                {
                    item.action = "Skip";
                    item.note = "ブラックリストに一致したファイルは処理しません。";
                    item.destPath = p;
                }
                else
                {
                    var sub = preset.ResolveCategorySubFolder(p);
                    if (sub == null)
                    {
                        item.action = "Skip";
                        item.category = "(Skip)";
                        item.note = "未分類の扱いが「何もしない」に設定されているため、このファイルは処理しません。";
                        item.destPath = p;
                    }
                    else
                    {
                        item.category = sub;
                        var destFolder = CombineAssetPath(outputRoot, sub);
                        var fileName = Path.GetFileName(p);
                        item.destPath = CombineAssetPath(destFolder, fileName);
                        item.action = actionDefault;

                        if (selectionNotes.TryGetValue(p, out var n) && !string.IsNullOrEmpty(n))
                            item.note = n;
                    }
                }
                item.enabled = item.action != "Skip";
                item.index = plan.items.Count;
                plan.items.Add(item);
            }

            plan.hasVariant = plan.duplicateEnabled && plan.items.Any(x => x.isVariant && x.action == "Copy");
            return plan;
        }

        private static bool IsTexturePath(string p)
        {
            var e = Path.GetExtension(p).ToLowerInvariant();
            return e == ".png" || e == ".jpg" || e == ".jpeg" || e == ".tga" || e == ".psd" || e == ".exr" || e == ".hdr" || e == ".tif" || e == ".tiff";
        }

        private static bool IsMaterialPath(string p)
        {
            return p.EndsWith(".mat", StringComparison.OrdinalIgnoreCase);
        }

        private static void CollectTexturePathsFromMaterials(IEnumerable<string> materialPaths, HashSet<string> allowedTexturePaths)
        {
            foreach (var mp in materialPaths)
            {
                var mat = AssetDatabase.LoadAssetAtPath<Material>(mp);
                if (mat == null) continue;

                var so = new SerializedObject(mat);
                var texEnvs = so.FindProperty("m_SavedProperties.m_TexEnvs");
                if (texEnvs == null || !texEnvs.isArray) continue;

                for (int i = 0; i < texEnvs.arraySize; i++)
                {
                    var env = texEnvs.GetArrayElementAtIndex(i);
                    if (env == null) continue;

                    var texProp = env.FindPropertyRelative("second.m_Texture");
                    if (texProp == null) continue;

                    var tex = texProp.objectReferenceValue as Texture;
                    if (tex == null) continue;

                    var tp = AssetDatabase.GetAssetPath(tex);
                    if (string.IsNullOrEmpty(tp)) continue;

                    allowedTexturePaths.Add(tp.Replace('\\', '/'));
                }
            }
        }

        private static bool IsUnderAssets(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath)) return false;
            assetPath = assetPath.Replace('\\', '/');
            return assetPath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase) || assetPath.Equals("Assets", StringComparison.OrdinalIgnoreCase);
        }

        private sealed class AssetsPackPreviewWindow : EditorWindow
        {
            private Plan plan;
            private AssetsPackPreset preset;
            private Vector2 scroll;

            private enum SortMode { Default, Category, Action, Path }
            private SortMode sortMode = SortMode.Category;

            public static void Open(Plan plan, AssetsPackPreset preset)
            {
                var w = CreateInstance<AssetsPackPreviewWindow>();
                w.plan = plan;
                w.preset = preset;
                w.titleContent = new GUIContent("AssetsPackTool Preview");
                w.minSize = new Vector2(760, 520);
                w.ShowUtility();
            }

            private void OnGUI()
            {
                if (plan == null || preset == null)
                {
                    EditorGUILayout.HelpBox("プレビュー情報がありません。", MessageType.Warning);
                    if (GUILayout.Button("閉じる")) Close();
                    return;
                }

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("実行内容プレビュー", EditorStyles.wordWrappedLabel);

                EditorGUILayout.Space(8);
                using (new EditorGUILayout.VerticalScope("box"))
                {
                    EditorGUILayout.LabelField("実行モード", plan.modeLabel);
                    EditorGUILayout.LabelField("出力ルート", plan.outputRoot);
                    EditorGUILayout.LabelField("依存モード", preset.dependencyMode.ToString());
                    EditorGUILayout.LabelField("対象数", $"選択: {plan.selectionCount} / 依存: {plan.dependencyCount}");
                }

                RecomputeCollisions(plan);

                using (new EditorGUILayout.VerticalScope("box"))
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.Label("ソート", GUILayout.Width(60));
                        sortMode = (SortMode)EditorGUILayout.EnumPopup(sortMode, GUILayout.Width(160));

                        GUILayout.FlexibleSpace();

                        if (GUILayout.Button("すべてON", GUILayout.Width(90)))
                        {
                            foreach (var it in plan.items) if (it.action != "Skip") it.enabled = true;
                        }
                        if (GUILayout.Button("すべてOFF", GUILayout.Width(90)))
                        {
                            foreach (var it in plan.items) it.enabled = false;
                        }
                        if (GUILayout.Button("衝突のみOFF", GUILayout.Width(110)))
                        {
                            foreach (var it in plan.items) if (it.isCollision) it.enabled = false;
                        }
                    }

                    EditorGUILayout.Space(4);
                    var enabledCount = plan.items.Count(x => x.enabled);
                    EditorGUILayout.LabelField("実行対象", $"{enabledCount} / {plan.items.Count}");
                }

                if (plan.duplicateEnabled && plan.hasVariant)
                {
                    EditorGUILayout.Space(6);
                    EditorGUILayout.HelpBox(
                        "Prefab Variantが含まれています。Variantを複製すると、参照先のベースPrefabが複製先へ自動で切り替わらない場合があります。\nその結果、アセットのパックとして自己完結しなくなる可能性があります。",
                        MessageType.Warning);
                }

                EditorGUILayout.Space(6);
                using (new EditorGUILayout.VerticalScope("box"))
                {
                    int moveCount = plan.items.Count(x => x.action == "Move");
                    int copyCount = plan.items.Count(x => x.action == "Copy");
                    int skipCount = plan.items.Count(x => x.action == "Skip");
                    int colCount = plan.items.Count(x => x.isCollision);

                    EditorGUILayout.LabelField("処理件数", $"Move: {moveCount} / Copy: {copyCount} / Skip: {skipCount}");
                    EditorGUILayout.LabelField("衝突", $"{colCount} 件");
                }

                EditorGUILayout.Space(8);
                DrawItemTable(plan);

                EditorGUILayout.Space(10);
                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("キャンセル", GUILayout.Height(26)))
                    {
                        Close();
                        return;
                    }

                    if (GUILayout.Button("実行", GUILayout.Height(26)))
                    {
                        var p = plan;
                        var pr = preset;

                        EditorApplication.delayCall += () =>
                        {
                            if (p == null || pr == null) return;
                            ConfirmAndExecute(p, pr);
                        };

                        Close();
                    }
                }
            }

            private void DrawItemTable(Plan plan)
            {
                IEnumerable<PlanItem> seq = plan.items;

                seq = sortMode switch
                {
                    SortMode.Category => seq.OrderBy(x => x.category).ThenBy(x => x.sourcePath),
                    SortMode.Action => seq.OrderBy(x => x.action).ThenBy(x => x.category).ThenBy(x => x.sourcePath),
                    SortMode.Path => seq.OrderBy(x => x.sourcePath),
                    _ => seq.OrderBy(x => x.index)
                };

                using (var sv = new EditorGUILayout.ScrollViewScope(scroll, true, true))
                {
                    scroll = sv.scrollPosition;

                    using (new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.Label("", GUILayout.Width(22));
                        GUILayout.Label("Action", GUILayout.Width(52));
                        GUILayout.Label("Category", GUILayout.Width(140));
                        GUILayout.Label("Asset", GUILayout.Width(220));
                        GUILayout.Label("From", GUILayout.Width(520));
                        GUILayout.Label("To", GUILayout.Width(520));
                        GUILayout.Label("Note", GUILayout.Width(360));
                    }

                    EditorGUILayout.Space(2);

                    foreach (var it in seq)
                    {
                        using (new EditorGUILayout.HorizontalScope("box"))
                        {
                            using (new EditorGUI.DisabledScope(it.action == "Skip"))
                            {
                                it.enabled = EditorGUILayout.Toggle(it.enabled, GUILayout.Width(22));
                            }

                            GUILayout.Label(it.action, GUILayout.Width(52));
                            GUILayout.Label(it.category ?? "", GUILayout.Width(140));
                            GUILayout.Label(Path.GetFileName(it.sourcePath), GUILayout.Width(220));

                            EditorGUILayout.SelectableLabel(it.sourcePath ?? "", EditorStyles.textField, GUILayout.Width(520), GUILayout.Height(18));
                            EditorGUILayout.SelectableLabel(it.destPath ?? "", EditorStyles.textField, GUILayout.Width(520), GUILayout.Height(18));

                            string note = it.note ?? "";
                            if (it.isCollision)
                            {
                                if (!string.IsNullOrEmpty(note)) note += " / ";
                                note += "移動先に同名ファイルが存在するため、衝突しています。";
                            }
                            EditorGUILayout.SelectableLabel(note, EditorStyles.textField, GUILayout.Width(360), GUILayout.Height(18));
                        }
                    }
                }
            }

            private static void RecomputeCollisions(Plan plan)
            {
                var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var it in plan.items)
                {
                    it.isCollision = false;
                    if (it.action == "Skip") continue;
                    if (string.IsNullOrEmpty(it.destPath)) continue;

                    if (!seen.Add(it.destPath))
                    {
                        it.isCollision = true;
                        continue;
                    }

                    if (AssetDatabase.LoadMainAssetAtPath(it.destPath) != null)
                    {
                        if (!string.Equals(it.sourcePath, it.destPath, StringComparison.OrdinalIgnoreCase))
                            it.isCollision = true;
                    }
                }
            }

            private static bool ConfirmAndExecute(Plan plan, AssetsPackPreset preset)
            {
                if (preset.showWarnings)
                {
                    if (!EditorUtility.DisplayDialog(
                            "AssetsPackTool",
                            "プレビュー内容に基づいて処理を実行します",
                            "実行",
                            "キャンセル"))
                        return false;
                }

                VariantCopyPolicy variantPolicy = VariantCopyPolicy.AllCopy;

                if (plan.duplicateEnabled && plan.hasVariant)
                {
                    int choice = EditorUtility.DisplayDialogComplex(
                        "Prefab Variantが検出されました",
                        "Prefab Variantが含まれています。\n\n" +
                        "Variantを複製すると、Variantが参照しているベースPrefabが複製先のベースPrefabに自動で切り替わらない場合があります。\n" +
                        "その結果、複製したVariantの参照先が元プロジェクト側のPrefabのまま残り、アセットのパックとして自己完結しなくなる可能性があります。\n" +
                        "この挙動はPrefabの構成によって変わるため、ツール側で完全な保証はできません。\n\n" +
                        "どの方針で複製するかを選択してください。",
                        "元のPrefabのみ複製",
                        "Prefabは複製しない",
                        "全て複製(非推奨)"
                    );

                    if (choice == 0) variantPolicy = VariantCopyPolicy.BaseOnly;
                    else if (choice == 1) variantPolicy = VariantCopyPolicy.NoPrefabs;
                    else if (choice == 2) variantPolicy = VariantCopyPolicy.AllCopy;
                    else return false;
                }

                RecomputeCollisions(plan);

                if (plan.items.Any(x => x.enabled && x.isCollision && x.isScript && x.action != "Skip"))
                {
                    EditorUtility.DisplayDialog(
                        "AssetsPackTool",
                        "スクリプト(.cs)が衝突しています。\nスクリプトはリネーム対象外のため、このまま実行できません。\n出力先を変更するか、衝突するファイルを解消してから再実行してください。",
                        "OK");
                    return false;
                }

                CollisionPolicy collisionPolicy = CollisionPolicy.None;

                if (plan.items.Any(x => x.enabled && x.isCollision && x.action != "Skip"))
                {
                    int c = EditorUtility.DisplayDialogComplex(
                        "衝突が検出されました",
                        "移動先に同名ファイルが存在するため、衝突が検出されました。\nどの方法で解決しますか？",
                        "衝突したものはスキップします",
                        "キャンセルします",
                        "衝突したものはリネームして続行します"
                    );

                    if (c == 0) collisionPolicy = CollisionPolicy.Skip;
                    else if (c == 2) collisionPolicy = CollisionPolicy.Rename;
                    else return false;
                }

                return ExecutePlan(plan, preset, variantPolicy, collisionPolicy);
            }

            private static bool ExecutePlan(Plan plan, AssetsPackPreset preset, VariantCopyPolicy variantPolicy, CollisionPolicy collisionPolicy)
            {
                AssetDatabase.Refresh();
                var folderCache = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                EnsureFolderExists(plan.outputRoot, folderCache);

                foreach (var it in plan.items)
                {
                    if (!it.enabled) continue;
                    if (it.action == "Skip") continue;
                    if (string.IsNullOrEmpty(it.destPath)) continue;

                    var folder = Path.GetDirectoryName(it.destPath)?.Replace('\\', '/');
                    if (!string.IsNullOrEmpty(folder))
                        EnsureFolderExists(folder, folderCache);
                }

                try
                {
                    AssetDatabase.StartAssetEditing();

                    foreach (var it in plan.items)
                    {
                        if (!it.enabled) continue;
                        if (it.action == "Skip") continue;

                        if (plan.duplicateEnabled && it.action == "Copy")
                        {
                            if (it.isPrefab)
                            {
                                if (variantPolicy == VariantCopyPolicy.NoPrefabs) continue;
                                if (variantPolicy == VariantCopyPolicy.BaseOnly && it.isVariant) continue;
                            }
                        }

                        string dest = it.destPath;

                        if (it.isCollision)
                        {
                            if (collisionPolicy == CollisionPolicy.Skip)
                                continue;

                            if (collisionPolicy == CollisionPolicy.Rename)
                                dest = GenerateUniquePath(dest);
                        }

                        if (string.Equals(it.sourcePath, dest, StringComparison.OrdinalIgnoreCase))
                            continue;

                        if (it.action == "Move")
                        {
                            var err = AssetDatabase.MoveAsset(it.sourcePath, dest);
                            if (!string.IsNullOrEmpty(err))
                            {
                                Debug.LogError($"AssetsPackTool: Moveに失敗しました: {it.sourcePath} -> {dest}\n{err}");
                                return false;
                            }
                        }
                        else if (it.action == "Copy")
                        {
                            if (!AssetDatabase.CopyAsset(it.sourcePath, dest))
                            {
                                Debug.LogError($"AssetsPackTool: Copyに失敗しました: {it.sourcePath} -> {dest}");
                                return false;
                            }
                        }
                    }
                }
                finally
                {
                    AssetDatabase.StopAssetEditing();
                    AssetDatabase.Refresh();
                }

                Debug.Log($"AssetsPackTool: 完了しました。出力ルート: {plan.outputRoot}");
                return true;
            }
            private enum CollisionPolicy { None, Skip, Rename }
            private enum VariantCopyPolicy { BaseOnly, NoPrefabs, AllCopy }
        }

        private static List<string> GatherSelectionPaths(out Dictionary<string, string> notes)
        {
            notes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            var guids = Selection.assetGUIDs;
            if (guids != null && guids.Length > 0)
            {
                foreach (var g in guids)
                {
                    var p = AssetDatabase.GUIDToAssetPath(g);
                    if (string.IsNullOrEmpty(p)) continue;
                    AddPathOrRecurseFolder(p, result, notes);
                }
            }
            else
            {
                var objs = Selection.objects;
                foreach (var o in objs)
                {
                    var p = AssetDatabase.GetAssetPath(o);
                    if (string.IsNullOrEmpty(p)) continue;
                    AddPathOrRecurseFolder(p, result, notes);
                }
            }

            result.RemoveWhere(x => x.EndsWith(".meta", StringComparison.OrdinalIgnoreCase));
            return result.ToList();
        }

        private static void AddPathOrRecurseFolder(string path, HashSet<string> result, Dictionary<string, string> notes)
        {
            path = NormalizeSubAssetToMain(path);

            if (AssetDatabase.IsValidFolder(path))
            {
                var found = AssetDatabase.FindAssets("", new[] { path });
                foreach (var fg in found)
                {
                    var ap = AssetDatabase.GUIDToAssetPath(fg);
                    if (string.IsNullOrEmpty(ap)) continue;

                    if (AssetDatabase.IsValidFolder(ap)) continue;

                    ap = NormalizeSubAssetToMain(ap);
                    result.Add(ap);
                }
                return;
            }

            if (!string.Equals(path, NormalizeSubAssetToMain(AssetDatabase.GetAssetPath(AssetDatabase.LoadMainAssetAtPath(path))), StringComparison.OrdinalIgnoreCase))
            {
                notes[path] = "FBX内のサブアセットが選択されたため、親アセット(FBX本体)として扱います。";
            }

            result.Add(path);
        }

        private static string NormalizeSubAssetToMain(string assetPath)
        {
            return assetPath.Replace('\\', '/');
        }

        private static bool IsPrefabPath(string path) => path.EndsWith(".prefab", StringComparison.OrdinalIgnoreCase);
        private static bool IsScriptPath(string path) => path.EndsWith(".cs", StringComparison.OrdinalIgnoreCase);

        private static bool IsVariantPrefab(string prefabPath)
        {
            var go = AssetDatabase.LoadAssetAtPath<GameObject>(prefabPath);
            var type = PrefabUtility.GetPrefabAssetType(go);
            return type == PrefabAssetType.Variant;
        }

        private static string ResolveAutoRoot(AssetsPackPreset preset, List<string> selected, out string basisNote, out List<(string folder, int count)> tops)
        {
            tops = new List<(string folder, int count)>();
            basisNote = "";

            var paths = selected;

            bool hasPrefab = paths.Any(IsPrefabPath);
            bool prefabOnly = preset.autoPreferPrefabFolder && hasPrefab;

            var candidates = new List<string>();
            foreach (var p in paths)
            {
                if (prefabOnly && !IsPrefabPath(p)) continue;

                var dir = Path.GetDirectoryName(p)?.Replace('\\', '/');
                if (string.IsNullOrEmpty(dir)) continue;
                candidates.Add(dir);
            }

            if (candidates.Count == 0)
            {
                basisNote = "Autoの判定対象が空のため、プリセットの出力ルートを使用します。";
                return preset.outputRoot;
            }

            var exclude = new HashSet<string>((preset.autoExcludeFolders ?? new List<string>()).Where(x => !string.IsNullOrEmpty(x)), StringComparer.OrdinalIgnoreCase);

            var counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var c in candidates)
            {
                counts.TryGetValue(c, out int v);
                counts[c] = v + 1;
            }

            var ordered = counts
                .OrderByDescending(kv => kv.Value)
                .ThenByDescending(kv => kv.Key.Length)
                .ToList();

            foreach (var kv in ordered.Take(3))
                tops.Add((kv.Key, kv.Value));

            foreach (var kv in ordered)
            {
                if (exclude.Contains(kv.Key))
                    continue;

                basisNote = prefabOnly
                    ? "Prefabが含まれるため、Prefabの場所のみを基準にAuto判定しました。"
                    : "選択アセット全体を基準にAuto判定しました。";

                return kv.Key;
            }

            basisNote = "Autoの候補がすべて除外フォルダに該当したため、最頻出フォルダを使用します。";
            return ordered[0].Key;
        }

        private static void EnsurePresetFolder()
        {
            if (AssetDatabase.IsValidFolder(PresetFolder)) return;

            if (!AssetDatabase.IsValidFolder("Assets/ACM"))
                AssetDatabase.CreateFolder("Assets", "ACM");
            if (!AssetDatabase.IsValidFolder("Assets/ACM/Data"))
                AssetDatabase.CreateFolder("Assets/ACM", "Data");
        }

        private static void InitDefaultPreset(AssetsPackPreset preset)
        {
            preset.outputRoot = "Assets/ACM_Pack";
            preset.autoPreferPrefabFolder = true;
            preset.dependencyMode = AssetsPackPreset.DependencyMode.Off;
            preset.showWarnings = true;
            preset.moveUnmatchedToUncategorized = true;
            preset.uncategorizedSubFolder = "Uncategorized";

            preset.rules = new List<AssetsPackPreset.Rule>();
            AddDefaultRules(preset);
        }

        private static void AddDefaultRules(AssetsPackPreset preset)
        {
            void Add(string name, string sub, params string[] ext)
            {
                var r = new AssetsPackPreset.Rule();
                r.name = name;
                r.outputSubFolder = sub;
                r.extensions = ext.Select(e => e.StartsWith(".") ? e : "." + e).ToList();
                preset.rules.Add(r);
            }

            Add("Prefabs", "Prefabs", ".prefab");
            Add("Materials", "Materials", ".mat");
            Add("Textures", "Textures", ".png", ".jpg", ".jpeg", ".tga", ".psd", ".exr", ".hdr", ".tif", ".tiff");
            Add("Model", "Model", ".fbx", ".obj");
            Add("Animation", "Animation", ".anim", ".controller", ".overridecontroller", ".mask");
            Add("Shader", "Shader", ".shader", ".shadergraph", ".hlsl", ".cginc");
            Add("Audio", "Audio", ".wav", ".mp3", ".ogg");
            Add("Scene", "Scene", ".unity");
            Add("Script", "Script", ".cs", ".asmdef", ".asmref");
            Add("Doc", "Doc", ".md", ".txt", ".pdf");
        }

        private static void DrawStringList(string label, List<string> list, string hint)
        {
            if (list == null) return;

            EditorGUILayout.LabelField(label);

            using (new EditorGUILayout.VerticalScope("box"))
            {
                for (int i = 0; i < list.Count; i++)
                {
                    using (new EditorGUILayout.HorizontalScope())
                    {
                        list[i] = EditorGUILayout.TextField(list[i]);
                        if (GUILayout.Button("×", GUILayout.Width(22)))
                        {
                            list.RemoveAt(i);
                            break;
                        }
                    }
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("追加", GUILayout.Width(60)))
                        list.Add("");

                    GUILayout.Label(hint, EditorStyles.miniLabel);
                }
            }
        }

        private static AssetsPackPreset LoadLastOrFirstPreset()
        {
            EnsurePresetFolder();

            var lastGuid = EditorPrefs.GetString(LastPresetGuidKey, "");
            if (!string.IsNullOrEmpty(lastGuid))
            {
                var path = AssetDatabase.GUIDToAssetPath(lastGuid);
                var p = AssetDatabase.LoadAssetAtPath<AssetsPackPreset>(path);
                if (p != null) return p;
            }

            var presets = FindAllPresets();
            if (presets.Count > 0) return presets[0];
            return null;
        }

        private static void SaveLastPresetGuid(AssetsPackPreset preset)
        {
            if (preset == null) return;
            var path = AssetDatabase.GetAssetPath(preset);
            var guid = AssetDatabase.AssetPathToGUID(path);
            EditorPrefs.SetString(LastPresetGuidKey, guid);
        }

        private static List<AssetsPackPreset> FindAllPresets()
        {
            var guids = AssetDatabase.FindAssets("t:AssetsPackPreset");
            var list = new List<AssetsPackPreset>(guids.Length);
            foreach (var g in guids)
            {
                var p = AssetDatabase.GUIDToAssetPath(g);
                var obj = AssetDatabase.LoadAssetAtPath<AssetsPackPreset>(p);
                if (obj != null) list.Add(obj);
            }

            list.Sort((a, b) =>
            {
                var pa = AssetDatabase.GetAssetPath(a);
                var pb = AssetDatabase.GetAssetPath(b);
                int c = string.Compare(pa, pb, StringComparison.OrdinalIgnoreCase);
                if (c != 0) return c;
                return string.Compare(a.name, b.name, StringComparison.OrdinalIgnoreCase);
            });

            return list;
        }

        private static void ShowPresetMenu(string title, List<AssetsPackPreset> presets, Action<AssetsPackPreset> onPick)
        {
            var menu = new GenericMenu();

            menu.AddDisabledItem(new GUIContent(title));
            menu.AddSeparator("");

            foreach (var p in presets)
            {
                if (p == null) continue;
                menu.AddItem(new GUIContent(p.name), false, () => onPick?.Invoke(p));
            }

            menu.ShowAsContext();
        }

        private static void EnsureFolderExists(string folderPath, HashSet<string> folderCache)
        {
            if (string.IsNullOrEmpty(folderPath)) return;

            folderPath = folderPath.Replace('\\', '/').TrimEnd('/');
            if (folderCache != null && folderCache.Contains(folderPath)) return;

            if (AssetDatabase.IsValidFolder(folderPath))
            {
                folderCache?.Add(folderPath);
                return;
            }

            var parts = folderPath.Split('/');
            if (parts.Length == 0) return;

            string current = parts[0];
            if (folderCache != null) folderCache.Add(current);

            for (int i = 1; i < parts.Length; i++)
            {
                var next = current + "/" + parts[i];

                if (folderCache != null && folderCache.Contains(next))
                {
                    current = next;
                    continue;
                }

                if (!AssetDatabase.IsValidFolder(next))
                {
                    AssetDatabase.CreateFolder(current, parts[i]);
                }

                folderCache?.Add(next);
                current = next;
            }
        }

        private static string CombineAssetPath(string a, string b)
        {
            a = (a ?? "").Replace('\\', '/').TrimEnd('/');
            b = (b ?? "").Replace('\\', '/').TrimStart('/');
            return string.IsNullOrEmpty(a) ? b : (a + "/" + b);
        }

        private static string GenerateUniquePath(string destPath)
        {
            destPath = destPath.Replace('\\', '/');
            var dir = Path.GetDirectoryName(destPath)?.Replace('\\', '/');
            var name = Path.GetFileNameWithoutExtension(destPath);
            var ext = Path.GetExtension(destPath);

            for (int i = 1; i < 10000; i++)
            {
                var p = CombineAssetPath(dir, $"{name}_{i}{ext}");
                if (AssetDatabase.LoadMainAssetAtPath(p) == null)
                    return p;
            }

            return AssetDatabase.GenerateUniqueAssetPath(destPath);
        }

        private static void RenamePresetAsset(AssetsPackPreset preset, string newName)
        {
            if (preset == null) return;

            newName = (newName ?? "").Trim();
            if (string.IsNullOrEmpty(newName)) return;

            foreach (var c in Path.GetInvalidFileNameChars())
                newName = newName.Replace(c.ToString(), "");

            if (string.IsNullOrEmpty(newName)) return;

            var path = AssetDatabase.GetAssetPath(preset);
            if (string.IsNullOrEmpty(path)) return;

            var err = AssetDatabase.RenameAsset(path, newName);
            if (!string.IsNullOrEmpty(err))
            {
                EditorUtility.DisplayDialog("AssetsPackTool", $"プリセット名の変更に失敗しました。\n{err}", "OK");
                return;
            }

            preset.name = newName;

            EditorUtility.SetDirty(preset);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            SaveLastPresetGuid(preset);
            EditorGUIUtility.PingObject(preset);
        }

        private sealed class PresetPickerWindow : EditorWindow
        {
            private List<AssetsPackPreset> presets;
            private Action<AssetsPackPreset> onPick;
            private Vector2 scroll;

            public static void Open(string title, List<AssetsPackPreset> presets, Action<AssetsPackPreset> onPick)
            {
                var w = CreateInstance<PresetPickerWindow>();
                w.titleContent = new GUIContent(title);
                w.presets = presets ?? new List<AssetsPackPreset>();
                w.onPick = onPick;
                w.minSize = new Vector2(520, 420);
                w.ShowUtility();
            }

            private void OnGUI()
            {
                if (presets == null || presets.Count == 0)
                {
                    EditorGUILayout.HelpBox("プリセットが見つかりませんでした。", MessageType.Info);
                    if (GUILayout.Button("閉じる", GUILayout.Height(24))) Close();
                    return;
                }

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("プリセットを選択してください。");

                EditorGUILayout.Space(6);
                using (var sv = new EditorGUILayout.ScrollViewScope(scroll))
                {
                    scroll = sv.scrollPosition;

                    for (int i = 0; i < presets.Count; i++)
                    {
                        var p = presets[i];
                        if (p == null) continue;

                        using (new EditorGUILayout.HorizontalScope("box"))
                        {
                            GUILayout.Label(p.name, GUILayout.ExpandWidth(true));
                            if (GUILayout.Button("選択", GUILayout.Width(80)))
                            {
                                onPick?.Invoke(p);
                                Close();
                                //GUIUtility.ExitGUI();
                            }
                        }
                    }
                }

                EditorGUILayout.Space(6);
                if (GUILayout.Button("閉じる", GUILayout.Height(24))) Close();
            }
        }
    }
}