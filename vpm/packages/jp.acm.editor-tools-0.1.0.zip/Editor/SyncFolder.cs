using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using UnityEditor;
using UnityEngine;

public class SyncFolder : EditorWindow
{
    private const string ToolVersion = "2.0.0";
    private const int MaxPreviewRows = 200;
    private const string SettingsKeyPrefix = "ACM.SyncFolder.V2.Settings.";

    private enum SyncMode
    {
        FileReplacement,
        FolderSync
    }

    private enum PlanKind
    {
        Copy,
        Skip,
        Error
    }

    [Serializable]
    private sealed class SyncPair
    {
        public string sourcePath = string.Empty;
        public string targetPath = string.Empty;
    }

    [Serializable]
    private sealed class SyncSettings
    {
        public bool japanese = true;
        public SyncMode mode = SyncMode.FileReplacement;
        public bool recursiveFolderSync;
        public bool createTargetDirectories = true;
        public bool skipUnchangedFiles = true;
        public bool createBackups = true;
        public List<SyncPair> pairs = new List<SyncPair> { new SyncPair() };
    }

    private sealed class PlannedOperation
    {
        public int pairIndex;
        public PlanKind kind;
        public string sourceAbsolutePath;
        public string targetAbsolutePath;
        public string targetAssetPath;
        public string sourceFileName;
        public string targetFileName;
        public string reasonJa;
        public string reasonEn;
        public string originalGuid;
        public bool nameMismatch;
        public bool createsNewGuid;
        public long sourceSize;
        public HashSet<string> previousSubAssets;
    }

    private sealed class StatusEntry
    {
        public MessageType type;
        public string ja;
        public string en;
    }

    private sealed class BackupInfo
    {
        public bool available;
        public bool targetExisted;
        public bool metaExisted;
        public string targetBackupPath;
        public string metaBackupPath;
    }

    private SyncSettings _settings;
    private List<PlannedOperation> _preview;
    private readonly List<StatusEntry> _statusEntries = new List<StatusEntry>();
    private Vector2 _mainScroll;
    private Vector2 _previewScroll;
    private Vector2 _statusScroll;
    private bool _showPaths = true;
    private bool _showOptions = true;
    private bool _showPreview = true;
    private bool _showStatus = true;

    private bool IsJapanese => _settings == null || _settings.japanese;
    private static string ProjectRoot => Directory.GetParent(Application.dataPath).FullName;
    private static string BackupRoot => Path.Combine(ProjectRoot, "Library", "ACM", "SyncFolderBackups");
    private static string StagingRoot => Path.Combine(ProjectRoot, "Library", "ACM", "SyncFolderStaging");
    private static string SettingsKey => SettingsKeyPrefix + Application.dataPath.Replace('\\', '/');

    [MenuItem("Tools/ACM/SyncFolder")]
    public static void ShowWindow()
    {
        SyncFolder window = GetWindow<SyncFolder>();
        window.titleContent = new GUIContent("ACM Sync Folder");
        window.minSize = new Vector2(620f, 520f);
        window.Show();
    }

    private void OnEnable()
    {
        LoadSettings();
        titleContent = new GUIContent("ACM Sync Folder");
        minSize = new Vector2(620f, 520f);
    }

    private void OnDisable()
    {
        SaveSettings();
    }

    private void OnGUI()
    {
        EnsureSettings();
        DrawLanguageToolbar();

        EditorGUILayout.LabelField(T("ACM アセット同期", "ACM Asset Sync"), EditorStyles.boldLabel);
        EditorGUILayout.LabelField(
            T("既存アセットの .meta と GUID を保護しながら内容を更新します。",
              "Updates asset contents while protecting the existing .meta file and GUID."),
            EditorStyles.wordWrappedLabel);
        EditorGUILayout.LabelField("Version " + ToolVersion, EditorStyles.miniLabel);
        EditorGUILayout.Space(6f);

        EditorGUI.BeginChangeCheck();
        _mainScroll = EditorGUILayout.BeginScrollView(_mainScroll);
        DrawModeSelection();
        DrawPathPairs();
        DrawOptions();
        EditorGUILayout.EndScrollView();
        bool settingsChanged = EditorGUI.EndChangeCheck();

        if (settingsChanged)
        {
            InvalidatePreview();
            SaveSettings();
        }

        EditorGUILayout.Space(6f);
        DrawActionButtons();
        DrawPreview();
        DrawStatus();
    }

    private string T(string ja, string en)
    {
        return IsJapanese ? ja : en;
    }

    private GUIContent C(string ja, string en, string tipJa, string tipEn)
    {
        return new GUIContent(T(ja, en), T(tipJa, tipEn));
    }

    private void DrawLanguageToolbar()
    {
        EditorGUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        int selected = GUILayout.Toolbar(_settings != null && _settings.japanese ? 0 : 1, new[] { "JP", "EN" }, GUILayout.Width(74));
        bool japanese = selected == 0;
        if (_settings != null && japanese != _settings.japanese)
        {
            _settings.japanese = japanese;
            SaveSettings();
        }
        EditorGUILayout.EndHorizontal();
    }

    private void DrawModeSelection()
    {
        EditorGUILayout.LabelField(T("動作モード", "Operation Mode"), EditorStyles.boldLabel);
        string[] labels =
        {
            T("ファイル置換（GUID維持）", "Replace File (Preserve GUID)"),
            T("フォルダー同期", "Sync Folder")
        };
        _settings.mode = (SyncMode)GUILayout.Toolbar((int)_settings.mode, labels);

        if (_settings.mode == SyncMode.FileReplacement)
        {
            EditorGUILayout.HelpBox(
                T("別名ファイルもコピー先の名前で置換できます。名前が異なる場合は実行前に警告します。コピー先の .meta は変更しません。",
                  "A differently named source can replace the target while keeping the target name. A warning is shown before execution, and the target .meta is not changed."),
                MessageType.Info);
        }
        else
        {
            EditorGUILayout.HelpBox(
                T("コピー元にあるファイルを追加・更新します。コピー先だけにあるファイルは削除しません。",
                  "Adds and updates files from the source. Files that exist only in the target are not deleted."),
                MessageType.Info);
        }

        EditorGUILayout.Space(6f);
    }

    private void DrawPathPairs()
    {
        _showPaths = EditorGUILayout.BeginFoldoutHeaderGroup(_showPaths, T("同期パス", "Sync Paths"));
        if (_showPaths)
        {
            EditorGUILayout.BeginVertical(GUI.skin.box);
            List<string> additionalSources = new List<string>();
            List<string> additionalTargets = new List<string>();

            for (int i = 0; i < _settings.pairs.Count; i++)
            {
                SyncPair pair = _settings.pairs[i];
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField(T($"ペア {i + 1}", $"Pair {i + 1}"), EditorStyles.boldLabel);
                GUILayout.FlexibleSpace();

                GUI.enabled = i > 0;
                if (GUILayout.Button("▲", GUILayout.Width(28f)))
                {
                    SwapPairs(i, i - 1);
                }
                GUI.enabled = i < _settings.pairs.Count - 1;
                if (GUILayout.Button("▼", GUILayout.Width(28f)))
                {
                    SwapPairs(i, i + 1);
                }
                GUI.enabled = true;

                if (GUILayout.Button(T("削除", "Remove"), GUILayout.Width(64f)))
                {
                    _settings.pairs.RemoveAt(i);
                    i--;
                    EditorGUILayout.EndHorizontal();
                    EditorGUILayout.EndVertical();
                    continue;
                }
                EditorGUILayout.EndHorizontal();

                bool folderMode = _settings.mode == SyncMode.FolderSync;
                string sourceLabel = folderMode
                    ? T("コピー元フォルダー", "Source Folder")
                    : T("置換元（新しい内容）", "Replacement Source");
                string targetLabel = folderMode
                    ? T("コピー先フォルダー", "Target Folder")
                    : T("置換先（名前・GUID維持）", "Existing Target (Keep Name/GUID)");

                pair.sourcePath = DrawPathField(sourceLabel, pair.sourcePath, folderMode, additionalSources);
                pair.targetPath = DrawPathField(targetLabel, pair.targetPath, folderMode, additionalTargets);
                DrawInlinePairValidation(pair, folderMode);
                EditorGUILayout.EndVertical();
                EditorGUILayout.Space(4f);
            }

            foreach (string source in additionalSources)
            {
                _settings.pairs.Add(new SyncPair { sourcePath = source });
            }
            foreach (string target in additionalTargets)
            {
                _settings.pairs.Add(new SyncPair { targetPath = target });
            }

            if (_settings.pairs.Count == 0)
            {
                _settings.pairs.Add(new SyncPair());
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(T("パスを追加", "Add Path Pair")))
            {
                _settings.pairs.Add(new SyncPair());
            }
            if (GUILayout.Button(T("空の行を削除", "Remove Empty Rows")))
            {
                _settings.pairs.RemoveAll(pair => string.IsNullOrWhiteSpace(pair.sourcePath) && string.IsNullOrWhiteSpace(pair.targetPath));
                if (_settings.pairs.Count == 0)
                {
                    _settings.pairs.Add(new SyncPair());
                }
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.EndVertical();
        }
        EditorGUILayout.EndFoldoutHeaderGroup();
    }

    private string DrawPathField(string label, string path, bool folder, List<string> additionalDrops)
    {
        EditorGUILayout.LabelField(label);
        EditorGUILayout.BeginHorizontal();
        string updatedPath = EditorGUILayout.TextField(path ?? string.Empty);
        Rect fieldRect = GUILayoutUtility.GetLastRect();
        if (GUILayout.Button("...", GUILayout.Width(34f)))
        {
            string initialDirectory = GetInitialDirectory(updatedPath);
            string selected = folder
                ? EditorUtility.OpenFolderPanel(label, initialDirectory, string.Empty)
                : EditorUtility.OpenFilePanel(label, initialDirectory, string.Empty);
            if (!string.IsNullOrEmpty(selected))
            {
                updatedPath = selected;
            }
        }
        EditorGUILayout.EndHorizontal();

        Event evt = Event.current;
        if ((evt.type == EventType.DragUpdated || evt.type == EventType.DragPerform) && fieldRect.Contains(evt.mousePosition))
        {
            List<string> validPaths = DragAndDrop.paths
                .Where(dropped => folder ? Directory.Exists(ToAbsolutePathUnchecked(dropped)) : File.Exists(ToAbsolutePathUnchecked(dropped)))
                .ToList();
            DragAndDrop.visualMode = validPaths.Count > 0 ? DragAndDropVisualMode.Copy : DragAndDropVisualMode.Rejected;

            if (evt.type == EventType.DragPerform)
            {
                DragAndDrop.AcceptDrag();
                if (validPaths.Count > 0)
                {
                    updatedPath = validPaths[0];
                    for (int i = 1; i < validPaths.Count; i++)
                    {
                        additionalDrops.Add(validPaths[i]);
                    }
                }
                evt.Use();
            }
        }

        return updatedPath;
    }

    private void DrawInlinePairValidation(SyncPair pair, bool folderMode)
    {
        if (folderMode || string.IsNullOrWhiteSpace(pair.sourcePath) || string.IsNullOrWhiteSpace(pair.targetPath))
        {
            return;
        }

        string sourceName = SafeFileName(pair.sourcePath);
        string targetName = SafeFileName(pair.targetPath);
        string sourceExtension = SafeExtension(pair.sourcePath);
        string targetExtension = SafeExtension(pair.targetPath);

        if (!string.Equals(sourceExtension, targetExtension, StringComparison.OrdinalIgnoreCase))
        {
            EditorGUILayout.HelpBox(
                T($"拡張子が異なります（{sourceExtension} → {targetExtension}）。このペアは実行できません。",
                  $"Extensions differ ({sourceExtension} -> {targetExtension}). This pair cannot run."),
                MessageType.Error);
        }
        else if (!string.Equals(sourceName, targetName, StringComparison.Ordinal))
        {
            EditorGUILayout.HelpBox(
                T($"名前が異なります：{sourceName} → {targetName}。実行時に確認します。",
                  $"Names differ: {sourceName} -> {targetName}. Confirmation is required before execution."),
                MessageType.Warning);
        }
    }

    private void DrawOptions()
    {
        _showOptions = EditorGUILayout.BeginFoldoutHeaderGroup(_showOptions, T("オプション", "Options"));
        if (_showOptions)
        {
            EditorGUILayout.BeginVertical(GUI.skin.box);
            _settings.skipUnchangedFiles = EditorGUILayout.Toggle(
                C("同一内容をスキップ", "Skip Unchanged Files",
                  "SHA-256ハッシュが同じファイルはコピーと再インポートを省略します。",
                  "Skips copy and reimport when SHA-256 hashes match."),
                _settings.skipUnchangedFiles);
            _settings.createBackups = EditorGUILayout.Toggle(
                C("バックアップを作成", "Create Backups",
                  "上書き前のファイルと.metaをLibrary/ACM/SyncFolderBackupsへ保存し、失敗時に復元します。",
                  "Stores the previous file and .meta under Library/ACM/SyncFolderBackups and restores them on failure."),
                _settings.createBackups);
            _settings.createTargetDirectories = EditorGUILayout.Toggle(
                C("コピー先フォルダーを作成", "Create Target Directories",
                  "不足しているコピー先フォルダーを実行時に作成します。",
                  "Creates missing target directories during execution."),
                _settings.createTargetDirectories);

            if (_settings.mode == SyncMode.FolderSync)
            {
                _settings.recursiveFolderSync = EditorGUILayout.Toggle(
                    C("サブフォルダーも同期", "Include Subfolders",
                      "コピー元の相対フォルダー構造を維持して再帰的に同期します。",
                      "Recursively syncs while preserving the source-relative folder structure."),
                    _settings.recursiveFolderSync);
                EditorGUILayout.HelpBox(
                    T("安全のため、コピー先だけに存在するファイルやフォルダーは削除しません。",
                      "For safety, files and folders that exist only in the target are never deleted."),
                    MessageType.None);
            }

            if (_settings.createBackups)
            {
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField(T("保存先", "Location"), BackupRoot, EditorStyles.miniLabel);
                if (GUILayout.Button(T("開く", "Reveal"), GUILayout.Width(60f)))
                {
                    Directory.CreateDirectory(BackupRoot);
                    EditorUtility.RevealInFinder(BackupRoot);
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndVertical();
        }
        EditorGUILayout.EndFoldoutHeaderGroup();
    }

    private void DrawActionButtons()
    {
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button(T("プレビューを更新", "Refresh Preview"), GUILayout.Height(28f)))
        {
            _preview = BuildPlan();
        }

        GUI.backgroundColor = new Color(0.55f, 0.9f, 0.65f);
        if (GUILayout.Button(T("同期を実行", "Execute Sync"), GUILayout.Height(28f)))
        {
            ExecuteSync();
        }
        GUI.backgroundColor = Color.white;
        EditorGUILayout.EndHorizontal();
    }

    private void DrawPreview()
    {
        _showPreview = EditorGUILayout.BeginFoldoutHeaderGroup(_showPreview, T("実行プレビュー", "Execution Preview"));
        if (_showPreview)
        {
            EditorGUILayout.BeginVertical(GUI.skin.box);
            if (_preview == null)
            {
                EditorGUILayout.HelpBox(
                    T("「プレビューを更新」でコピー、スキップ、エラーを確認できます。実行時にも必ず再検証します。",
                      "Use Refresh Preview to inspect copies, skips, and errors. The plan is always revalidated before execution."),
                    MessageType.Info);
            }
            else
            {
                DrawPlanSummary(_preview);
                _previewScroll = EditorGUILayout.BeginScrollView(_previewScroll, GUILayout.MinHeight(100f), GUILayout.MaxHeight(240f));
                int count = Mathf.Min(_preview.Count, MaxPreviewRows);
                for (int i = 0; i < count; i++)
                {
                    PlannedOperation operation = _preview[i];
                    EditorGUILayout.HelpBox(DescribeOperation(operation), GetPlanMessageType(operation));
                }
                if (_preview.Count > count)
                {
                    EditorGUILayout.LabelField(
                        T($"ほか {_preview.Count - count} 件", $"{_preview.Count - count} more items"),
                        EditorStyles.miniLabel);
                }
                EditorGUILayout.EndScrollView();
            }
            EditorGUILayout.EndVertical();
        }
        EditorGUILayout.EndFoldoutHeaderGroup();
    }

    private void DrawPlanSummary(List<PlannedOperation> plan)
    {
        int copyCount = plan.Count(operation => operation.kind == PlanKind.Copy);
        int skipCount = plan.Count(operation => operation.kind == PlanKind.Skip);
        int errorCount = plan.Count(operation => operation.kind == PlanKind.Error);
        int mismatchCount = plan.Count(operation => operation.kind == PlanKind.Copy && operation.nameMismatch);
        int newGuidCount = plan.Count(operation => operation.kind == PlanKind.Copy && operation.createsNewGuid);

        EditorGUILayout.LabelField(
            T($"コピー {copyCount} / スキップ {skipCount} / エラー {errorCount}",
              $"Copy {copyCount} / Skip {skipCount} / Errors {errorCount}"),
            EditorStyles.boldLabel);
        if (mismatchCount > 0)
        {
            EditorGUILayout.HelpBox(
                T($"別名置換が {mismatchCount} 件あります。コピー先の名前で上書きします。",
                  $"{mismatchCount} replacement(s) use different names. Content will be written under the target name."),
                MessageType.Warning);
        }
        if (newGuidCount > 0)
        {
            EditorGUILayout.HelpBox(
                T($"既存の .meta がない新規アセットが {newGuidCount} 件あります。これらには新しいGUIDが作成されます。",
                  $"{newGuidCount} asset(s) have no existing .meta and will receive new GUIDs."),
                MessageType.Warning);
        }
    }

    private void DrawStatus()
    {
        _showStatus = EditorGUILayout.BeginFoldoutHeaderGroup(_showStatus, T("実行結果", "Results"));
        if (_showStatus)
        {
            EditorGUILayout.BeginVertical(GUI.skin.box);
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (_statusEntries.Count > 0 && GUILayout.Button(T("結果を消去", "Clear Results"), GUILayout.Width(100f)))
            {
                _statusEntries.Clear();
            }
            EditorGUILayout.EndHorizontal();

            if (_statusEntries.Count == 0)
            {
                EditorGUILayout.LabelField(T("まだ実行結果はありません。", "No execution results yet."), EditorStyles.miniLabel);
            }
            else
            {
                _statusScroll = EditorGUILayout.BeginScrollView(_statusScroll, GUILayout.MinHeight(100f), GUILayout.MaxHeight(240f));
                foreach (StatusEntry status in _statusEntries)
                {
                    EditorGUILayout.HelpBox(T(status.ja, status.en), status.type);
                }
                EditorGUILayout.EndScrollView();
            }
            EditorGUILayout.EndVertical();
        }
        EditorGUILayout.EndFoldoutHeaderGroup();
    }

    private List<PlannedOperation> BuildPlan()
    {
        List<PlannedOperation> plan = new List<PlannedOperation>();
        for (int i = 0; i < _settings.pairs.Count; i++)
        {
            SyncPair pair = _settings.pairs[i];
            if (string.IsNullOrWhiteSpace(pair.sourcePath) && string.IsNullOrWhiteSpace(pair.targetPath))
            {
                continue;
            }

            if (_settings.mode == SyncMode.FileReplacement)
            {
                PlanFilePair(plan, pair, i);
            }
            else
            {
                PlanFolderPair(plan, pair, i);
            }
        }

        if (plan.Count == 0)
        {
            plan.Add(ErrorOperation(-1,
                "有効な同期パスがありません。",
                "No valid sync paths were provided."));
        }
        return plan;
    }

    private void PlanFilePair(List<PlannedOperation> plan, SyncPair pair, int pairIndex)
    {
        if (!TryGetAbsolutePath(pair.sourcePath, out string sourcePath, out string sourceError))
        {
            plan.Add(ErrorOperation(pairIndex, sourceError, sourceError));
            return;
        }
        if (!TryGetAbsolutePath(pair.targetPath, out string targetPath, out string targetError))
        {
            plan.Add(ErrorOperation(pairIndex, targetError, targetError));
            return;
        }
        if (!File.Exists(sourcePath))
        {
            plan.Add(ErrorOperation(pairIndex,
                $"置換元ファイルが存在しません：{sourcePath}",
                $"Replacement source does not exist: {sourcePath}"));
            return;
        }
        if (Directory.Exists(targetPath))
        {
            plan.Add(ErrorOperation(pairIndex,
                $"ファイル置換のコピー先にフォルダーが指定されています：{targetPath}",
                $"A folder was selected as the file replacement target: {targetPath}"));
            return;
        }

        PlanCopy(plan, sourcePath, targetPath, pairIndex, true);
    }

    private void PlanFolderPair(List<PlannedOperation> plan, SyncPair pair, int pairIndex)
    {
        if (!TryGetAbsolutePath(pair.sourcePath, out string sourceRoot, out string sourceError))
        {
            plan.Add(ErrorOperation(pairIndex, sourceError, sourceError));
            return;
        }
        if (!TryGetAbsolutePath(pair.targetPath, out string targetRoot, out string targetError))
        {
            plan.Add(ErrorOperation(pairIndex, targetError, targetError));
            return;
        }
        if (!Directory.Exists(sourceRoot))
        {
            plan.Add(ErrorOperation(pairIndex,
                $"コピー元フォルダーが存在しません：{sourceRoot}",
                $"Source folder does not exist: {sourceRoot}"));
            return;
        }
        if (File.Exists(targetRoot))
        {
            plan.Add(ErrorOperation(pairIndex,
                $"フォルダー同期のコピー先にファイルが指定されています：{targetRoot}",
                $"A file was selected as the folder sync target: {targetRoot}"));
            return;
        }
        if (!TryToAssetPath(targetRoot, out _))
        {
            plan.Add(ErrorOperation(pairIndex,
                $"コピー先はUnityプロジェクトのAssets配下に指定してください：{targetRoot}",
                $"The target must be located under the Unity project's Assets folder: {targetRoot}"));
            return;
        }
        if (AreSamePath(sourceRoot, targetRoot) || IsPathInside(sourceRoot, targetRoot) || IsPathInside(targetRoot, sourceRoot))
        {
            plan.Add(ErrorOperation(pairIndex,
                "コピー元とコピー先を同一または入れ子のフォルダーにはできません。",
                "Source and target folders cannot be identical or nested inside one another."));
            return;
        }
        if (!Directory.Exists(targetRoot) && !_settings.createTargetDirectories)
        {
            plan.Add(ErrorOperation(pairIndex,
                $"コピー先フォルダーが存在しません：{targetRoot}",
                $"Target folder does not exist: {targetRoot}"));
            return;
        }

        try
        {
            SearchOption searchOption = _settings.recursiveFolderSync ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            string[] files = Directory.GetFiles(sourceRoot, "*", searchOption);
            int added = 0;
            foreach (string sourceFile in files)
            {
                if (IsMetaFile(sourceFile))
                {
                    continue;
                }

                string relativePath = GetRelativeChildPath(sourceRoot, sourceFile);
                string targetFile = Path.Combine(targetRoot, relativePath);
                PlanCopy(plan, sourceFile, targetFile, pairIndex, false);
                added++;
            }

            if (added == 0)
            {
                plan.Add(new PlannedOperation
                {
                    pairIndex = pairIndex,
                    kind = PlanKind.Skip,
                    reasonJa = $"コピー対象のファイルがありません：{sourceRoot}",
                    reasonEn = $"No files to copy: {sourceRoot}"
                });
            }
        }
        catch (Exception exception)
        {
            plan.Add(ErrorOperation(pairIndex,
                $"フォルダーの読み取りに失敗しました：{exception.Message}",
                $"Failed to read the folder: {exception.Message}"));
        }
    }

    private void PlanCopy(List<PlannedOperation> plan, string sourcePath, string targetPath, int pairIndex, bool detectNameMismatch)
    {
        if (IsMetaFile(sourcePath) || IsMetaFile(targetPath))
        {
            plan.Add(ErrorOperation(pairIndex,
                ".metaファイルは同期対象にできません。",
                ".meta files cannot be synchronized."));
            return;
        }
        if (!TryToAssetPath(targetPath, out string assetPath))
        {
            plan.Add(ErrorOperation(pairIndex,
                $"コピー先はUnityプロジェクトのAssets配下に指定してください：{targetPath}",
                $"The target must be located under the Unity project's Assets folder: {targetPath}"));
            return;
        }
        if (AreSamePath(sourcePath, targetPath))
        {
            plan.Add(new PlannedOperation
            {
                pairIndex = pairIndex,
                kind = PlanKind.Skip,
                sourceAbsolutePath = sourcePath,
                targetAbsolutePath = targetPath,
                targetAssetPath = assetPath,
                reasonJa = $"コピー元とコピー先が同じためスキップ：{assetPath}",
                reasonEn = $"Skipped because source and target are identical: {assetPath}"
            });
            return;
        }

        string sourceExtension = Path.GetExtension(sourcePath);
        string targetExtension = Path.GetExtension(targetPath);
        if (!string.Equals(sourceExtension, targetExtension, StringComparison.OrdinalIgnoreCase))
        {
            plan.Add(ErrorOperation(pairIndex,
                $"拡張子が異なるため実行できません：{sourceExtension} → {targetExtension}",
                $"Extensions differ and cannot be processed: {sourceExtension} -> {targetExtension}"));
            return;
        }

        string targetDirectory = Path.GetDirectoryName(targetPath);
        if (string.IsNullOrEmpty(targetDirectory))
        {
            plan.Add(ErrorOperation(pairIndex,
                $"コピー先フォルダーを判定できません：{targetPath}",
                $"Could not determine the target folder: {targetPath}"));
            return;
        }
        if (!Directory.Exists(targetDirectory) && !_settings.createTargetDirectories)
        {
            plan.Add(ErrorOperation(pairIndex,
                $"コピー先フォルダーが存在しません：{targetDirectory}",
                $"Target folder does not exist: {targetDirectory}"));
            return;
        }
        if (File.Exists(targetPath) && (File.GetAttributes(targetPath) & FileAttributes.ReadOnly) != 0)
        {
            plan.Add(ErrorOperation(pairIndex,
                $"コピー先ファイルは読み取り専用です：{assetPath}",
                $"Target file is read-only: {assetPath}"));
            return;
        }

        bool targetExists = File.Exists(targetPath);
        if (targetExists && _settings.skipUnchangedFiles)
        {
            try
            {
                if (FilesAreIdentical(sourcePath, targetPath))
                {
                    plan.Add(new PlannedOperation
                    {
                        pairIndex = pairIndex,
                        kind = PlanKind.Skip,
                        sourceAbsolutePath = sourcePath,
                        targetAbsolutePath = targetPath,
                        targetAssetPath = assetPath,
                        reasonJa = $"内容が同一のためスキップ：{assetPath}",
                        reasonEn = $"Skipped because contents are identical: {assetPath}"
                    });
                    return;
                }
            }
            catch (Exception exception)
            {
                plan.Add(ErrorOperation(pairIndex,
                    $"ファイル比較に失敗しました：{exception.Message}",
                    $"Failed to compare files: {exception.Message}"));
                return;
            }
        }

        string sourceName = Path.GetFileName(sourcePath);
        string targetName = Path.GetFileName(targetPath);
        string metaPath = targetPath + ".meta";
        string originalGuid = ReadMetaGuid(metaPath);
        bool createsNewGuid = string.IsNullOrEmpty(originalGuid);

        plan.Add(new PlannedOperation
        {
            pairIndex = pairIndex,
            kind = PlanKind.Copy,
            sourceAbsolutePath = sourcePath,
            targetAbsolutePath = targetPath,
            targetAssetPath = assetPath,
            sourceFileName = sourceName,
            targetFileName = targetName,
            nameMismatch = detectNameMismatch && !string.Equals(sourceName, targetName, StringComparison.Ordinal),
            createsNewGuid = createsNewGuid,
            originalGuid = originalGuid,
            sourceSize = new FileInfo(sourcePath).Length,
            previousSubAssets = IsFbx(targetPath) && targetExists ? CaptureSubAssetIdentities(assetPath) : null
        });
    }

    private void ExecuteSync()
    {
        _statusEntries.Clear();
        _preview = BuildPlan();

        List<PlannedOperation> copyOperations = _preview.Where(operation => operation.kind == PlanKind.Copy).ToList();
        foreach (PlannedOperation operation in _preview.Where(operation => operation.kind == PlanKind.Error))
        {
            AddStatus(MessageType.Error, operation.reasonJa, operation.reasonEn);
        }
        foreach (PlannedOperation operation in _preview.Where(operation => operation.kind == PlanKind.Skip))
        {
            AddStatus(MessageType.Info, operation.reasonJa, operation.reasonEn);
        }

        if (copyOperations.Count == 0)
        {
            AddStatus(MessageType.Warning,
                "実行できるコピー処理がありません。プレビューのエラーを確認してください。",
                "There are no copy operations to execute. Review the preview errors.");
            Repaint();
            return;
        }

        if (!ConfirmExecution(copyOperations, _preview.Count(operation => operation.kind == PlanKind.Error)))
        {
            AddStatus(MessageType.Info, "同期をキャンセルしました。", "Synchronization was cancelled.");
            Repaint();
            return;
        }

        string sessionBackupRoot = Path.Combine(BackupRoot, DateTime.Now.ToString("yyyyMMdd_HHmmss_fff"));
        int successCount = 0;
        int failureCount = 0;
        bool cancelled = false;

        try
        {
            for (int i = 0; i < copyOperations.Count; i++)
            {
                PlannedOperation operation = copyOperations[i];
                if (EditorUtility.DisplayCancelableProgressBar(
                    T("ACM アセット同期", "ACM Asset Sync"),
                    T($"{operation.sourceFileName} → {operation.targetAssetPath}",
                      $"{operation.sourceFileName} -> {operation.targetAssetPath}"),
                    (float)i / copyOperations.Count))
                {
                    cancelled = true;
                    break;
                }

                if (ExecuteCopy(operation, sessionBackupRoot))
                {
                    successCount++;
                }
                else
                {
                    failureCount++;
                }
            }
        }
        finally
        {
            EditorUtility.ClearProgressBar();
        }

        if (cancelled)
        {
            AddStatus(MessageType.Warning,
                "処理を途中でキャンセルしました。完了済みのファイルはそのままです。",
                "Processing was cancelled. Files completed before cancellation remain updated.");
        }

        AddStatus(failureCount == 0 ? MessageType.Info : MessageType.Warning,
            $"完了：成功 {successCount} / 失敗 {failureCount}" + (cancelled ? " / キャンセル" : string.Empty),
            $"Completed: {successCount} succeeded / {failureCount} failed" + (cancelled ? " / Cancelled" : string.Empty));
        SaveSettings();
        Repaint();
    }

    private bool ConfirmExecution(List<PlannedOperation> operations, int errorCount)
    {
        int mismatchCount = operations.Count(operation => operation.nameMismatch);
        int overwriteCount = operations.Count(operation => File.Exists(operation.targetAbsolutePath));
        int newGuidCount = operations.Count(operation => operation.createsNewGuid);

        string detailsJa = $"コピー：{operations.Count}件\n既存ファイルの上書き：{overwriteCount}件";
        string detailsEn = $"Copies: {operations.Count}\nExisting files overwritten: {overwriteCount}";
        if (mismatchCount > 0)
        {
            detailsJa += $"\n\n警告：別名置換が{mismatchCount}件あります。コピー先の名前と.metaを維持して内容を置換します。";
            detailsEn += $"\n\nWarning: {mismatchCount} replacement(s) use different names. Contents will be replaced while keeping the target name and .meta.";

            IEnumerable<PlannedOperation> examples = operations.Where(operation => operation.nameMismatch).Take(8);
            foreach (PlannedOperation operation in examples)
            {
                detailsJa += $"\n・{operation.sourceFileName} → {operation.targetFileName}";
                detailsEn += $"\n- {operation.sourceFileName} -> {operation.targetFileName}";
            }
            if (mismatchCount > 8)
            {
                detailsJa += $"\n・ほか {mismatchCount - 8}件";
                detailsEn += $"\n- {mismatchCount - 8} more";
            }
        }
        if (newGuidCount > 0)
        {
            detailsJa += $"\n\n注意：既存.metaがない{newGuidCount}件には新しいGUIDが作成されます。";
            detailsEn += $"\n\nNote: {newGuidCount} item(s) have no existing .meta and will receive new GUIDs.";
        }
        if (errorCount > 0)
        {
            detailsJa += $"\n\nエラー{errorCount}件は実行せず、有効な項目だけを処理します。";
            detailsEn += $"\n\n{errorCount} error item(s) will be skipped; only valid items will run.";
        }
        detailsJa += "\n\n実行しますか？";
        detailsEn += "\n\nProceed?";

        return EditorUtility.DisplayDialog(
            T("同期の確認", "Confirm Synchronization"),
            T(detailsJa, detailsEn),
            T("上書きを実行", "Execute"),
            T("キャンセル", "Cancel"));
    }

    private bool ExecuteCopy(PlannedOperation operation, string sessionBackupRoot)
    {
        BackupInfo backup = null;
        try
        {
            string targetDirectory = Path.GetDirectoryName(operation.targetAbsolutePath);
            if (string.IsNullOrEmpty(targetDirectory))
            {
                throw new InvalidOperationException("Target directory could not be determined.");
            }
            if (!Directory.Exists(targetDirectory))
            {
                if (!_settings.createTargetDirectories)
                {
                    throw new DirectoryNotFoundException(targetDirectory);
                }
                Directory.CreateDirectory(targetDirectory);
            }

            if (_settings.createBackups)
            {
                backup = CreateBackup(operation, sessionBackupRoot);
            }

            ReplaceFileContent(operation.sourceAbsolutePath, operation.targetAbsolutePath);
            AssetDatabase.ImportAsset(
                operation.targetAssetPath,
                ImportAssetOptions.ForceUpdate | ImportAssetOptions.ForceSynchronousImport);

            string resultingGuid = ReadMetaGuid(operation.targetAbsolutePath + ".meta");
            if (!string.IsNullOrEmpty(operation.originalGuid) &&
                !string.Equals(operation.originalGuid, resultingGuid, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    $"Asset GUID changed from {operation.originalGuid} to {resultingGuid}.");
            }
            if (IsFbx(operation.targetAbsolutePath) && AssetDatabase.LoadMainAssetAtPath(operation.targetAssetPath) == null)
            {
                throw new InvalidOperationException("The FBX could not be imported as a Unity asset.");
            }

            AddStatus(MessageType.Info,
                $"同期成功：{operation.sourceFileName} → {operation.targetAssetPath}" +
                (!string.IsNullOrEmpty(resultingGuid) ? $"（GUID: {resultingGuid}）" : string.Empty),
                $"Synchronized: {operation.sourceFileName} -> {operation.targetAssetPath}" +
                (!string.IsNullOrEmpty(resultingGuid) ? $" (GUID: {resultingGuid})" : string.Empty));

            ReportSubAssetChanges(operation);
            return true;
        }
        catch (Exception exception)
        {
            string restoreJa = string.Empty;
            string restoreEn = string.Empty;
            if (backup != null && backup.available)
            {
                try
                {
                    RestoreBackup(operation, backup);
                    restoreJa = " 元のファイルへ復元しました。";
                    restoreEn = " The original file was restored.";
                }
                catch (Exception restoreException)
                {
                    restoreJa = $" 復元にも失敗しました：{restoreException.Message}";
                    restoreEn = $" Restore also failed: {restoreException.Message}";
                }
            }

            AddStatus(MessageType.Error,
                $"同期失敗：{operation.targetAssetPath}\n{exception.Message}{restoreJa}",
                $"Synchronization failed: {operation.targetAssetPath}\n{exception.Message}{restoreEn}");
            Debug.LogException(exception);
            return false;
        }
    }

    private BackupInfo CreateBackup(PlannedOperation operation, string sessionBackupRoot)
    {
        BackupInfo backup = new BackupInfo
        {
            targetExisted = File.Exists(operation.targetAbsolutePath),
            metaExisted = File.Exists(operation.targetAbsolutePath + ".meta")
        };

        string relativeAssetPath = operation.targetAssetPath.Replace('/', Path.DirectorySeparatorChar);
        backup.targetBackupPath = Path.Combine(sessionBackupRoot, relativeAssetPath);
        backup.metaBackupPath = backup.targetBackupPath + ".meta";
        string backupDirectory = Path.GetDirectoryName(backup.targetBackupPath);
        if (!string.IsNullOrEmpty(backupDirectory))
        {
            Directory.CreateDirectory(backupDirectory);
        }

        if (backup.targetExisted)
        {
            File.Copy(operation.targetAbsolutePath, backup.targetBackupPath, true);
        }
        if (backup.metaExisted)
        {
            File.Copy(operation.targetAbsolutePath + ".meta", backup.metaBackupPath, true);
        }
        backup.available = true;
        return backup;
    }

    private void RestoreBackup(PlannedOperation operation, BackupInfo backup)
    {
        if (backup.targetExisted)
        {
            File.Copy(backup.targetBackupPath, operation.targetAbsolutePath, true);
        }
        else if (File.Exists(operation.targetAbsolutePath))
        {
            File.Delete(operation.targetAbsolutePath);
        }

        string metaPath = operation.targetAbsolutePath + ".meta";
        if (backup.metaExisted)
        {
            File.Copy(backup.metaBackupPath, metaPath, true);
        }
        else if (File.Exists(metaPath))
        {
            File.Delete(metaPath);
        }

        if (File.Exists(operation.targetAbsolutePath))
        {
            AssetDatabase.ImportAsset(
                operation.targetAssetPath,
                ImportAssetOptions.ForceUpdate | ImportAssetOptions.ForceSynchronousImport);
        }
        else
        {
            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        }
    }

    private void ReportSubAssetChanges(PlannedOperation operation)
    {
        if (operation.previousSubAssets == null || operation.previousSubAssets.Count == 0)
        {
            return;
        }

        HashSet<string> current = CaptureSubAssetIdentities(operation.targetAssetPath);
        List<string> missing = operation.previousSubAssets.Where(identity => !current.Contains(identity)).Take(8).ToList();
        if (missing.Count == 0)
        {
            return;
        }

        string details = string.Join("\n", missing.Select(identity => "- " + identity));
        int totalMissing = operation.previousSubAssets.Count(identity => !current.Contains(identity));
        if (totalMissing > missing.Count)
        {
            details += $"\n- ... {totalMissing - missing.Count} more";
        }

        AddStatus(MessageType.Warning,
            $"FBX内部のサブアセット識別子が{totalMissing}件変化または消失しました。Prefab等の参照を確認してください。\n{details}",
            $"{totalMissing} FBX sub-asset identifier(s) changed or disappeared. Check Prefab and other references.\n{details}");
    }

    private static HashSet<string> CaptureSubAssetIdentities(string assetPath)
    {
        HashSet<string> result = new HashSet<string>(StringComparer.Ordinal);
        if (string.IsNullOrEmpty(assetPath))
        {
            return result;
        }

        UnityEngine.Object[] assets = AssetDatabase.LoadAllAssetsAtPath(assetPath);
        foreach (UnityEngine.Object asset in assets)
        {
            if (asset == null)
            {
                continue;
            }
            if (AssetDatabase.TryGetGUIDAndLocalFileIdentifier(asset, out string _, out long localId))
            {
                result.Add($"{asset.GetType().Name} | {asset.name} | fileID {localId}");
            }
        }
        return result;
    }

    private static void ReplaceFileContent(string sourcePath, string targetPath)
    {
        Directory.CreateDirectory(StagingRoot);
        string stagingPath = Path.Combine(StagingRoot, Guid.NewGuid().ToString("N") + Path.GetExtension(targetPath));
        try
        {
            File.Copy(sourcePath, stagingPath, true);
            if (File.Exists(targetPath))
            {
                try
                {
                    File.Replace(stagingPath, targetPath, null, true);
                }
                catch (PlatformNotSupportedException)
                {
                    File.Copy(stagingPath, targetPath, true);
                }
                catch (IOException)
                {
                    File.Copy(stagingPath, targetPath, true);
                }
            }
            else
            {
                File.Move(stagingPath, targetPath);
            }
        }
        finally
        {
            if (File.Exists(stagingPath))
            {
                File.Delete(stagingPath);
            }
        }
    }

    private static bool FilesAreIdentical(string firstPath, string secondPath)
    {
        FileInfo first = new FileInfo(firstPath);
        FileInfo second = new FileInfo(secondPath);
        if (first.Length != second.Length)
        {
            return false;
        }

        using (SHA256 sha = SHA256.Create())
        using (FileStream firstStream = File.OpenRead(firstPath))
        using (FileStream secondStream = File.OpenRead(secondPath))
        {
            byte[] firstHash = sha.ComputeHash(firstStream);
            byte[] secondHash = sha.ComputeHash(secondStream);
            return firstHash.SequenceEqual(secondHash);
        }
    }

    private string DescribeOperation(PlannedOperation operation)
    {
        if (operation.kind == PlanKind.Error || operation.kind == PlanKind.Skip)
        {
            return T(operation.reasonJa, operation.reasonEn);
        }

        string tagsJa = string.Empty;
        string tagsEn = string.Empty;
        if (operation.nameMismatch)
        {
            tagsJa += " [別名置換]";
            tagsEn += " [Different Name]";
        }
        if (operation.createsNewGuid)
        {
            tagsJa += " [新規GUID]";
            tagsEn += " [New GUID]";
        }
        else
        {
            tagsJa += " [GUID維持]";
            tagsEn += " [Preserve GUID]";
        }

        return T(
            $"コピー：{operation.sourceFileName} → {operation.targetAssetPath}{tagsJa} ({FormatSize(operation.sourceSize)})",
            $"Copy: {operation.sourceFileName} -> {operation.targetAssetPath}{tagsEn} ({FormatSize(operation.sourceSize)})");
    }

    private static MessageType GetPlanMessageType(PlannedOperation operation)
    {
        if (operation.kind == PlanKind.Error)
        {
            return MessageType.Error;
        }
        if (operation.kind == PlanKind.Skip)
        {
            return MessageType.None;
        }
        return operation.nameMismatch || operation.createsNewGuid ? MessageType.Warning : MessageType.Info;
    }

    private static PlannedOperation ErrorOperation(int pairIndex, string ja, string en)
    {
        return new PlannedOperation
        {
            pairIndex = pairIndex,
            kind = PlanKind.Error,
            reasonJa = ja,
            reasonEn = en
        };
    }

    private void AddStatus(MessageType type, string ja, string en)
    {
        _statusEntries.Add(new StatusEntry { type = type, ja = ja, en = en });
    }

    private static bool TryGetAbsolutePath(string path, out string absolutePath, out string error)
    {
        absolutePath = string.Empty;
        error = string.Empty;
        if (string.IsNullOrWhiteSpace(path))
        {
            error = "Path is empty.";
            return false;
        }

        try
        {
            absolutePath = ToAbsolutePathUnchecked(path);
            return true;
        }
        catch (Exception exception)
        {
            error = $"Invalid path '{path}': {exception.Message}";
            return false;
        }
    }

    private static string ToAbsolutePathUnchecked(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return string.Empty;
        }
        string normalized = path.Trim().Replace('/', Path.DirectorySeparatorChar);
        return Path.GetFullPath(Path.IsPathRooted(normalized) ? normalized : Path.Combine(ProjectRoot, normalized));
    }

    private static bool TryToAssetPath(string absolutePath, out string assetPath)
    {
        assetPath = string.Empty;
        string fullPath;
        try
        {
            fullPath = Path.GetFullPath(absolutePath);
        }
        catch
        {
            return false;
        }

        string assetsRoot = Path.GetFullPath(Application.dataPath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        if (string.Equals(fullPath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar), assetsRoot, StringComparison.OrdinalIgnoreCase))
        {
            assetPath = "Assets";
            return true;
        }

        string prefix = assetsRoot + Path.DirectorySeparatorChar;
        if (!fullPath.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        assetPath = "Assets/" + fullPath.Substring(prefix.Length).Replace('\\', '/');
        return true;
    }

    private static bool AreSamePath(string firstPath, string secondPath)
    {
        return string.Equals(
            Path.GetFullPath(firstPath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
            Path.GetFullPath(secondPath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar),
            StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsPathInside(string candidatePath, string parentPath)
    {
        string candidate = Path.GetFullPath(candidatePath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        string parent = Path.GetFullPath(parentPath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
        return candidate.StartsWith(parent, StringComparison.OrdinalIgnoreCase);
    }

    private static string GetRelativeChildPath(string rootPath, string childPath)
    {
        string root = Path.GetFullPath(rootPath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
        string child = Path.GetFullPath(childPath);
        return child.StartsWith(root, StringComparison.OrdinalIgnoreCase)
            ? child.Substring(root.Length)
            : Path.GetFileName(child);
    }

    private static string ReadMetaGuid(string metaPath)
    {
        if (!File.Exists(metaPath))
        {
            return string.Empty;
        }

        try
        {
            foreach (string line in File.ReadLines(metaPath))
            {
                string trimmed = line.Trim();
                if (trimmed.StartsWith("guid:", StringComparison.Ordinal))
                {
                    return trimmed.Substring("guid:".Length).Trim();
                }
            }
        }
        catch (IOException)
        {
            return string.Empty;
        }
        return string.Empty;
    }

    private static bool IsMetaFile(string path)
    {
        return string.Equals(Path.GetExtension(path), ".meta", StringComparison.OrdinalIgnoreCase);
    }

    private static bool IsFbx(string path)
    {
        return string.Equals(Path.GetExtension(path), ".fbx", StringComparison.OrdinalIgnoreCase);
    }

    private static string SafeFileName(string path)
    {
        try
        {
            return Path.GetFileName(path);
        }
        catch
        {
            return path;
        }
    }

    private static string SafeExtension(string path)
    {
        try
        {
            return Path.GetExtension(path);
        }
        catch
        {
            return string.Empty;
        }
    }

    private static string GetInitialDirectory(string path)
    {
        try
        {
            string absolute = ToAbsolutePathUnchecked(path);
            if (Directory.Exists(absolute))
            {
                return absolute;
            }
            string directory = Path.GetDirectoryName(absolute);
            return !string.IsNullOrEmpty(directory) && Directory.Exists(directory) ? directory : ProjectRoot;
        }
        catch
        {
            return ProjectRoot;
        }
    }

    private static string FormatSize(long bytes)
    {
        string[] units = { "B", "KB", "MB", "GB" };
        double value = bytes;
        int unit = 0;
        while (value >= 1024d && unit < units.Length - 1)
        {
            value /= 1024d;
            unit++;
        }
        return $"{value:0.##} {units[unit]}";
    }

    private void SwapPairs(int firstIndex, int secondIndex)
    {
        SyncPair temporary = _settings.pairs[firstIndex];
        _settings.pairs[firstIndex] = _settings.pairs[secondIndex];
        _settings.pairs[secondIndex] = temporary;
        InvalidatePreview();
    }

    private void InvalidatePreview()
    {
        _preview = null;
    }

    private void EnsureSettings()
    {
        if (_settings == null)
        {
            _settings = new SyncSettings();
        }
        if (_settings.pairs == null)
        {
            _settings.pairs = new List<SyncPair>();
        }
        if (_settings.pairs.Count == 0)
        {
            _settings.pairs.Add(new SyncPair());
        }
    }

    private void LoadSettings()
    {
        try
        {
            string json = EditorPrefs.GetString(SettingsKey, string.Empty);
            _settings = string.IsNullOrEmpty(json) ? new SyncSettings() : JsonUtility.FromJson<SyncSettings>(json);
        }
        catch (Exception exception)
        {
            Debug.LogWarning($"ACM SyncFolder settings could not be loaded: {exception.Message}");
            _settings = new SyncSettings();
        }
        EnsureSettings();
    }

    private void SaveSettings()
    {
        if (_settings == null)
        {
            return;
        }
        try
        {
            EditorPrefs.SetString(SettingsKey, JsonUtility.ToJson(_settings));
        }
        catch (Exception exception)
        {
            Debug.LogWarning($"ACM SyncFolder settings could not be saved: {exception.Message}");
        }
    }
}
