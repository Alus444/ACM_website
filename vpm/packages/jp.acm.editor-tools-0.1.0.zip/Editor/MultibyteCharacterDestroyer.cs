using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using Debug = UnityEngine.Debug;

public class MultibyteC_Destroyer : EditorWindow
{
    private const string ToolVersion = "2.0.0";
    private const int MaxPreviewRows = 300;
    private const string SettingsKeyPrefix = "ACM.MultibyteCharacterDestroyer.V2.Settings.";
    private const string HistoryKeyPrefix = "ACM.MultibyteCharacterDestroyer.V2.History.";

    private static readonly HashSet<string> RiskyExtensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
    {
        ".cs", ".asmdef", ".asmref", ".dll", ".rsp",
        ".shader", ".compute", ".cginc", ".hlsl", ".glslinc"
    };

    private enum OperationMode
    {
        RemoveNonAscii,
        ReplaceNonAsciiName,
        SearchReplace,
        SequentialRename,
        AddAffix
    }

    private enum HierarchyScope
    {
        SelectedOnly,
        DirectChildren,
        AllDescendants
    }

    private enum PreviewItemKind
    {
        SceneObject,
        AssetFile,
        AssetFolder,
        Ignored
    }

    [Serializable]
    private sealed class SettingsData
    {
        public bool japanese = true;
        public OperationMode operationMode = OperationMode.RemoveNonAscii;
        public HierarchyScope hierarchyScope = HierarchyScope.SelectedOnly;

        public string emptyNameFallback = "Object";
        public int emptyNameStartNumber;

        public string replacementText = "Object";
        public int replacementStartNumber;

        public string searchText = string.Empty;
        public string replaceText = string.Empty;

        public string sequentialName = "Object";
        public int rootStartNumber;
        public int childStartNumber;

        public string prefixText = string.Empty;
        public string suffixText = string.Empty;
        public bool addNumberToAffix;
        public int affixStartNumber;

        public bool allowRiskyAssets;
    }

    [Serializable]
    private sealed class AssetRenameRecord
    {
        public string guid;
        public string originalPath;
        public string finalPath;
        public bool isFolder;
    }

    [Serializable]
    private sealed class HistoryData
    {
        public List<AssetRenameRecord> records = new List<AssetRenameRecord>();
    }

    private sealed class SceneTarget
    {
        public GameObject gameObject;
        public bool isRoot;
    }

    private sealed class AssetTarget
    {
        public string guid;
        public string path;
        public bool isFolder;
    }

    private sealed class PreviewItem
    {
        public PreviewItemKind kind;
        public GameObject sceneObject;
        public string assetGuid;
        public string originalPath;
        public string finalPath;
        public bool assetIsFolder;
        public string beforeName;
        public string afterName;
        public bool willChange;
        public readonly List<string> warningsJa = new List<string>();
        public readonly List<string> warningsEn = new List<string>();
        public readonly List<string> errorsJa = new List<string>();
        public readonly List<string> errorsEn = new List<string>();

        public bool HasError => errorsJa.Count > 0 || errorsEn.Count > 0;
        public bool HasWarning => warningsJa.Count > 0 || warningsEn.Count > 0;
    }

    private sealed class StatusEntry
    {
        public MessageType type;
        public string ja;
        public string en;
    }

    private sealed class MoveRequest
    {
        public string guid;
        public string sourcePath;
        public string targetPath;
        public bool isFolder;
    }

    private sealed class MoveState
    {
        public MoveRequest request;
        public string originalPath;
    }

    private SettingsData _settings;
    private HistoryData _history;
    private readonly List<PreviewItem> _previewItems = new List<PreviewItem>();
    private readonly List<StatusEntry> _statusEntries = new List<StatusEntry>();

    private Vector2 _mainScroll;
    private Vector2 _previewScroll;
    private Vector2 _statusScroll;
    private bool _showSettings = true;
    private bool _showSelection = true;
    private bool _showPreview = true;
    private bool _showResults = true;
    private bool _isApplying;
    private string _previewSelectionSignature = string.Empty;
    private string _previewSettingsSignature = string.Empty;

    private bool IsJapanese => _settings == null || _settings.japanese;
    private static string ProjectRoot => Directory.GetParent(Application.dataPath).FullName;
    private static string SettingsKey => SettingsKeyPrefix + Application.dataPath.Replace('\\', '/');
    private static string HistoryKey => HistoryKeyPrefix + Application.dataPath.Replace('\\', '/');

    [MenuItem("Tools/ACM/MultibyteC_Destroyer")]
    public static void OpenWindow()
    {
        MultibyteC_Destroyer window = GetWindow<MultibyteC_Destroyer>();
        window.titleContent = new GUIContent("ACM Name Sanitizer");
        window.minSize = new Vector2(620f, 620f);
        window.Show();
    }

    private void OnEnable()
    {
        LoadSettings();
        LoadHistory();
        Selection.selectionChanged += OnSelectionChanged;
        titleContent = new GUIContent("ACM Name Sanitizer");
        minSize = new Vector2(620f, 620f);
    }

    private void OnDisable()
    {
        Selection.selectionChanged -= OnSelectionChanged;
        SaveSettings();
        SaveHistory();
    }

    private void OnSelectionChanged()
    {
        if (!_isApplying)
        {
            InvalidatePreview();
        }
        Repaint();
    }

    private void OnProjectChange()
    {
        if (!_isApplying)
        {
            InvalidatePreview();
        }
        Repaint();
    }

    private void OnHierarchyChange()
    {
        if (!_isApplying)
        {
            InvalidatePreview();
        }
        Repaint();
    }

    private void OnGUI()
    {
        EnsureData();
        DrawLanguageToolbar();

        EditorGUILayout.LabelField(T("ACM 名前サニタイザー", "ACM Name Sanitizer"), EditorStyles.boldLabel);
        EditorGUILayout.LabelField(
            T("シーンオブジェクトとProjectアセットの名前を、安全なプレビューを経由して変更します。",
              "Renames scene objects and Project assets through a validated preview."),
            EditorStyles.wordWrappedLabel);
        EditorGUILayout.LabelField("Version " + ToolVersion, EditorStyles.miniLabel);
        EditorGUILayout.Space(6f);

        _mainScroll = EditorGUILayout.BeginScrollView(_mainScroll);
        bool changed = DrawOperationSettings();
        DrawSelectionSummary();
        EditorGUILayout.EndScrollView();

        if (changed)
        {
            SaveSettings();
            InvalidatePreview();
        }

        EditorGUILayout.Space(6f);
        DrawActionButtons();
        DrawPreviewPanel();
        DrawResultsPanel();
    }

    private string T(string ja, string en)
    {
        return IsJapanese ? ja : en;
    }

    private GUIContent C(string ja, string en, string tooltipJa, string tooltipEn)
    {
        return new GUIContent(T(ja, en), T(tooltipJa, tooltipEn));
    }

    private void DrawLanguageToolbar()
    {
        EditorGUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        int selected = GUILayout.Toolbar(IsJapanese ? 0 : 1, new[] { "JP", "EN" }, GUILayout.Width(74f));
        bool japanese = selected == 0;
        if (_settings != null && japanese != _settings.japanese)
        {
            _settings.japanese = japanese;
            SaveSettings();
        }
        EditorGUILayout.EndHorizontal();
    }

    private bool DrawOperationSettings()
    {
        bool changed = false;
        _showSettings = EditorGUILayout.BeginFoldoutHeaderGroup(_showSettings, T("名前変更設定", "Rename Settings"));
        if (_showSettings)
        {
            EditorGUILayout.BeginVertical(GUI.skin.box);
            EditorGUI.BeginChangeCheck();

            string[] modeLabels =
            {
                T("非ASCII文字だけ除去", "Remove Non-ASCII Characters"),
                T("非ASCIIを含む名前全体を置換", "Replace Names Containing Non-ASCII"),
                T("検索・置換", "Search and Replace"),
                T("連番リネーム", "Sequential Rename"),
                T("接頭辞・接尾辞", "Add Prefix and Suffix")
            };
            _settings.operationMode = (OperationMode)EditorGUILayout.Popup(
                C("処理", "Operation", "実行する名前変更処理です。", "Select the rename operation."),
                (int)_settings.operationMode,
                modeLabels);

            EditorGUILayout.Space(4f);
            DrawModeSpecificSettings();
            EditorGUILayout.Space(6f);

            string[] scopeLabels =
            {
                T("選択のみ", "Selected Only"),
                T("直下の子まで", "Direct Children"),
                T("全子階層", "All Descendants")
            };
            _settings.hierarchyScope = (HierarchyScope)EditorGUILayout.Popup(
                C("シーン対象範囲", "Scene Scope",
                  "Projectアセットには影響せず、シーン上のGameObjectだけに適用されます。",
                  "Applies only to scene GameObjects and does not expand Project assets."),
                (int)_settings.hierarchyScope,
                scopeLabels);

            _settings.allowRiskyAssets = EditorGUILayout.Toggle(
                C("コード・Shader系を許可", "Allow Code and Shader Assets",
                  "C#、asmdef、DLL、Shader系アセットのリネームを許可します。通常は無効を推奨します。",
                  "Allows renaming C#, asmdef, DLL, and shader-related assets. Keep disabled unless necessary."),
                _settings.allowRiskyAssets);

            if (_settings.allowRiskyAssets)
            {
                EditorGUILayout.HelpBox(
                    T("コードやShaderのファイル名変更は、クラス名規約・includeパス・外部ツールを壊す可能性があります。",
                      "Renaming code or shader files can break class-name conventions, include paths, and external tools."),
                    MessageType.Warning);
            }

            EditorGUILayout.HelpBox(
                T("ProjectアセットはAssets配下のメインアセットだけが対象です。Packagesとサブアセットは変更しません。",
                  "Only main assets under Assets are supported. Package and sub-assets are never renamed."),
                MessageType.Info);
            changed = EditorGUI.EndChangeCheck();
            EditorGUILayout.EndVertical();
        }
        EditorGUILayout.EndFoldoutHeaderGroup();
        return changed;
    }

    private void DrawModeSpecificSettings()
    {
        switch (_settings.operationMode)
        {
            case OperationMode.RemoveNonAscii:
                EditorGUILayout.HelpBox(
                    T("名前に含まれる非ASCII文字だけを除去し、ASCII部分を残します。例：Chair_日本語 → Chair_",
                      "Removes only non-ASCII characters and preserves ASCII text. Example: Chair_日本語 -> Chair_"),
                    MessageType.Info);
                _settings.emptyNameFallback = EditorGUILayout.TextField(
                    C("空になった場合", "Fallback for Empty Name",
                      "除去後に名前が空になった場合に使用するASCII名です。",
                      "ASCII fallback used when removal leaves an empty name."),
                    _settings.emptyNameFallback);
                _settings.emptyNameStartNumber = EditorGUILayout.IntField(
                    C("開始番号", "Start Number",
                      "空になった名前へ付ける連番の開始値です。",
                      "Starting number appended to empty-name fallbacks."),
                    _settings.emptyNameStartNumber);
                break;

            case OperationMode.ReplaceNonAsciiName:
                EditorGUILayout.HelpBox(
                    T("非ASCII文字を1文字でも含む名前全体を、指定名と連番へ置換します。",
                      "Replaces the entire name when it contains at least one non-ASCII character."),
                    MessageType.Info);
                _settings.replacementText = EditorGUILayout.TextField(
                    C("置換名", "Replacement Name",
                      "非ASCIIを含む名前全体の置換先です。ASCII名を指定してください。",
                      "ASCII replacement for the entire name."),
                    _settings.replacementText);
                _settings.replacementStartNumber = EditorGUILayout.IntField(
                    C("開始番号", "Start Number", "置換名へ付ける連番の開始値です。", "Starting replacement number."),
                    _settings.replacementStartNumber);
                break;

            case OperationMode.SearchReplace:
                _settings.searchText = EditorGUILayout.TextField(
                    C("検索", "Search", "名前から検索する文字列です。", "Text to find in names."),
                    _settings.searchText);
                _settings.replaceText = EditorGUILayout.TextField(
                    C("置換", "Replace", "空欄にすると検索文字列を削除します。", "Leave empty to delete the search text."),
                    _settings.replaceText);
                break;

            case OperationMode.SequentialRename:
                _settings.sequentialName = EditorGUILayout.TextField(
                    C("基本名", "Base Name", "連番名の基本部分です。", "Base text for sequential names."),
                    _settings.sequentialName);
                _settings.rootStartNumber = EditorGUILayout.IntField(
                    C("選択ルート開始番号", "Selected Root Start",
                      "選択ルートとProjectアセットに使用する開始番号です。",
                      "Starting number for selected roots and Project assets."),
                    _settings.rootStartNumber);
                _settings.childStartNumber = EditorGUILayout.IntField(
                    C("子階層開始番号", "Child Start",
                      "展開された子階層全体で共有する開始番号です。",
                      "Starting number shared by all expanded child objects."),
                    _settings.childStartNumber);
                break;

            case OperationMode.AddAffix:
                _settings.prefixText = EditorGUILayout.TextField(
                    C("接頭辞", "Prefix", "元の名前の前へ追加します。", "Added before the original name."),
                    _settings.prefixText);
                _settings.suffixText = EditorGUILayout.TextField(
                    C("接尾辞", "Suffix", "元の名前の後へ追加します。", "Added after the original name."),
                    _settings.suffixText);
                _settings.addNumberToAffix = EditorGUILayout.Toggle(
                    C("連番を追加", "Add Number", "末尾へ連番を追加します。", "Appends a sequential number."),
                    _settings.addNumberToAffix);
                using (new EditorGUI.DisabledScope(!_settings.addNumberToAffix))
                {
                    _settings.affixStartNumber = EditorGUILayout.IntField(
                        C("開始番号", "Start Number", "付加する連番の開始値です。", "Starting appended number."),
                        _settings.affixStartNumber);
                }
                break;
        }
    }

    private void DrawSelectionSummary()
    {
        _showSelection = EditorGUILayout.BeginFoldoutHeaderGroup(_showSelection, T("現在の選択", "Current Selection"));
        if (_showSelection)
        {
            EditorGUILayout.BeginVertical(GUI.skin.box);
            int sceneCount = 0;
            int assetCount = 0;
            int otherCount = 0;

            foreach (UnityEngine.Object selected in Selection.objects)
            {
                if (selected == null)
                {
                    continue;
                }
                string path = AssetDatabase.GetAssetPath(selected);
                if (!string.IsNullOrEmpty(path))
                {
                    assetCount++;
                }
                else if (selected is GameObject gameObject && gameObject.scene.IsValid())
                {
                    sceneCount++;
                }
                else
                {
                    otherCount++;
                }
            }

            EditorGUILayout.LabelField(T("シーンGameObject", "Scene GameObjects"), sceneCount.ToString());
            EditorGUILayout.LabelField(T("Projectアセット", "Project Assets"), assetCount.ToString());
            if (otherCount > 0)
            {
                EditorGUILayout.LabelField(T("対象外", "Unsupported"), otherCount.ToString());
            }

            if (sceneCount > 0 && assetCount > 0)
            {
                EditorGUILayout.HelpBox(
                    T("シーンとProjectアセットが混在しています。両方を同じプレビューで処理します。",
                      "Scene objects and Project assets are mixed and will be processed in the same preview."),
                    MessageType.Warning);
            }
            EditorGUILayout.EndVertical();
        }
        EditorGUILayout.EndFoldoutHeaderGroup();
    }

    private void DrawActionButtons()
    {
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button(T("プレビューを生成", "Generate Preview"), GUILayout.Height(30f)))
        {
            GeneratePreview();
        }

        bool canApply = _previewItems.Any(item => item.willChange) &&
                        !_previewItems.Any(item => item.HasError) &&
                        IsPreviewCurrent();
        using (new EditorGUI.DisabledScope(!canApply))
        {
            GUI.backgroundColor = new Color(0.55f, 0.9f, 0.65f);
            if (GUILayout.Button(T("プレビューを適用", "Apply Preview"), GUILayout.Height(30f)))
            {
                ApplyPreview();
            }
            GUI.backgroundColor = Color.white;
        }

        using (new EditorGUI.DisabledScope(_history == null || _history.records.Count == 0))
        {
            if (GUILayout.Button(T("前回のアセット名を復元", "Restore Previous Asset Names"), GUILayout.Height(30f)))
            {
                RestorePreviousAssetNames();
            }
        }
        EditorGUILayout.EndHorizontal();
    }

    private void DrawPreviewPanel()
    {
        _showPreview = EditorGUILayout.BeginFoldoutHeaderGroup(_showPreview, T("プレビュー", "Preview"));
        if (_showPreview)
        {
            EditorGUILayout.BeginVertical(GUI.skin.box);
            if (_previewItems.Count == 0)
            {
                EditorGUILayout.HelpBox(
                    T("プレビューはまだ生成されていません。名前変更はプレビューからのみ実行できます。",
                      "No preview has been generated. Renames can only be applied from a preview."),
                    MessageType.Info);
                EditorGUILayout.EndVertical();
                EditorGUILayout.EndFoldoutHeaderGroup();
                return;
            }

            int changeCount = _previewItems.Count(item => item.willChange);
            int warningCount = _previewItems.Count(item => item.HasWarning);
            int errorCount = _previewItems.Count(item => item.HasError);
            EditorGUILayout.LabelField(
                T($"変更 {changeCount} / 警告 {warningCount} / エラー {errorCount}",
                  $"Changes {changeCount} / Warnings {warningCount} / Errors {errorCount}"),
                EditorStyles.boldLabel);

            if (!IsPreviewCurrent())
            {
                EditorGUILayout.HelpBox(
                    T("選択または設定が変わりました。プレビューを再生成してください。",
                      "The selection or settings changed. Generate the preview again."),
                    MessageType.Error);
            }

            _previewScroll = EditorGUILayout.BeginScrollView(_previewScroll, GUILayout.MinHeight(140f), GUILayout.MaxHeight(330f));
            int displayCount = Mathf.Min(_previewItems.Count, MaxPreviewRows);
            for (int i = 0; i < displayCount; i++)
            {
                DrawPreviewItem(_previewItems[i]);
            }
            if (_previewItems.Count > displayCount)
            {
                EditorGUILayout.LabelField(
                    T($"ほか {_previewItems.Count - displayCount} 件", $"{_previewItems.Count - displayCount} more items"),
                    EditorStyles.miniLabel);
            }
            EditorGUILayout.EndScrollView();

            if (GUILayout.Button(T("プレビューを消去", "Clear Preview")))
            {
                InvalidatePreview();
            }
            EditorGUILayout.EndVertical();
        }
        EditorGUILayout.EndFoldoutHeaderGroup();
    }

    private void DrawPreviewItem(PreviewItem item)
    {
        Color previousColor = GUI.backgroundColor;
        if (item.HasError)
        {
            GUI.backgroundColor = new Color(1f, 0.55f, 0.55f);
        }
        else if (item.HasWarning)
        {
            GUI.backgroundColor = new Color(1f, 0.85f, 0.45f);
        }
        else if (item.willChange)
        {
            GUI.backgroundColor = new Color(0.65f, 1f, 0.7f);
        }

        EditorGUILayout.BeginVertical(EditorStyles.helpBox);
        GUI.backgroundColor = previousColor;
        EditorGUILayout.LabelField(GetPreviewKindLabel(item.kind), EditorStyles.miniBoldLabel);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.SelectableLabel(item.beforeName ?? string.Empty, GUILayout.Height(EditorGUIUtility.singleLineHeight));
        GUILayout.Label("→", GUILayout.Width(20f));
        EditorGUILayout.SelectableLabel(item.afterName ?? string.Empty, GUILayout.Height(EditorGUIUtility.singleLineHeight));
        EditorGUILayout.EndHorizontal();

        foreach (string warning in IsJapanese ? item.warningsJa : item.warningsEn)
        {
            EditorGUILayout.HelpBox(warning, MessageType.Warning);
        }
        foreach (string error in IsJapanese ? item.errorsJa : item.errorsEn)
        {
            EditorGUILayout.HelpBox(error, MessageType.Error);
        }
        EditorGUILayout.EndVertical();
    }

    private void DrawResultsPanel()
    {
        _showResults = EditorGUILayout.BeginFoldoutHeaderGroup(_showResults, T("実行結果", "Results"));
        if (_showResults)
        {
            EditorGUILayout.BeginVertical(GUI.skin.box);
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (_statusEntries.Count > 0 && GUILayout.Button(T("結果を消去", "Clear Results"), GUILayout.Width(100f)))
            {
                _statusEntries.Clear();
            }
            EditorGUILayout.EndHorizontal();

            if (_statusEntries.Count == 0)
            {
                EditorGUILayout.LabelField(T("まだ実行結果はありません。", "No execution results yet."), EditorStyles.miniLabel);
            }
            else
            {
                _statusScroll = EditorGUILayout.BeginScrollView(_statusScroll, GUILayout.MinHeight(90f), GUILayout.MaxHeight(220f));
                foreach (StatusEntry status in _statusEntries)
                {
                    EditorGUILayout.HelpBox(T(status.ja, status.en), status.type);
                }
                EditorGUILayout.EndScrollView();
            }
            EditorGUILayout.EndVertical();
        }
        EditorGUILayout.EndFoldoutHeaderGroup();
    }

    private void GeneratePreview()
    {
        _previewItems.Clear();
        _statusEntries.Clear();

        if (!ValidateOperationInputs())
        {
            CapturePreviewSignatures();
            Repaint();
            return;
        }

        List<SceneTarget> sceneTargets = CollectSceneTargets();
        List<AssetTarget> assetTargets = CollectAssetTargets();

        int scenePrimaryCounter = GetPrimaryStartNumber();
        int sceneChildCounter = _settings.childStartNumber;
        int assetCounter = GetPrimaryStartNumber();

        foreach (SceneTarget target in sceneTargets)
        {
            BuildScenePreviewItem(target, ref scenePrimaryCounter, ref sceneChildCounter);
        }
        foreach (AssetTarget target in assetTargets)
        {
            BuildAssetPreviewItem(target, ref assetCounter);
        }

        if (_previewItems.Count == 0)
        {
            AddGlobalPreviewError(
                "対象になるシーンGameObjectまたはProjectアセットが選択されていません。",
                "No supported scene GameObjects or Project assets are selected.");
        }

        ValidateSceneCollisions();
        ValidateAssetCollisions();
        CapturePreviewSignatures();
        Repaint();
    }

    private bool ValidateOperationInputs()
    {
        switch (_settings.operationMode)
        {
            case OperationMode.RemoveNonAscii:
                if (string.IsNullOrWhiteSpace(_settings.emptyNameFallback) || ContainsNonAscii(_settings.emptyNameFallback))
                {
                    AddGlobalPreviewError(
                        "空になった場合の名前には、空でないASCII文字列を指定してください。",
                        "Fallback for empty names must be a non-empty ASCII string.");
                    return false;
                }
                break;

            case OperationMode.ReplaceNonAsciiName:
                if (string.IsNullOrWhiteSpace(_settings.replacementText) || ContainsNonAscii(_settings.replacementText))
                {
                    AddGlobalPreviewError(
                        "置換名には、空でないASCII文字列を指定してください。",
                        "Replacement name must be a non-empty ASCII string.");
                    return false;
                }
                break;

            case OperationMode.SearchReplace:
                if (string.IsNullOrEmpty(_settings.searchText))
                {
                    AddGlobalPreviewError(
                        "検索文字列が空です。",
                        "Search text is empty.");
                    return false;
                }
                break;

            case OperationMode.SequentialRename:
                if (string.IsNullOrWhiteSpace(_settings.sequentialName))
                {
                    AddGlobalPreviewError(
                        "連番リネームの基本名が空です。",
                        "Sequential rename base name is empty.");
                    return false;
                }
                break;

            case OperationMode.AddAffix:
                if (string.IsNullOrEmpty(_settings.prefixText) &&
                    string.IsNullOrEmpty(_settings.suffixText) &&
                    !_settings.addNumberToAffix)
                {
                    AddGlobalPreviewError(
                        "接頭辞、接尾辞、または連番のいずれかを設定してください。",
                        "Set a prefix, suffix, or appended number.");
                    return false;
                }
                break;
        }
        return true;
    }

    private List<SceneTarget> CollectSceneTargets()
    {
        List<GameObject> selectedObjects = Selection.objects
            .OfType<GameObject>()
            .Where(gameObject => gameObject != null &&
                                 gameObject.scene.IsValid() &&
                                 string.IsNullOrEmpty(AssetDatabase.GetAssetPath(gameObject)))
            .GroupBy(gameObject => gameObject.GetInstanceID())
            .Select(group => group.First())
            .OrderBy(gameObject => GetHierarchyPath(gameObject.transform), StringComparer.Ordinal)
            .ToList();

        if (_settings.hierarchyScope == HierarchyScope.SelectedOnly)
        {
            return selectedObjects.Select(gameObject => new SceneTarget { gameObject = gameObject, isRoot = true }).ToList();
        }

        List<GameObject> roots = GetTopLevelSelection(selectedObjects);
        Dictionary<int, SceneTarget> targets = new Dictionary<int, SceneTarget>();
        foreach (GameObject root in roots)
        {
            targets[root.GetInstanceID()] = new SceneTarget { gameObject = root, isRoot = true };
            if (_settings.hierarchyScope == HierarchyScope.DirectChildren)
            {
                foreach (Transform child in root.transform)
                {
                    if (!targets.ContainsKey(child.gameObject.GetInstanceID()))
                    {
                        targets.Add(child.gameObject.GetInstanceID(), new SceneTarget { gameObject = child.gameObject, isRoot = false });
                    }
                }
            }
            else
            {
                foreach (Transform child in root.GetComponentsInChildren<Transform>(true))
                {
                    if (child == root.transform)
                    {
                        continue;
                    }
                    if (!targets.ContainsKey(child.gameObject.GetInstanceID()))
                    {
                        targets.Add(child.gameObject.GetInstanceID(), new SceneTarget { gameObject = child.gameObject, isRoot = false });
                    }
                }
            }
        }

        return targets.Values
            .OrderBy(target => GetHierarchyPath(target.gameObject.transform), StringComparer.Ordinal)
            .ToList();
    }

    private List<AssetTarget> CollectAssetTargets()
    {
        Dictionary<string, AssetTarget> candidates = new Dictionary<string, AssetTarget>(StringComparer.OrdinalIgnoreCase);
        foreach (UnityEngine.Object selected in Selection.objects)
        {
            if (selected == null)
            {
                continue;
            }

            string path = AssetDatabase.GetAssetPath(selected);
            if (string.IsNullOrEmpty(path))
            {
                continue;
            }
            if (AssetDatabase.IsSubAsset(selected))
            {
                PreviewItem ignored = CreateIgnoredItem(selected.name,
                    "サブアセットは安全のため無視します。",
                    "Sub-assets are ignored for safety.");
                _previewItems.Add(ignored);
                continue;
            }

            string guid = AssetDatabase.AssetPathToGUID(path);
            if (string.IsNullOrEmpty(guid) || candidates.ContainsKey(guid))
            {
                continue;
            }
            candidates.Add(guid, new AssetTarget
            {
                guid = guid,
                path = NormalizeAssetPath(path),
                isFolder = AssetDatabase.IsValidFolder(path)
            });
        }

        List<AssetTarget> sorted = candidates.Values
            .OrderBy(target => target.path.Length)
            .ThenBy(target => target.path, StringComparer.OrdinalIgnoreCase)
            .ToList();
        List<AssetTarget> result = new List<AssetTarget>();

        foreach (AssetTarget target in sorted)
        {
            AssetTarget selectedAncestor = result.FirstOrDefault(existing =>
                existing.isFolder && IsAssetPathInside(target.path, existing.path));
            if (selectedAncestor != null)
            {
                PreviewItem ignored = CreateIgnoredItem(target.path,
                    $"選択フォルダー「{selectedAncestor.path}」の中にあるため、二重処理を避けて無視します。",
                    $"Ignored because it is inside selected folder '{selectedAncestor.path}', avoiding duplicate processing.");
                _previewItems.Add(ignored);
                continue;
            }
            result.Add(target);
        }
        return result;
    }

    private void BuildScenePreviewItem(SceneTarget target, ref int primaryCounter, ref int childCounter)
    {
        GameObject gameObject = target.gameObject;
        string before = gameObject.name;
        string after = ComputeName(before, target.isRoot, false, ref primaryCounter, ref childCounter);
        PreviewItem item = new PreviewItem
        {
            kind = PreviewItemKind.SceneObject,
            sceneObject = gameObject,
            beforeName = before,
            afterName = after,
            willChange = !string.Equals(before, after, StringComparison.Ordinal)
        };

        ValidateSceneName(item);
        if (item.willChange)
        {
            AddWarning(item,
                "GameObject名の変更は、AnimationClipなどの階層パス参照を壊す可能性があります。",
                "Renaming a GameObject can break hierarchy-path references such as AnimationClip bindings.");
        }
        _previewItems.Add(item);
    }

    private void BuildAssetPreviewItem(AssetTarget target, ref int primaryCounter)
    {
        string path = target.path;
        string extension = target.isFolder ? string.Empty : Path.GetExtension(path);
        string beforeBase = target.isFolder ? Path.GetFileName(path) : Path.GetFileNameWithoutExtension(path);
        int unusedChildCounter = 0;
        string rawAfterBase = ComputeName(beforeBase, true, true, ref primaryCounter, ref unusedChildCounter);
        string sanitizedAfterBase = SanitizeAssetBaseName(rawAfterBase);
        string directory = NormalizeAssetPath(Path.GetDirectoryName(path));
        string finalPath = CombineAssetPath(directory, sanitizedAfterBase + extension);

        PreviewItem item = new PreviewItem
        {
            kind = target.isFolder ? PreviewItemKind.AssetFolder : PreviewItemKind.AssetFile,
            assetGuid = target.guid,
            originalPath = path,
            finalPath = finalPath,
            assetIsFolder = target.isFolder,
            beforeName = beforeBase + extension,
            afterName = sanitizedAfterBase + extension,
            willChange = !string.Equals(path, finalPath, StringComparison.Ordinal)
        };

        if (!path.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase) && !string.Equals(path, "Assets", StringComparison.OrdinalIgnoreCase))
        {
            AddError(item,
                "Packagesなど、Assets配下以外のアセットは変更できません。",
                "Assets outside the project's Assets folder, including Packages, cannot be renamed.");
        }
        if (string.Equals(path, "Assets", StringComparison.OrdinalIgnoreCase))
        {
            AddError(item,
                "Assetsルートは変更できません。",
                "The Assets root cannot be renamed.");
        }
        if (string.IsNullOrEmpty(sanitizedAfterBase))
        {
            AddError(item,
                "適用後のアセット名が空になります。",
                "The resulting asset name is empty.");
        }
        if (!string.Equals(rawAfterBase, sanitizedAfterBase, StringComparison.Ordinal))
        {
            AddWarning(item,
                $"ファイル名に使用できない文字を除去しました。実際の名前：{sanitizedAfterBase}",
                $"Invalid filename characters were removed. Actual name: {sanitizedAfterBase}");
        }

        string riskyExtension = Path.GetExtension(path);
        if (!target.isFolder && RiskyExtensions.Contains(riskyExtension))
        {
            if (_settings.allowRiskyAssets)
            {
                AddWarning(item,
                    $"危険度の高いアセットです（{riskyExtension}）。クラス名やincludeパス等を確認してください。",
                    $"This is a high-risk asset ({riskyExtension}). Check class names, include paths, and external references.");
            }
            else
            {
                AddError(item,
                    $"安全のため{riskyExtension}アセットのリネームを禁止しています。",
                    $"Renaming {riskyExtension} assets is blocked for safety.");
            }
        }
        if (target.isFolder && item.willChange)
        {
            AddWarning(item,
                "フォルダー名の変更は、文字列で保存されたパスや外部ツールを壊す可能性があります。",
                "Renaming a folder can break string-based paths and external tools.");
        }

        string absolutePath = AssetPathToAbsolute(path);
        if ((File.Exists(absolutePath) || Directory.Exists(absolutePath)) &&
            (File.GetAttributes(absolutePath) & FileAttributes.ReadOnly) != 0)
        {
            AddError(item,
                "アセットが読み取り専用です。",
                "The asset is read-only.");
        }
        string metaPath = absolutePath + ".meta";
        if (File.Exists(metaPath) && (File.GetAttributes(metaPath) & FileAttributes.ReadOnly) != 0)
        {
            AddError(item,
                ".metaファイルが読み取り専用です。",
                "The .meta file is read-only.");
        }

        _previewItems.Add(item);
    }

    private string ComputeName(string before, bool isRoot, bool isAsset, ref int primaryCounter, ref int childCounter)
    {
        switch (_settings.operationMode)
        {
            case OperationMode.RemoveNonAscii:
            {
                string removed = RemoveNonAscii(before);
                if (string.IsNullOrWhiteSpace(removed))
                {
                    string fallback = $"{_settings.emptyNameFallback}_{primaryCounter}";
                    primaryCounter++;
                    return fallback;
                }
                return removed;
            }

            case OperationMode.ReplaceNonAsciiName:
                if (!ContainsNonAscii(before))
                {
                    return before;
                }
                string replacement = $"{_settings.replacementText}_{primaryCounter}";
                primaryCounter++;
                return replacement;

            case OperationMode.SearchReplace:
                return before.Replace(_settings.searchText, _settings.replaceText);

            case OperationMode.SequentialRename:
                if (isAsset || isRoot)
                {
                    string rootName = $"{_settings.sequentialName}_{primaryCounter}";
                    primaryCounter++;
                    return rootName;
                }
                string childName = $"{_settings.sequentialName}_{childCounter}";
                childCounter++;
                return childName;

            case OperationMode.AddAffix:
                string number = _settings.addNumberToAffix ? $"_{primaryCounter}" : string.Empty;
                if (_settings.addNumberToAffix)
                {
                    primaryCounter++;
                }
                return _settings.prefixText + before + _settings.suffixText + number;

            default:
                return before;
        }
    }

    private void ValidateSceneName(PreviewItem item)
    {
        if (string.IsNullOrWhiteSpace(item.afterName))
        {
            AddError(item,
                "適用後のGameObject名が空になります。",
                "The resulting GameObject name is empty.");
        }
        if (item.afterName.IndexOf('/') >= 0 || item.afterName.IndexOf('\\') >= 0)
        {
            AddError(item,
                "GameObject名に / または \\ は使用できません。階層パスが曖昧になります。",
                "GameObject names cannot contain / or \\ because hierarchy paths become ambiguous.");
        }
        if (item.afterName.Any(char.IsControl))
        {
            AddError(item,
                "GameObject名に制御文字は使用できません。",
                "GameObject names cannot contain control characters.");
        }
    }

    private void ValidateSceneCollisions()
    {
        List<PreviewItem> sceneItems = _previewItems
            .Where(item => item.kind == PreviewItemKind.SceneObject && item.sceneObject != null)
            .ToList();
        Dictionary<int, PreviewItem> byInstanceId = sceneItems.ToDictionary(
            item => item.sceneObject.GetInstanceID(),
            item => item);

        foreach (IGrouping<string, PreviewItem> group in sceneItems.GroupBy(GetSceneCollisionKey, StringComparer.Ordinal))
        {
            List<PreviewItem> members = group.ToList();
            if (members.Count <= 1 || !members.Any(item => item.willChange))
            {
                continue;
            }
            foreach (PreviewItem member in members)
            {
                AddError(member,
                    "同じ親の下で適用後の名前が重複します。",
                    "The resulting name is duplicated under the same parent.");
            }
        }

        foreach (PreviewItem item in sceneItems.Where(entry => entry.willChange && !entry.HasError))
        {
            IEnumerable<GameObject> siblings = GetSceneSiblings(item.sceneObject);
            foreach (GameObject sibling in siblings)
            {
                if (sibling == item.sceneObject || !string.Equals(sibling.name, item.afterName, StringComparison.Ordinal))
                {
                    continue;
                }

                if (byInstanceId.TryGetValue(sibling.GetInstanceID(), out PreviewItem siblingPreview) &&
                    siblingPreview.willChange &&
                    !string.Equals(siblingPreview.afterName, item.afterName, StringComparison.Ordinal))
                {
                    continue;
                }

                AddError(item,
                    $"同じ親の下に「{item.afterName}」が既に存在します。",
                    $"A sibling named '{item.afterName}' already exists.");
                break;
            }
        }
    }

    private void ValidateAssetCollisions()
    {
        List<PreviewItem> changedAssets = _previewItems
            .Where(item => (item.kind == PreviewItemKind.AssetFile || item.kind == PreviewItemKind.AssetFolder) && item.willChange)
            .ToList();

        foreach (IGrouping<string, PreviewItem> group in changedAssets.GroupBy(item => item.finalPath, StringComparer.OrdinalIgnoreCase))
        {
            List<PreviewItem> members = group.ToList();
            if (members.Count <= 1)
            {
                continue;
            }
            foreach (PreviewItem member in members)
            {
                AddError(member,
                    $"複数のアセットが同じパス「{member.finalPath}」になります。",
                    $"Multiple assets would use the same path '{member.finalPath}'.");
            }
        }

        HashSet<string> movingGuids = new HashSet<string>(changedAssets.Select(item => item.assetGuid), StringComparer.OrdinalIgnoreCase);
        foreach (PreviewItem item in changedAssets.Where(entry => !entry.HasError))
        {
            string existingGuid = AssetDatabase.AssetPathToGUID(item.finalPath);
            if (!string.IsNullOrEmpty(existingGuid) &&
                !string.Equals(existingGuid, item.assetGuid, StringComparison.OrdinalIgnoreCase) &&
                !movingGuids.Contains(existingGuid))
            {
                AddError(item,
                    $"コピー先パスに別のアセットが存在します：{item.finalPath}",
                    $"Another asset already exists at the target path: {item.finalPath}");
                continue;
            }

            if (string.IsNullOrEmpty(existingGuid))
            {
                string absoluteTarget = AssetPathToAbsolute(item.finalPath);
                if (File.Exists(absoluteTarget) || Directory.Exists(absoluteTarget))
                {
                    AddError(item,
                        $"AssetDatabase外のファイルまたはフォルダーが存在します：{item.finalPath}",
                        $"A file or folder outside AssetDatabase tracking exists at: {item.finalPath}");
                }
            }
        }
    }

    private void ApplyPreview()
    {
        _statusEntries.Clear();
        if (!IsPreviewCurrent())
        {
            AddStatus(MessageType.Error,
                "選択または設定が変更されています。プレビューを再生成してください。",
                "The selection or settings changed. Generate the preview again.");
            return;
        }
        if (_previewItems.Any(item => item.HasError))
        {
            AddStatus(MessageType.Error,
                "プレビューにエラーがあるため適用できません。",
                "The preview contains errors and cannot be applied.");
            return;
        }
        if (!ValidateCurrentPreviewTargets())
        {
            InvalidatePreview();
            AddStatus(MessageType.Error,
                "対象がプレビュー生成後に変更されました。プレビューを再生成してください。",
                "A target changed after preview generation. Generate the preview again.");
            return;
        }

        List<PreviewItem> changedSceneItems = _previewItems
            .Where(item => item.kind == PreviewItemKind.SceneObject && item.willChange)
            .ToList();
        List<PreviewItem> changedAssetItems = _previewItems
            .Where(item => (item.kind == PreviewItemKind.AssetFile || item.kind == PreviewItemKind.AssetFolder) && item.willChange)
            .ToList();
        if (changedSceneItems.Count == 0 && changedAssetItems.Count == 0)
        {
            AddStatus(MessageType.Info, "変更対象はありません。", "There are no changes to apply.");
            return;
        }

        if (!ConfirmApply(changedSceneItems, changedAssetItems))
        {
            AddStatus(MessageType.Info, "適用をキャンセルしました。", "Apply was cancelled.");
            return;
        }

        _isApplying = true;
        try
        {
            if (changedAssetItems.Count > 0)
            {
                List<MoveRequest> requests = changedAssetItems.Select(item => new MoveRequest
                {
                    guid = item.assetGuid,
                    sourcePath = item.originalPath,
                    targetPath = item.finalPath,
                    isFolder = item.assetIsFolder
                }).ToList();

                if (!MoveAssetsTransaction(requests, out string assetError))
                {
                    AddStatus(MessageType.Error,
                        $"アセット名変更に失敗し、可能な範囲で元へ戻しました。\n{assetError}",
                        $"Asset rename failed and was rolled back where possible.\n{assetError}");
                    return;
                }

                _history.records = requests.Select(request => new AssetRenameRecord
                {
                    guid = request.guid,
                    originalPath = request.sourcePath,
                    finalPath = request.targetPath,
                    isFolder = request.isFolder
                }).ToList();
                SaveHistory();
                AddStatus(MessageType.Info,
                    $"Projectアセットを{requests.Count}件変更しました。GUIDと.metaは維持されています。",
                    $"Renamed {requests.Count} Project asset(s). GUIDs and .meta files were preserved.");
            }

            if (changedSceneItems.Count > 0)
            {
                int sceneCount = ApplySceneRenames(changedSceneItems);
                AddStatus(MessageType.Info,
                    $"シーンGameObjectを{sceneCount}件変更しました。Unity Undoで戻せます。",
                    $"Renamed {sceneCount} scene GameObject(s). These changes can be reverted with Unity Undo.");
            }
        }
        finally
        {
            _isApplying = false;
            InvalidatePreview();
            Repaint();
        }
    }

    private bool ConfirmApply(List<PreviewItem> sceneItems, List<PreviewItem> assetItems)
    {
        int folderCount = assetItems.Count(item => item.assetIsFolder);
        int riskyCount = assetItems.Count(item => RiskyExtensions.Contains(Path.GetExtension(item.originalPath)));
        int warningCount = _previewItems.Count(item => item.HasWarning);

        string ja = $"シーンGameObject：{sceneItems.Count}件\nProjectアセット：{assetItems.Count}件";
        string en = $"Scene GameObjects: {sceneItems.Count}\nProject assets: {assetItems.Count}";
        if (warningCount > 0)
        {
            ja += $"\n警告あり：{warningCount}件";
            en += $"\nItems with warnings: {warningCount}";
        }
        if (sceneItems.Count > 0)
        {
            ja += "\n\nGameObject名の変更によりAnimationClip等の階層パス参照が壊れる可能性があります。";
            en += "\n\nRenaming GameObjects can break hierarchy-path references such as AnimationClip bindings.";
        }
        if (folderCount > 0)
        {
            ja += $"\n\nフォルダー名変更：{folderCount}件。文字列パスや外部ツールを確認してください。";
            en += $"\n\nFolder renames: {folderCount}. Check string paths and external tools.";
        }
        if (riskyCount > 0)
        {
            ja += $"\n\nコード・Shader系：{riskyCount}件。コンパイルやincludeパスが壊れる可能性があります。";
            en += $"\n\nCode or shader assets: {riskyCount}. Compilation or include paths may break.";
        }
        ja += "\n\nプレビュー内容を適用しますか？";
        en += "\n\nApply the preview?";

        return EditorUtility.DisplayDialog(
            T("名前変更の最終確認", "Confirm Rename"),
            T(ja, en),
            T("適用", "Apply"),
            T("キャンセル", "Cancel"));
    }

    private bool ValidateCurrentPreviewTargets()
    {
        foreach (PreviewItem item in _previewItems.Where(entry => entry.willChange))
        {
            if (item.kind == PreviewItemKind.SceneObject)
            {
                if (item.sceneObject == null ||
                    !item.sceneObject.scene.IsValid() ||
                    !string.Equals(item.sceneObject.name, item.beforeName, StringComparison.Ordinal))
                {
                    return false;
                }
            }
            else if (item.kind == PreviewItemKind.AssetFile || item.kind == PreviewItemKind.AssetFolder)
            {
                string currentPath = NormalizeAssetPath(AssetDatabase.GUIDToAssetPath(item.assetGuid));
                if (!string.Equals(currentPath, item.originalPath, StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }
        }
        return true;
    }

    private int ApplySceneRenames(List<PreviewItem> sceneItems)
    {
        int undoGroup = Undo.GetCurrentGroup();
        Undo.SetCurrentGroupName("ACM Rename Scene Objects");
        int applied = 0;

        foreach (PreviewItem item in sceneItems
                     .Where(entry => entry.sceneObject != null)
                     .OrderByDescending(entry => GetHierarchyDepth(entry.sceneObject.transform)))
        {
            GameObject gameObject = item.sceneObject;
            try
            {
                Undo.RecordObject(gameObject, "ACM Rename Scene Object");
                gameObject.name = item.afterName;
                EditorUtility.SetDirty(gameObject);
                if (PrefabUtility.IsPartOfPrefabInstance(gameObject))
                {
                    PrefabUtility.RecordPrefabInstancePropertyModifications(gameObject);
                }
                if (gameObject.scene.IsValid())
                {
                    EditorSceneManager.MarkSceneDirty(gameObject.scene);
                }
                applied++;
            }
            catch (Exception exception)
            {
                AddStatus(MessageType.Error,
                    $"GameObject「{item.beforeName}」の変更に失敗しました：{exception.Message}",
                    $"Failed to rename GameObject '{item.beforeName}': {exception.Message}");
                Debug.LogException(exception);
            }
        }

        Undo.CollapseUndoOperations(undoGroup);
        return applied;
    }

    private bool MoveAssetsTransaction(List<MoveRequest> requests, out string error)
    {
        error = string.Empty;
        if (requests.Count == 0)
        {
            return true;
        }

        if (!ValidateMoveRequests(requests, out error))
        {
            return false;
        }

        List<MoveState> states = requests.Select(request => new MoveState
        {
            request = request,
            originalPath = NormalizeAssetPath(AssetDatabase.GUIDToAssetPath(request.guid))
        }).ToList();

        try
        {
            foreach (MoveState state in states)
            {
                string currentPath = NormalizeAssetPath(AssetDatabase.GUIDToAssetPath(state.request.guid));
                string temporaryPath = CreateTemporaryAssetPath(currentPath, state.request.isFolder, state.request.guid);
                string moveError = AssetDatabase.MoveAsset(currentPath, temporaryPath);
                if (!string.IsNullOrEmpty(moveError))
                {
                    throw new InvalidOperationException($"{currentPath} -> {temporaryPath}: {moveError}");
                }
            }

            foreach (MoveState state in states)
            {
                string currentPath = NormalizeAssetPath(AssetDatabase.GUIDToAssetPath(state.request.guid));
                string moveError = AssetDatabase.MoveAsset(currentPath, state.request.targetPath);
                if (!string.IsNullOrEmpty(moveError))
                {
                    throw new InvalidOperationException($"{currentPath} -> {state.request.targetPath}: {moveError}");
                }
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            return true;
        }
        catch (Exception exception)
        {
            error = exception.Message;
            string rollbackError = RollbackMoveStates(states);
            if (!string.IsNullOrEmpty(rollbackError))
            {
                error += "\nRollback: " + rollbackError;
            }
            Debug.LogException(exception);
            return false;
        }
    }

    private bool ValidateMoveRequests(List<MoveRequest> requests, out string error)
    {
        error = string.Empty;
        HashSet<string> guids = new HashSet<string>(requests.Select(request => request.guid), StringComparer.OrdinalIgnoreCase);
        HashSet<string> targets = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (MoveRequest request in requests)
        {
            string currentPath = NormalizeAssetPath(AssetDatabase.GUIDToAssetPath(request.guid));
            if (string.IsNullOrEmpty(currentPath) ||
                !string.Equals(currentPath, NormalizeAssetPath(request.sourcePath), StringComparison.OrdinalIgnoreCase))
            {
                error = $"Asset changed after planning: {request.sourcePath}";
                return false;
            }
            if (!targets.Add(NormalizeAssetPath(request.targetPath)))
            {
                error = $"Duplicate target path: {request.targetPath}";
                return false;
            }

            string targetDirectory = NormalizeAssetPath(Path.GetDirectoryName(request.targetPath));
            if (!AssetDatabase.IsValidFolder(targetDirectory))
            {
                error = $"Target folder does not exist: {targetDirectory}";
                return false;
            }

            string existingGuid = AssetDatabase.AssetPathToGUID(request.targetPath);
            if (!string.IsNullOrEmpty(existingGuid) &&
                !string.Equals(existingGuid, request.guid, StringComparison.OrdinalIgnoreCase) &&
                !guids.Contains(existingGuid))
            {
                error = $"Target path is occupied: {request.targetPath}";
                return false;
            }
        }
        return true;
    }

    private string RollbackMoveStates(List<MoveState> states)
    {
        List<MoveState> movedToRollbackTemp = new List<MoveState>();
        StringBuilder errors = new StringBuilder();

        foreach (MoveState state in states)
        {
            string currentPath = NormalizeAssetPath(AssetDatabase.GUIDToAssetPath(state.request.guid));
            if (string.IsNullOrEmpty(currentPath) || string.Equals(currentPath, state.originalPath, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            string rollbackTemp = CreateTemporaryAssetPath(currentPath, state.request.isFolder, state.request.guid + "_rollback");
            string moveError = AssetDatabase.MoveAsset(currentPath, rollbackTemp);
            if (!string.IsNullOrEmpty(moveError))
            {
                errors.AppendLine($"{currentPath} -> {rollbackTemp}: {moveError}");
            }
            else
            {
                movedToRollbackTemp.Add(state);
            }
        }

        foreach (MoveState state in movedToRollbackTemp)
        {
            string currentPath = NormalizeAssetPath(AssetDatabase.GUIDToAssetPath(state.request.guid));
            string moveError = AssetDatabase.MoveAsset(currentPath, state.originalPath);
            if (!string.IsNullOrEmpty(moveError))
            {
                errors.AppendLine($"{currentPath} -> {state.originalPath}: {moveError}");
            }
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        return errors.ToString().Trim();
    }

    private void RestorePreviousAssetNames()
    {
        if (_history == null || _history.records.Count == 0)
        {
            return;
        }

        if (!EditorUtility.DisplayDialog(
                T("前回のアセット名を復元", "Restore Previous Asset Names"),
                T($"前回変更したProjectアセット{_history.records.Count}件を元のパスへ戻します。実行しますか？",
                  $"Restore {_history.records.Count} Project asset(s) from the last operation to their original paths?"),
                T("復元", "Restore"),
                T("キャンセル", "Cancel")))
        {
            return;
        }

        List<MoveRequest> requests = new List<MoveRequest>();
        foreach (AssetRenameRecord record in _history.records)
        {
            string currentPath = NormalizeAssetPath(AssetDatabase.GUIDToAssetPath(record.guid));
            if (string.IsNullOrEmpty(currentPath))
            {
                AddStatus(MessageType.Error,
                    $"GUIDからアセットを見つけられません：{record.guid}",
                    $"Could not find asset by GUID: {record.guid}");
                return;
            }
            requests.Add(new MoveRequest
            {
                guid = record.guid,
                sourcePath = currentPath,
                targetPath = record.originalPath,
                isFolder = record.isFolder
            });
        }

        _isApplying = true;
        try
        {
            if (MoveAssetsTransaction(requests, out string error))
            {
                AddStatus(MessageType.Info,
                    $"Projectアセット{requests.Count}件を元の名前へ復元しました。",
                    $"Restored {requests.Count} Project asset(s) to their previous names.");
                _history.records.Clear();
                SaveHistory();
                InvalidatePreview();
            }
            else
            {
                AddStatus(MessageType.Error,
                    $"復元に失敗しました。\n{error}",
                    $"Restore failed.\n{error}");
            }
        }
        finally
        {
            _isApplying = false;
            Repaint();
        }
    }

    private bool IsPreviewCurrent()
    {
        return _previewItems.Count > 0 &&
               string.Equals(_previewSelectionSignature, GetSelectionSignature(), StringComparison.Ordinal) &&
               string.Equals(_previewSettingsSignature, GetOperationalSettingsSignature(), StringComparison.Ordinal);
    }

    private void CapturePreviewSignatures()
    {
        _previewSelectionSignature = GetSelectionSignature();
        _previewSettingsSignature = GetOperationalSettingsSignature();
    }

    private string GetSelectionSignature()
    {
        return string.Join("|", Selection.objects
            .Where(selected => selected != null)
            .Select(selected =>
            {
                string path = AssetDatabase.GetAssetPath(selected);
                string guid = string.IsNullOrEmpty(path) ? string.Empty : AssetDatabase.AssetPathToGUID(path);
                return selected.GetInstanceID() + ":" + guid + ":" + NormalizeAssetPath(path);
            })
            .OrderBy(value => value, StringComparer.Ordinal));
    }

    private string GetOperationalSettingsSignature()
    {
        return string.Join("\u001f", new[]
        {
            ((int)_settings.operationMode).ToString(),
            ((int)_settings.hierarchyScope).ToString(),
            _settings.emptyNameFallback ?? string.Empty,
            _settings.emptyNameStartNumber.ToString(),
            _settings.replacementText ?? string.Empty,
            _settings.replacementStartNumber.ToString(),
            _settings.searchText ?? string.Empty,
            _settings.replaceText ?? string.Empty,
            _settings.sequentialName ?? string.Empty,
            _settings.rootStartNumber.ToString(),
            _settings.childStartNumber.ToString(),
            _settings.prefixText ?? string.Empty,
            _settings.suffixText ?? string.Empty,
            _settings.addNumberToAffix.ToString(),
            _settings.affixStartNumber.ToString(),
            _settings.allowRiskyAssets.ToString()
        });
    }

    private int GetPrimaryStartNumber()
    {
        switch (_settings.operationMode)
        {
            case OperationMode.RemoveNonAscii:
                return _settings.emptyNameStartNumber;
            case OperationMode.ReplaceNonAsciiName:
                return _settings.replacementStartNumber;
            case OperationMode.SequentialRename:
                return _settings.rootStartNumber;
            case OperationMode.AddAffix:
                return _settings.affixStartNumber;
            default:
                return 0;
        }
    }

    private static string RemoveNonAscii(string value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return string.Empty;
        }
        StringBuilder builder = new StringBuilder(value.Length);
        foreach (char character in value)
        {
            if (character <= 127)
            {
                builder.Append(character);
            }
        }
        return builder.ToString();
    }

    private static bool ContainsNonAscii(string value)
    {
        return !string.IsNullOrEmpty(value) && value.Any(character => character > 127);
    }

    private static string SanitizeAssetBaseName(string name)
    {
        if (string.IsNullOrEmpty(name))
        {
            return string.Empty;
        }

        HashSet<char> invalidCharacters = new HashSet<char>(Path.GetInvalidFileNameChars());
        StringBuilder builder = new StringBuilder(name.Length);
        foreach (char character in name)
        {
            if (!invalidCharacters.Contains(character) && !char.IsControl(character))
            {
                builder.Append(character);
            }
        }

        string sanitized = builder.ToString().Trim().TrimEnd('.', ' ');
        string[] reservedNames =
        {
            "CON", "PRN", "AUX", "NUL",
            "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
            "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
        };
        if (reservedNames.Contains(sanitized, StringComparer.OrdinalIgnoreCase))
        {
            sanitized = "_" + sanitized;
        }
        return sanitized;
    }

    private static string CreateTemporaryAssetPath(string currentPath, bool isFolder, string token)
    {
        string directory = NormalizeAssetPath(Path.GetDirectoryName(currentPath));
        string extension = isFolder ? string.Empty : Path.GetExtension(currentPath);
        string safeToken = new string((token ?? Guid.NewGuid().ToString("N"))
            .Where(char.IsLetterOrDigit)
            .Take(20)
            .ToArray());
        string desired = CombineAssetPath(directory, "ACM_RENAME_TEMP_" + safeToken + extension);
        return AssetDatabase.GenerateUniqueAssetPath(desired);
    }

    private static IEnumerable<GameObject> GetSceneSiblings(GameObject gameObject)
    {
        Transform parent = gameObject.transform.parent;
        if (parent != null)
        {
            foreach (Transform child in parent)
            {
                yield return child.gameObject;
            }
            yield break;
        }

        foreach (GameObject root in gameObject.scene.GetRootGameObjects())
        {
            yield return root;
        }
    }

    private static string GetSceneCollisionKey(PreviewItem item)
    {
        GameObject gameObject = item.sceneObject;
        int parentId = gameObject.transform.parent == null ? 0 : gameObject.transform.parent.GetInstanceID();
        return gameObject.scene.handle + "|" + parentId + "|" + item.afterName;
    }

    private static List<GameObject> GetTopLevelSelection(List<GameObject> sceneSelection)
    {
        HashSet<Transform> selectedTransforms = new HashSet<Transform>(sceneSelection
            .Where(gameObject => gameObject != null)
            .Select(gameObject => gameObject.transform));
        return sceneSelection
            .Where(gameObject => gameObject != null && !HasSelectedAncestor(gameObject.transform, selectedTransforms))
            .OrderBy(gameObject => GetHierarchyPath(gameObject.transform), StringComparer.Ordinal)
            .ToList();
    }

    private static bool HasSelectedAncestor(Transform transform, HashSet<Transform> selectedTransforms)
    {
        Transform parent = transform.parent;
        while (parent != null)
        {
            if (selectedTransforms.Contains(parent))
            {
                return true;
            }
            parent = parent.parent;
        }
        return false;
    }

    private static string GetHierarchyPath(Transform transform)
    {
        Stack<string> names = new Stack<string>();
        Transform current = transform;
        while (current != null)
        {
            names.Push(current.name);
            current = current.parent;
        }
        return transform.gameObject.scene.handle + ":/" + string.Join("/", names.ToArray());
    }

    private static int GetHierarchyDepth(Transform transform)
    {
        int depth = 0;
        Transform current = transform.parent;
        while (current != null)
        {
            depth++;
            current = current.parent;
        }
        return depth;
    }

    private static string NormalizeAssetPath(string path)
    {
        return string.IsNullOrEmpty(path) ? string.Empty : path.Replace('\\', '/').TrimEnd('/');
    }

    private static string CombineAssetPath(string directory, string name)
    {
        string normalizedDirectory = NormalizeAssetPath(directory);
        return string.IsNullOrEmpty(normalizedDirectory) ? name : normalizedDirectory + "/" + name;
    }

    private static bool IsAssetPathInside(string candidate, string parent)
    {
        string normalizedCandidate = NormalizeAssetPath(candidate);
        string normalizedParent = NormalizeAssetPath(parent) + "/";
        return normalizedCandidate.StartsWith(normalizedParent, StringComparison.OrdinalIgnoreCase);
    }

    private static string AssetPathToAbsolute(string assetPath)
    {
        return Path.GetFullPath(Path.Combine(ProjectRoot, NormalizeAssetPath(assetPath).Replace('/', Path.DirectorySeparatorChar)));
    }

    private PreviewItem CreateIgnoredItem(string name, string warningJa, string warningEn)
    {
        PreviewItem item = new PreviewItem
        {
            kind = PreviewItemKind.Ignored,
            beforeName = name,
            afterName = name,
            willChange = false
        };
        AddWarning(item, warningJa, warningEn);
        return item;
    }

    private void AddGlobalPreviewError(string ja, string en)
    {
        PreviewItem item = new PreviewItem
        {
            kind = PreviewItemKind.Ignored,
            beforeName = T("入力エラー", "Input Error"),
            afterName = string.Empty,
            willChange = false
        };
        AddError(item, ja, en);
        _previewItems.Add(item);
    }

    private static void AddWarning(PreviewItem item, string ja, string en)
    {
        if (!item.warningsJa.Contains(ja))
        {
            item.warningsJa.Add(ja);
        }
        if (!item.warningsEn.Contains(en))
        {
            item.warningsEn.Add(en);
        }
    }

    private static void AddError(PreviewItem item, string ja, string en)
    {
        if (!item.errorsJa.Contains(ja))
        {
            item.errorsJa.Add(ja);
        }
        if (!item.errorsEn.Contains(en))
        {
            item.errorsEn.Add(en);
        }
    }

    private void AddStatus(MessageType type, string ja, string en)
    {
        _statusEntries.Add(new StatusEntry { type = type, ja = ja, en = en });
    }

    private string GetPreviewKindLabel(PreviewItemKind kind)
    {
        switch (kind)
        {
            case PreviewItemKind.SceneObject:
                return T("シーンGameObject", "Scene GameObject");
            case PreviewItemKind.AssetFile:
                return T("Projectアセット", "Project Asset");
            case PreviewItemKind.AssetFolder:
                return T("Projectフォルダー", "Project Folder");
            default:
                return T("対象外／情報", "Ignored / Information");
        }
    }

    private void InvalidatePreview()
    {
        _previewItems.Clear();
        _previewSelectionSignature = string.Empty;
        _previewSettingsSignature = string.Empty;
    }

    private void EnsureData()
    {
        if (_settings == null)
        {
            _settings = new SettingsData();
        }
        if (_history == null)
        {
            _history = new HistoryData();
        }
        if (_history.records == null)
        {
            _history.records = new List<AssetRenameRecord>();
        }
    }

    private void LoadSettings()
    {
        try
        {
            string json = EditorPrefs.GetString(SettingsKey, string.Empty);
            _settings = string.IsNullOrEmpty(json) ? new SettingsData() : JsonUtility.FromJson<SettingsData>(json);
        }
        catch (Exception exception)
        {
            Debug.LogWarning($"ACM Name Sanitizer settings could not be loaded: {exception.Message}");
            _settings = new SettingsData();
        }
        EnsureData();
    }

    private void SaveSettings()
    {
        if (_settings == null)
        {
            return;
        }
        try
        {
            EditorPrefs.SetString(SettingsKey, JsonUtility.ToJson(_settings));
        }
        catch (Exception exception)
        {
            Debug.LogWarning($"ACM Name Sanitizer settings could not be saved: {exception.Message}");
        }
    }

    private void LoadHistory()
    {
        try
        {
            string json = EditorPrefs.GetString(HistoryKey, string.Empty);
            _history = string.IsNullOrEmpty(json) ? new HistoryData() : JsonUtility.FromJson<HistoryData>(json);
        }
        catch (Exception exception)
        {
            Debug.LogWarning($"ACM Name Sanitizer history could not be loaded: {exception.Message}");
            _history = new HistoryData();
        }
        EnsureData();
    }

    private void SaveHistory()
    {
        if (_history == null)
        {
            return;
        }
        try
        {
            EditorPrefs.SetString(HistoryKey, JsonUtility.ToJson(_history));
        }
        catch (Exception exception)
        {
            Debug.LogWarning($"ACM Name Sanitizer history could not be saved: {exception.Message}");
        }
    }
}
