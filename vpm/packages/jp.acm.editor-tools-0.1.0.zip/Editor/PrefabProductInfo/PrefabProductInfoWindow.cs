using System.Globalization;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace ACM
{
    public sealed class PrefabProductInfoWindow : EditorWindow
    {
        private const string WindowTitle = "Prefab Product Info";

        [SerializeField] private GameObject targetPrefab;
        [SerializeField] private bool jp = true;
        [SerializeField] private bool followSelection = true;
        [SerializeField] private Vector2 scroll;
        [SerializeField] private bool specificationFoldout = true;
        [SerializeField] private bool structureFoldout = true;
        [SerializeField] private bool capacityFoldout = true;
        [SerializeField] private bool outputFoldout = true;
        [SerializeField] private string reportText = "";

        private PrefabProductInfo info;
        private string statusMessage = "";

        [MenuItem("Tools/ACM/Prefab Product Info")]
        public static PrefabProductInfoWindow OpenWindow()
        {
            var window = GetWindow<PrefabProductInfoWindow>();
            window.titleContent = new GUIContent(WindowTitle);
            window.minSize = new Vector2(480f, 600f);
            window.Show();
            return window;
        }

        [MenuItem("Assets/ACM/Prefab Product Info", false, 2200)]
        private static void OpenFromAssetsMenu()
        {
            var window = OpenWindow();
            window.UseCurrentSelection(true);
        }

        [MenuItem("Assets/ACM/Prefab Product Info", true)]
        private static bool ValidateOpenFromAssetsMenu()
        {
            return PrefabProductInfoAnalyzer.ResolvePrefabAsset(Selection.activeGameObject) != null;
        }

        private void OnEnable()
        {
            titleContent = new GUIContent(WindowTitle);
            Selection.selectionChanged -= OnSelectionChanged;
            Selection.selectionChanged += OnSelectionChanged;

            EditorApplication.delayCall += InitializeAfterReload;
        }

        private void OnDisable()
        {
            Selection.selectionChanged -= OnSelectionChanged;
            EditorApplication.delayCall -= InitializeAfterReload;
        }

        private void InitializeAfterReload()
        {
            if (this == null)
                return;

            if (targetPrefab != null)
                AnalyzeTarget();
            else
                UseCurrentSelection(false);
        }

        private void OnSelectionChanged()
        {
            if (!followSelection)
                return;

            UseCurrentSelection(false);
        }

        private void OnGUI()
        {
            DrawLanguageToolbar();

            using (var scrollView = new EditorGUILayout.ScrollViewScope(scroll))
            {
                scroll = scrollView.scrollPosition;
                DrawHeader();
                EditorGUILayout.Space(8);
                DrawTargetSection();

                if (info == null)
                {
                    EditorGUILayout.Space(8);
                    EditorGUILayout.HelpBox(
                        T("ProjectまたはHierarchyでPrefabを選択してください。Prefabインスタンスからも元Prefabを取得できます。",
                          "Select a Prefab in the Project or Hierarchy. A Prefab instance is resolved to its source asset."),
                        MessageType.Info);
                    return;
                }

                EditorGUILayout.Space(8);
                DrawSpecificationSection();
                DrawStructureSection();
                DrawCapacitySection();
                DrawOutputSection();

                if (!string.IsNullOrEmpty(statusMessage))
                {
                    EditorGUILayout.Space(6);
                    EditorGUILayout.HelpBox(statusMessage, MessageType.Info);
                }
            }
        }

        private void DrawLanguageToolbar()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                int next = GUILayout.Toolbar(jp ? 0 : 1, new[] { "JP", "EN" }, GUILayout.Width(74));
                bool nextJp = next == 0;
                if (nextJp != jp)
                {
                    jp = nextJp;
                    RefreshReportText();
                }
            }
        }

        private void DrawHeader()
        {
            EditorGUILayout.LabelField(T("Prefab 商品情報", "Prefab Product Info"), EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                T("選択Prefabの描画仕様・構成・参照アセット容量を集計し、BOOTHの商品説明へ貼り付けやすい文章を生成します。",
                  "Collect rendering specs, structure, and referenced asset size from the selected Prefab, then generate product-listing text."),
                MessageType.None);
        }

        private void DrawTargetSection()
        {
            EditorGUILayout.LabelField(T("対象", "Target"), EditorStyles.boldLabel);
            using (new EditorGUILayout.VerticalScope(GUI.skin.box))
            {
                EditorGUI.BeginChangeCheck();
                var selected = (GameObject)EditorGUILayout.ObjectField(
                    C("Prefab", "Prefab",
                      "Prefabアセット、またはHierarchy上のPrefabインスタンスを指定します。",
                      "Assign a Prefab asset or a Prefab instance in the Hierarchy."),
                    targetPrefab,
                    typeof(GameObject),
                    true);

                if (EditorGUI.EndChangeCheck())
                    SetTarget(selected, true);

                EditorGUILayout.Space(4);
                using (new EditorGUILayout.HorizontalScope())
                {
                    followSelection = EditorGUILayout.ToggleLeft(
                        C("選択に追従", "Follow Selection",
                          "ProjectまたはHierarchyの選択がPrefabなら自動で再集計します。",
                          "Automatically re-analyze when a Prefab is selected in the Project or Hierarchy."),
                        followSelection,
                        GUILayout.Width(130));

                    if (GUILayout.Button(T("現在の選択を使用", "Use Current Selection")))
                        UseCurrentSelection(true);

                    using (new EditorGUI.DisabledScope(targetPrefab == null))
                    {
                        if (GUILayout.Button(T("再集計", "Re-analyze"), GUILayout.Width(88)))
                            AnalyzeTarget();
                    }
                }

                if (targetPrefab != null)
                    EditorGUILayout.LabelField(T("アセットパス", "Asset Path"), AssetDatabase.GetAssetPath(targetPrefab), EditorStyles.miniLabel);
            }
        }

        private void DrawSpecificationSection()
        {
            specificationFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(
                specificationFoldout, T("商品仕様", "Product Specifications"));
            if (specificationFoldout)
            {
                using (new EditorGUILayout.VerticalScope(GUI.skin.box))
                {
                    DrawValue(
                        C("ポリゴン数（三角形換算）", "Polygon Count (Triangles)",
                          "MeshRendererとSkinnedMeshRendererが使用するMeshをインスタンス単位で合計します。Quadは三角形2枚として換算します。",
                          "Totals meshes per MeshRenderer and SkinnedMeshRenderer instance. Each quad is converted to two triangles."),
                        FormatNumber(info.triangleCount));
                    DrawValue(
                        C("頂点数", "Vertex Count",
                          "MeshRendererとSkinnedMeshRendererが使用するMeshのvertexCountをインスタンス単位で合計します。",
                          "Totals Mesh.vertexCount per MeshRenderer and SkinnedMeshRenderer instance."),
                        FormatNumber(info.vertexCount));
                    DrawValue(
                        C("メッシュ", "Meshes",
                          "Mesh使用箇所の合計と、重複を除いたMesh数です。",
                          "Total mesh usages and unique mesh assets."),
                        T($"{FormatNumber(info.meshInstanceCount)}（ユニーク {FormatNumber(info.uniqueMeshCount)}）",
                          $"{FormatNumber(info.meshInstanceCount)} (Unique {FormatNumber(info.uniqueMeshCount)})"));
                    DrawValue(
                        C("マテリアル", "Materials",
                          "Rendererへ割り当てられた重複なしのMaterial数と、全スロット数です。",
                          "Unique Materials assigned to Renderers and the total number of material slots."),
                        T($"{FormatNumber(info.uniqueMaterialCount)}（スロット {FormatNumber(info.materialSlotCount)}）",
                          $"{FormatNumber(info.uniqueMaterialCount)} (Slots {FormatNumber(info.materialSlotCount)})"));
                    DrawValue(C("テクスチャ", "Textures", "Prefabの依存関係に含まれる重複なしのTexture数です。", "Unique Texture assets in the Prefab dependencies."),
                        FormatNumber(info.textureCount));
                    DrawValue(C("最大テクスチャ解像度", "Largest Texture Resolution", "画素面積が最大のTextureのインポート解像度です。", "Imported resolution of the Texture with the largest pixel area."),
                        info.textureCount > 0 ? $"{info.maxTextureWidth} x {info.maxTextureHeight}" : "-");
                    DrawValue(C("シェーダー", "Shaders", "割り当てMaterialが使用する重複なしのShader数です。", "Unique Shaders used by assigned Materials."),
                        FormatNumber(info.uniqueShaderCount));
                }
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        private void DrawStructureSection()
        {
            structureFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(
                structureFoldout, T("構成", "Structure"));
            if (structureFoldout)
            {
                using (new EditorGUILayout.VerticalScope(GUI.skin.box))
                {
                    DrawValue(C("GameObject", "GameObjects", "非アクティブを含むPrefab階層内のGameObject数です。", "GameObjects in the Prefab hierarchy, including inactive objects."),
                        FormatNumber(info.gameObjectCount));
                    DrawValue(C("Renderer", "Renderers", "非アクティブを含む全Renderer数です。", "All Renderers, including inactive objects."),
                        FormatNumber(info.rendererCount));
                    DrawValue(C("Skinned Mesh Renderer", "Skinned Mesh Renderers", "非アクティブを含むSkinnedMeshRenderer数です。", "SkinnedMeshRenderers, including inactive objects."),
                        FormatNumber(info.skinnedMeshRendererCount));
                    DrawValue(C("ボーン", "Bones", "SkinnedMeshRendererから参照される重複なしのTransform数です。", "Unique Transforms referenced as bones by SkinnedMeshRenderers."),
                        FormatNumber(info.boneCount));
                    DrawValue(C("BlendShape", "BlendShapes", "SkinnedMeshRendererが使用するMeshのBlendShape数を合計します。", "Total BlendShapes on meshes used by SkinnedMeshRenderers."),
                        FormatNumber(info.blendShapeCount));
                    DrawValue(C("AnimationClip", "Animation Clips", "Prefabの依存関係に含まれる重複なしのAnimationClip数です。", "Unique AnimationClips in the Prefab dependencies."),
                        FormatNumber(info.animationClipCount));
                    DrawValue(C("Collider", "Colliders", "3D Colliderと2D Colliderの合計です。", "Combined count of 3D and 2D Colliders."),
                        FormatNumber(info.colliderCount));
                    DrawValue(C("LOD Group", "LOD Groups", "Prefab階層内のLODGroup数です。", "LODGroups in the Prefab hierarchy."),
                        FormatNumber(info.lodGroupCount));
                    DrawValue(C("Particle System", "Particle Systems", "Prefab階層内のParticleSystem数です。", "ParticleSystems in the Prefab hierarchy."),
                        FormatNumber(info.particleSystemCount));

                    if (info.HasMissingReferences)
                    {
                        EditorGUILayout.Space(4);
                        EditorGUILayout.HelpBox(
                            T($"未設定参照があります。Mesh: {info.missingMeshCount} / Materialスロット: {info.missingMaterialSlotCount}",
                              $"Unassigned references found. Meshes: {info.missingMeshCount} / Material slots: {info.missingMaterialSlotCount}"),
                            MessageType.Warning);
                    }
                }
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        private void DrawCapacitySection()
        {
            capacityFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(
                capacityFoldout, T("容量・依存関係", "Size and Dependencies"));
            if (capacityFoldout)
            {
                using (new EditorGUILayout.VerticalScope(GUI.skin.box))
                {
                    DrawValue(C("Prefabファイル容量", "Prefab File Size", "Prefabファイル本体のソースファイル容量です。", "Source file size of the Prefab file itself."),
                        FormatBytes(info.prefabFileBytes));
                    DrawValue(C("関連アセット総容量", "Referenced Asset Total", "Prefabから再帰参照されるAssets配下のソースファイル合計です。.metaは含みません。", "Total source file size recursively referenced under Assets. .meta files are excluded."),
                        FormatBytes(info.dependencyFileBytes));
                    DrawValue(C("関連アセット", "Referenced Assets", "容量集計対象になったAssets配下のファイル数です。", "Number of files under Assets included in the size total."),
                        FormatNumber(info.sourceAssetCount));
                    DrawValue(C("Package依存パス", "Package Dependency Paths", "Packages配下にある依存アセットパス数です。容量には含めません。", "Dependency asset paths under Packages. Their size is excluded."),
                        FormatNumber(info.packageDependencyCount));
                    DrawValue(C("Prefab種別", "Prefab Type", "Unityが判定したPrefab Asset Typeです。", "Prefab Asset Type reported by Unity."),
                        info.prefabAssetType);

                    EditorGUILayout.Space(4);
                    EditorGUILayout.HelpBox(
                        T("総容量は配布ファイルや実行時メモリの容量ではなく、選択Prefabが参照するAssets配下のソースファイル合計です（重複なし・.meta除外）。",
                          "The total is the unique source-file size under Assets referenced by this Prefab, not download size or runtime memory (.meta files excluded)."),
                        MessageType.None);
                }
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        private void DrawOutputSection()
        {
            outputFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(
                outputFoldout, T("コピー用テキスト", "Copy-ready Text"));
            if (outputFoldout)
            {
                using (new EditorGUILayout.VerticalScope(GUI.skin.box))
                {
                    EditorGUILayout.HelpBox(
                        T("下の文章は編集できます。必要な項目だけ残してからコピーすることもできます。",
                          "The text below is editable. Remove any fields you do not need before copying."),
                        MessageType.None);

                    reportText = EditorGUILayout.TextArea(reportText, GUILayout.MinHeight(230));
                    EditorGUILayout.Space(4);

                    using (new EditorGUILayout.HorizontalScope())
                    {
                        if (GUILayout.Button(T("商品説明用テキストをコピー", "Copy Product Text"), GUILayout.Height(30)))
                            CopyToClipboard(reportText);

                        if (GUILayout.Button("TSV " + T("をコピー", "Copy"), GUILayout.Width(112), GUILayout.Height(30)))
                            CopyToClipboard(BuildTsv());

                        if (GUILayout.Button(T("再生成", "Reset Text"), GUILayout.Width(88), GUILayout.Height(30)))
                            RefreshReportText();
                    }
                }
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        private void SetTarget(GameObject candidate, bool showInvalidMessage)
        {
            if (candidate == null)
            {
                targetPrefab = null;
                info = null;
                reportText = "";
                return;
            }

            var resolved = PrefabProductInfoAnalyzer.ResolvePrefabAsset(candidate);
            if (resolved == null)
            {
                if (showInvalidMessage)
                    statusMessage = T("PrefabアセットまたはPrefabインスタンスを選択してください。", "Select a Prefab asset or Prefab instance.");
                return;
            }

            targetPrefab = resolved;
            AnalyzeTarget();
        }

        private void UseCurrentSelection(bool showInvalidMessage)
        {
            var resolved = PrefabProductInfoAnalyzer.ResolvePrefabAsset(Selection.activeGameObject);
            if (resolved == null)
            {
                if (showInvalidMessage)
                    statusMessage = T("現在の選択からPrefabを取得できませんでした。", "No Prefab could be resolved from the current selection.");
                Repaint();
                return;
            }

            if (resolved == targetPrefab && info != null)
                return;

            targetPrefab = resolved;
            AnalyzeTarget();
        }

        private void AnalyzeTarget()
        {
            if (targetPrefab == null)
            {
                info = null;
                reportText = "";
                return;
            }

            try
            {
                info = PrefabProductInfoAnalyzer.Analyze(targetPrefab);
                RefreshReportText();
                statusMessage = T("集計しました。", "Analysis complete.");
            }
            catch (System.Exception exception)
            {
                info = null;
                reportText = "";
                statusMessage = T("集計に失敗しました。Consoleを確認してください。", "Analysis failed. See the Console for details.");
                Debug.LogException(exception);
            }

            Repaint();
        }

        private void RefreshReportText()
        {
            reportText = info == null ? "" : BuildProductText();
        }

        private string BuildProductText()
        {
            var builder = new StringBuilder();
            builder.AppendLine(T("【Prefab 商品仕様】", "[Prefab Product Specifications]"));
            AppendReportLine(builder, T("Prefab名", "Prefab Name"), info.prefabName);
            AppendReportLine(builder, T("ポリゴン数（三角形換算）", "Polygon Count (Triangles)"), FormatNumber(info.triangleCount));
            AppendReportLine(builder, T("頂点数", "Vertex Count"), FormatNumber(info.vertexCount));
            AppendReportLine(builder, T("メッシュ数", "Meshes"),
                T($"{FormatNumber(info.meshInstanceCount)}（ユニーク {FormatNumber(info.uniqueMeshCount)}）",
                  $"{FormatNumber(info.meshInstanceCount)} (Unique {FormatNumber(info.uniqueMeshCount)})"));
            AppendReportLine(builder, T("マテリアル数", "Materials"),
                T($"{FormatNumber(info.uniqueMaterialCount)}（スロット {FormatNumber(info.materialSlotCount)}）",
                  $"{FormatNumber(info.uniqueMaterialCount)} (Slots {FormatNumber(info.materialSlotCount)})"));
            AppendReportLine(builder, T("テクスチャ数", "Textures"), FormatNumber(info.textureCount));
            AppendReportLine(builder, T("最大テクスチャ解像度", "Largest Texture Resolution"),
                info.textureCount > 0 ? $"{info.maxTextureWidth} x {info.maxTextureHeight}" : "-");
            AppendReportLine(builder, T("シェーダー数", "Shaders"), FormatNumber(info.uniqueShaderCount));
            AppendReportLine(builder, T("関連アセット総容量", "Referenced Asset Total"), FormatBytes(info.dependencyFileBytes));

            builder.AppendLine();
            builder.AppendLine(T("【構成】", "[Structure]"));
            AppendReportLine(builder, "GameObject", FormatNumber(info.gameObjectCount));
            AppendReportLine(builder, "Renderer", FormatNumber(info.rendererCount));
            AppendReportLine(builder, "Skinned Mesh Renderer", FormatNumber(info.skinnedMeshRendererCount));
            AppendReportLine(builder, T("ボーン", "Bones"), FormatNumber(info.boneCount));
            AppendReportLine(builder, "BlendShape", FormatNumber(info.blendShapeCount));
            AppendReportLine(builder, "AnimationClip", FormatNumber(info.animationClipCount));
            AppendReportLine(builder, "Collider", FormatNumber(info.colliderCount));
            AppendReportLine(builder, "LOD Group", FormatNumber(info.lodGroupCount));
            AppendReportLine(builder, "Particle System", FormatNumber(info.particleSystemCount));
            AppendReportLine(builder, T("Prefabファイル容量", "Prefab File Size"), FormatBytes(info.prefabFileBytes));
            AppendReportLine(builder, T("関連アセット数", "Referenced Assets"), FormatNumber(info.sourceAssetCount));
            AppendReportLine(builder, T("外部Package依存パス", "Package Dependency Paths"), FormatNumber(info.packageDependencyCount));
            AppendReportLine(builder, T("Unityバージョン", "Unity Version"), Application.unityVersion);

            builder.AppendLine();
            builder.AppendLine(T(
                "※ポリゴン数と頂点数は、MeshRendererとSkinnedMeshRendererで使用されるMeshをインスタンス単位で合計しています。",
                "* Polygon and vertex counts total meshes per MeshRenderer and SkinnedMeshRenderer instance."));
            builder.AppendLine(T(
                "※マテリアル数はRendererに割り当てられた重複なしの数です。",
                "* Material count is the number of unique Materials assigned to Renderers."));
            builder.Append(T(
                "※総容量はPrefabから再帰参照されるAssets配下のソースファイル合計です（重複なし・.meta除外）。",
                "* Referenced asset total is the unique source-file size recursively referenced under Assets (.meta files excluded)."));

            return builder.ToString();
        }

        private string BuildTsv()
        {
            if (info == null)
                return "";

            var builder = new StringBuilder();
            builder.AppendLine(T("項目\t値", "Field\tValue"));
            AppendTsvLine(builder, T("Prefab名", "Prefab Name"), info.prefabName);
            AppendTsvLine(builder, T("ポリゴン数（三角形換算）", "Polygon Count (Triangles)"), info.triangleCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("頂点数", "Vertex Count"), info.vertexCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("メッシュ使用数", "Mesh Usages"), info.meshInstanceCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("ユニークMesh数", "Unique Meshes"), info.uniqueMeshCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("ユニークMaterial数", "Unique Materials"), info.uniqueMaterialCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("Materialスロット数", "Material Slots"), info.materialSlotCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("Texture数", "Textures"), info.textureCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("最大Texture解像度", "Largest Texture Resolution"),
                info.textureCount > 0 ? $"{info.maxTextureWidth} x {info.maxTextureHeight}" : "-");
            AppendTsvLine(builder, T("Shader数", "Shaders"), info.uniqueShaderCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, "GameObject", info.gameObjectCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, "Renderer", info.rendererCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, "Skinned Mesh Renderer", info.skinnedMeshRendererCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("ボーン", "Bones"), info.boneCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, "BlendShape", info.blendShapeCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, "AnimationClip", info.animationClipCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, "Collider", info.colliderCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, "LOD Group", info.lodGroupCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, "Particle System", info.particleSystemCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("Prefabファイル容量（bytes）", "Prefab File Size (bytes)"), info.prefabFileBytes.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("関連アセット総容量（bytes）", "Referenced Asset Total (bytes)"), info.dependencyFileBytes.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("関連アセット数", "Referenced Assets"), info.sourceAssetCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("Package依存パス", "Package Dependency Paths"), info.packageDependencyCount.ToString(CultureInfo.InvariantCulture));
            AppendTsvLine(builder, T("Prefab種別", "Prefab Type"), info.prefabAssetType);
            AppendTsvLine(builder, T("アセットパス", "Asset Path"), info.prefabPath);
            return builder.ToString().TrimEnd();
        }

        private void CopyToClipboard(string value)
        {
            EditorGUIUtility.systemCopyBuffer = value ?? "";
            statusMessage = T("クリップボードへコピーしました。", "Copied to the clipboard.");
            Repaint();
        }

        private static void DrawValue(GUIContent label, string value)
        {
            EditorGUILayout.LabelField(label, new GUIContent(value));
        }

        private void AppendReportLine(StringBuilder builder, string label, string value)
        {
            if (jp)
                builder.Append("・").Append(label).Append("：").AppendLine(value);
            else
                builder.Append("- ").Append(label).Append(": ").AppendLine(value);
        }

        private static void AppendTsvLine(StringBuilder builder, string label, string value)
        {
            builder.Append(label).Append('\t').AppendLine((value ?? "").Replace("\t", " ").Replace("\r", " ").Replace("\n", " "));
        }

        private static string FormatNumber(long value)
        {
            return value.ToString("N0", CultureInfo.InvariantCulture);
        }

        private static string FormatBytes(long bytes)
        {
            string[] units = { "B", "KB", "MB", "GB", "TB" };
            double value = bytes;
            int unitIndex = 0;
            while (value >= 1024d && unitIndex < units.Length - 1)
            {
                value /= 1024d;
                unitIndex++;
            }

            string formatted = unitIndex == 0
                ? value.ToString("N0", CultureInfo.InvariantCulture)
                : value.ToString(value >= 100d ? "N1" : "N2", CultureInfo.InvariantCulture);
            return $"{formatted} {units[unitIndex]}";
        }

        private string T(string ja, string en)
        {
            return jp ? ja : en;
        }

        private GUIContent C(string ja, string en, string tipJa, string tipEn)
        {
            return new GUIContent(T(ja, en), T(tipJa, tipEn));
        }
    }
}
