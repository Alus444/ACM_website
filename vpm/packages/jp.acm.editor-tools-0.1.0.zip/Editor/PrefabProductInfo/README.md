# Prefab Product Info

## 日本語

選択したPrefabから、BOOTHの商品説明に掲載しやすい技術情報を集計するUnity Editorツールです。

### 開き方

- `Tools > ACM > Prefab Product Info`
- ProjectウィンドウでPrefabを右クリックし、`ACM > Prefab Product Info`

Project上のPrefabアセットまたはHierarchy上のPrefabインスタンスを選択してください。`選択に追従` が有効な場合、選択が変わると自動で再集計します。

`商品説明用テキストをコピー` はBOOTHへ貼り付けやすい文章を、`TSVをコピー` は表計算ソフトへ貼り付けやすい2列データをコピーします。コピー前にプレビュー欄を直接編集できます。

### 集計基準

- ポリゴン数は三角形換算です。MeshRendererとSkinnedMeshRendererが使用するMeshをインスタンス単位で合計します。
- 頂点数もMeshをインスタンス単位で合計します。
- マテリアル数はRendererへ割り当てられたユニークMaterial数です。スロット数も併記します。
- 関連アセット総容量は、Prefabから再帰参照される`Assets`配下のソースファイル合計です。重複ファイルと`.meta`は含みません。
- 総容量は配布zip容量や実行時メモリ容量ではありません。商品説明へ掲載するときは自動生成される注記も併記してください。

## English

This Unity Editor tool collects technical information from a selected Prefab for use in a BOOTH product listing.

### Opening the Tool

- `Tools > ACM > Prefab Product Info`
- Right-click a Prefab in the Project window, then choose `ACM > Prefab Product Info`

Select a Prefab asset in the Project window or a Prefab instance in the Hierarchy. When `Follow Selection` is enabled, the tool re-analyzes automatically as the selection changes.

`Copy Product Text` copies listing-ready prose. `TSV Copy` copies two-column data suitable for a spreadsheet. You can edit the preview directly before copying.

### Counting Rules

- Polygon count is triangle-equivalent and totals meshes per MeshRenderer and SkinnedMeshRenderer instance.
- Vertex count also totals meshes per renderer instance.
- Material count is the number of unique Materials assigned to Renderers. Total slot count is shown separately.
- Referenced asset total is the unique source-file size recursively referenced under `Assets`. Duplicate files and `.meta` files are excluded.
- The total is not the distributed zip size or runtime memory usage. Keep the generated note when publishing the value.
