using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ACM
{
    internal sealed class PrefabProductInfo
    {
        public string prefabName;
        public string prefabPath;
        public string prefabAssetType;

        public int gameObjectCount;
        public int rendererCount;
        public int meshInstanceCount;
        public int uniqueMeshCount;
        public int missingMeshCount;
        public long triangleCount;
        public long vertexCount;

        public int uniqueMaterialCount;
        public int materialSlotCount;
        public int missingMaterialSlotCount;
        public int uniqueShaderCount;

        public int textureCount;
        public int maxTextureWidth;
        public int maxTextureHeight;

        public int skinnedMeshRendererCount;
        public int boneCount;
        public int blendShapeCount;
        public int animationClipCount;
        public int colliderCount;
        public int lodGroupCount;
        public int particleSystemCount;

        public int sourceAssetCount;
        public int packageDependencyCount;
        public long prefabFileBytes;
        public long dependencyFileBytes;

        public bool HasMissingReferences => missingMeshCount > 0 || missingMaterialSlotCount > 0;
    }

    internal static class PrefabProductInfoAnalyzer
    {
        public static GameObject ResolvePrefabAsset(GameObject candidate)
        {
            if (candidate == null)
                return null;

            GameObject source = candidate;
            if (!EditorUtility.IsPersistent(candidate))
            {
                var outermostRoot = PrefabUtility.GetOutermostPrefabInstanceRoot(candidate);
                if (outermostRoot == null)
                    return null;

                source = PrefabUtility.GetCorrespondingObjectFromSource(outermostRoot);
                if (source == null)
                    return null;
            }

            string path = AssetDatabase.GetAssetPath(source);
            if (string.IsNullOrEmpty(path))
                return null;

            var prefabAsset = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (prefabAsset == null || PrefabUtility.GetPrefabAssetType(prefabAsset) == PrefabAssetType.NotAPrefab)
                return null;

            return prefabAsset;
        }

        public static PrefabProductInfo Analyze(GameObject prefabAsset)
        {
            prefabAsset = ResolvePrefabAsset(prefabAsset);
            if (prefabAsset == null)
                throw new ArgumentException("A valid Prefab asset is required.", nameof(prefabAsset));

            string prefabPath = AssetDatabase.GetAssetPath(prefabAsset);
            var info = new PrefabProductInfo
            {
                prefabName = prefabAsset.name,
                prefabPath = prefabPath,
                prefabAssetType = PrefabUtility.GetPrefabAssetType(prefabAsset).ToString(),
                gameObjectCount = prefabAsset.GetComponentsInChildren<Transform>(true).Length,
                colliderCount = prefabAsset.GetComponentsInChildren<Collider>(true).Length
                                + prefabAsset.GetComponentsInChildren<Collider2D>(true).Length,
                lodGroupCount = prefabAsset.GetComponentsInChildren<LODGroup>(true).Length,
                particleSystemCount = prefabAsset.GetComponentsInChildren<ParticleSystem>(true).Length
            };

            var renderers = prefabAsset.GetComponentsInChildren<Renderer>(true);
            info.rendererCount = renderers.Length;

            var uniqueMaterials = new HashSet<Material>();
            var uniqueShaders = new HashSet<Shader>();

            foreach (var renderer in renderers)
            {
                var materials = renderer.sharedMaterials;
                info.materialSlotCount += materials.Length;

                foreach (var material in materials)
                {
                    if (material == null)
                    {
                        info.missingMaterialSlotCount++;
                        continue;
                    }

                    uniqueMaterials.Add(material);
                    if (material.shader != null)
                        uniqueShaders.Add(material.shader);
                }
            }

            info.uniqueMaterialCount = uniqueMaterials.Count;
            info.uniqueShaderCount = uniqueShaders.Count;

            var uniqueMeshes = new HashSet<Mesh>();
            foreach (var meshRenderer in prefabAsset.GetComponentsInChildren<MeshRenderer>(true))
            {
                var meshFilter = meshRenderer.GetComponent<MeshFilter>();
                AddMesh(meshFilter != null ? meshFilter.sharedMesh : null, uniqueMeshes, info);
            }

            var skinnedRenderers = prefabAsset.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            info.skinnedMeshRendererCount = skinnedRenderers.Length;

            var uniqueBones = new HashSet<Transform>();
            foreach (var skinnedRenderer in skinnedRenderers)
            {
                AddMesh(skinnedRenderer.sharedMesh, uniqueMeshes, info);
                if (skinnedRenderer.sharedMesh != null)
                    info.blendShapeCount += skinnedRenderer.sharedMesh.blendShapeCount;

                foreach (var bone in skinnedRenderer.bones)
                {
                    if (bone != null)
                        uniqueBones.Add(bone);
                }
            }

            info.uniqueMeshCount = uniqueMeshes.Count;
            info.boneCount = uniqueBones.Count;

            var textures = new HashSet<Texture>();
            var animationClips = new HashSet<AnimationClip>();
            long largestTextureArea = -1;

            string[] dependencies = AssetDatabase.GetDependencies(prefabPath, true)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();

            foreach (string dependencyPath in dependencies)
            {
                if (dependencyPath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
                {
                    if (TryGetFileSize(dependencyPath, out long fileBytes))
                    {
                        info.sourceAssetCount++;
                        info.dependencyFileBytes += fileBytes;
                        if (string.Equals(dependencyPath, prefabPath, StringComparison.OrdinalIgnoreCase))
                            info.prefabFileBytes = fileBytes;
                    }
                }
                else if (dependencyPath.StartsWith("Packages/", StringComparison.OrdinalIgnoreCase))
                {
                    info.packageDependencyCount++;
                }

                UnityEngine.Object[] assetsAtPath;
                try
                {
                    assetsAtPath = AssetDatabase.LoadAllAssetsAtPath(dependencyPath);
                }
                catch (Exception)
                {
                    continue;
                }

                foreach (var asset in assetsAtPath)
                {
                    if (asset is Texture texture && textures.Add(texture))
                    {
                        long area = (long)texture.width * texture.height;
                        if (area > largestTextureArea)
                        {
                            largestTextureArea = area;
                            info.maxTextureWidth = texture.width;
                            info.maxTextureHeight = texture.height;
                        }
                    }
                    else if (asset is AnimationClip animationClip)
                    {
                        animationClips.Add(animationClip);
                    }
                }
            }

            info.textureCount = textures.Count;
            info.animationClipCount = animationClips.Count;
            return info;
        }

        private static void AddMesh(Mesh mesh, HashSet<Mesh> uniqueMeshes, PrefabProductInfo info)
        {
            if (mesh == null)
            {
                info.missingMeshCount++;
                return;
            }

            info.meshInstanceCount++;
            info.vertexCount += mesh.vertexCount;
            info.triangleCount += GetTriangleCount(mesh);
            uniqueMeshes.Add(mesh);
        }

        private static long GetTriangleCount(Mesh mesh)
        {
            long triangles = 0;
            for (int subMeshIndex = 0; subMeshIndex < mesh.subMeshCount; subMeshIndex++)
            {
                long indexCount;
                MeshTopology topology;
                try
                {
                    indexCount = (long)mesh.GetIndexCount(subMeshIndex);
                    topology = mesh.GetTopology(subMeshIndex);
                }
                catch (Exception)
                {
                    continue;
                }

                if (topology == MeshTopology.Triangles)
                    triangles += indexCount / 3;
                else if (topology == MeshTopology.Quads)
                    triangles += (indexCount / 4) * 2;
            }

            return triangles;
        }

        private static bool TryGetFileSize(string assetPath, out long bytes)
        {
            bytes = 0;
            try
            {
                string projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                string relativePath = assetPath.Replace('/', Path.DirectorySeparatorChar);
                string absolutePath = Path.GetFullPath(Path.Combine(projectRoot, relativePath));
                if (!File.Exists(absolutePath))
                    return false;

                bytes = new FileInfo(absolutePath).Length;
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
