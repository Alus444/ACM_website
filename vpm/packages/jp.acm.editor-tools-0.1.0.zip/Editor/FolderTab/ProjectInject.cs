using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using UnityEditor.UIElements;
using System.Reflection;


[InitializeOnLoad]
static class FolderTabsProjectInject
{
    static FolderTabsProjectInject()
    {
        EditorApplication.delayCall += InstallAll;
        EditorApplication.projectChanged += InstallAll;
        EditorApplication.update += UpdateTick;
    }

    static double last;
    static void UpdateTick()
    {
        if (EditorApplication.timeSinceStartup - last < 1.0) return;
        last = EditorApplication.timeSinceStartup;
        if (!HasInjectedAny()) InstallAll();
    }

    [MenuItem("Tools/ACM/Folder Tabs/Force Inject")]
    static void ForceInject() => InstallAll();

    static bool HasInjectedAny()
    {
        foreach (var win in Resources.FindObjectsOfTypeAll<EditorWindow>())
        {
            if (win.GetType().Name != "ProjectBrowser") continue;
            var root = win.rootVisualElement;
            if (root != null && root.Q<VisualElement>("ACMFolderTabs") != null) return true;
        }
        return false;
    }

    public static void InstallAll()
    {
        int count = 0;
        foreach (var win in Resources.FindObjectsOfTypeAll<EditorWindow>())
        {
            if (win.GetType().Name != "ProjectBrowser") continue;

            var root = win.rootVisualElement;
            if (root == null) continue;
            if (root.Q<VisualElement>("ACMFolderTabs") != null) continue;

            VisualElement target = root;
            string[] candidates = { "BreadCrumbBar", "TopToolbar", "ToolbarContainer", "Header", "SearchToolbar" };
            foreach (var name in candidates)
            {
                var el = root.Q<VisualElement>(name);
                if (el != null && el.parent != null) { target = el.parent; break; }
            }

            var strip = BuildTabsElement();
            strip.name = "ACMFolderTabs";

            if (target.childCount >= 1)
                target.Insert(Mathf.Min(1, target.childCount), strip);
            else
                target.Add(strip);

            count++;
        }

        if (count > 0) Debug.Log($"[FolderTabs] Injected into {count} Project window(s).");
    }


static void OpenFolderInProject(string path, bool focus = true)
{
    if (string.IsNullOrEmpty(path)) return;

    var obj = AssetDatabase.LoadAssetAtPath<Object>(path);
    if (!obj)
    {
        var dir = System.IO.Path.GetDirectoryName(path)?.Replace('\\','/');
        if (!string.IsNullOrEmpty(dir))
            obj = AssetDatabase.LoadAssetAtPath<Object>(dir);
        if (!obj) return;
    }

    if (focus) EditorUtility.FocusProjectWindow();
    Selection.activeObject = obj;

    var pbType = typeof(Editor).Assembly.GetType("UnityEditor.ProjectBrowser");
    if (pbType != null)
    {
        var wins = Resources.FindObjectsOfTypeAll(pbType);
        if (wins != null && wins.Length > 0)
        {
            var win = wins[0];
            var mi = pbType.GetMethod("ShowFolderContents",
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (mi != null)
            {
                mi.Invoke(win, new object[] { obj.GetInstanceID(), true });
                return;
            }
        }
    }

    EditorGUIUtility.PingObject(obj);
}


    static VisualElement BuildTabsElement()
    {
        var baseColor = new Color(0, 0, 0, EditorGUIUtility.isProSkin ? 0.16f : 0.08f);
        var highlight = new Color(0.2f, 0.5f, 1f, 0.15f);
        var bar = new VisualElement();
        bar.style.height = 22;
        bar.style.minHeight = 22;
        bar.style.flexDirection = FlexDirection.Row;
        bar.style.alignItems = Align.Center;
        bar.style.paddingLeft = 4;
        bar.style.paddingRight = 1;
        bar.style.marginTop = -3;
        bar.style.flexShrink = 0;

        bar.pickingMode = PickingMode.Ignore;

        var limiter = new VisualElement();
        limiter.style.flexDirection = FlexDirection.Row;
        limiter.style.flexGrow = 0;
        limiter.style.flexShrink = 0;
        limiter.style.overflow = Overflow.Hidden;
        limiter.pickingMode = PickingMode.Position; 
        limiter.style.backgroundColor = new Color(0.1f, 0.12f, 0.1f, 0.4f); // 可視範囲の色
        limiter.style.borderTopLeftRadius = 4;
        limiter.style.borderTopRightRadius = 4;
        limiter.style.borderBottomLeftRadius = 4;
        limiter.style.borderBottomRightRadius = 4;

        const float limiterH = 20f;
        limiter.style.height = limiterH;

        const float offsetLeft = 40f;
        const float reserveRight = 510f;
        const float minWidth = 200f;
        const float maxWidth = 1200f;

        limiter.style.marginLeft = offsetLeft;

        bar.RegisterCallback<GeometryChangedEvent>(e =>
        {
            var w = Mathf.Clamp(bar.contentRect.width - reserveRight - offsetLeft, minWidth, maxWidth);
            limiter.style.width = w;
        });

        var scroll = new ScrollView(ScrollViewMode.Horizontal);
        scroll.style.flexGrow = 1;
        scroll.style.flexShrink = 1;
        scroll.style.height = limiterH;
        scroll.horizontalScrollerVisibility = ScrollerVisibility.Hidden;
        scroll.verticalScrollerVisibility = ScrollerVisibility.Hidden;
        scroll.style.overflow = Overflow.Hidden;

        scroll.contentContainer.style.paddingLeft = 8;
        scroll.contentContainer.style.alignItems = Align.Center;

        bool DragHasSomething()
        {
            if (DragAndDrop.paths != null && DragAndDrop.paths.Length > 0) return true;
            if (DragAndDrop.objectReferences != null && DragAndDrop.objectReferences.Length > 0) return true;
            return false;
        }

        bar.RegisterCallback<DragUpdatedEvent>(evt =>
        {
            if (!DragHasSomething()) return;
            DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
            evt.StopImmediatePropagation();
        });

        bar.RegisterCallback<DragPerformEvent>(evt =>
        {
            if (!DragHasSomething()) return;
            var added = FolderTabsState.AddFromDragAndDrop();
            DragAndDrop.AcceptDrag();
            bar.style.backgroundColor = baseColor; 
            if (added > 0) Rebuild(scroll);
            evt.StopImmediatePropagation();
        });

        bar.RegisterCallback<DragEnterEvent>(_ => { bar.style.backgroundColor = highlight; });
        bar.RegisterCallback<DragLeaveEvent>(_ => { bar.style.backgroundColor = baseColor; });
        bar.RegisterCallback<DragExitedEvent>(_ => { bar.style.backgroundColor = baseColor; });

        Rebuild(scroll);
        limiter.Add(scroll);
        bar.Add(limiter);
        return bar;
    }

    static void Rebuild(ScrollView scroll)
    {
        scroll.contentContainer.Clear();
        var s = FolderTabsState.LoadOrCreate();

        if (s.tabs.Count == 0)
        {
            var hint = new Label("Projectでフォルダをドラッグ&ドロップで追加");
            hint.style.unityTextAlign = TextAnchor.MiddleLeft;
            hint.style.marginLeft = 6;
            hint.style.color = EditorGUIUtility.isProSkin ? new Color(0.7f, 0.7f, 0.7f) : new Color(0.2f, 0.2f, 0.2f);
            scroll.contentContainer.Add(hint);
            return;
        }

        for (int i = 0; i < s.tabs.Count; i++)
        {
            var idx = i;
            var e = s.tabs[i];

            var wrap = new VisualElement
            {
                style =
                {
                    flexDirection = FlexDirection.Row,
                    marginRight = 4,
                    alignItems = Align.Center
                }
            };

            const float btnH = 16f;
            Button tabBtn;
            try { tabBtn = new ToolbarButton(); } catch { tabBtn = new Button(); }
            tabBtn.text = string.IsNullOrEmpty(e.alias) ? e.path : e.alias;
            tabBtn.tooltip = e.path;
            tabBtn.clicked += () => OpenFolderInProject(e.path);


            tabBtn.style.height = btnH;
            tabBtn.style.marginTop = 0;
            tabBtn.style.marginBottom = 0;
            tabBtn.style.paddingTop = 0;
            tabBtn.style.paddingBottom = 0;

            tabBtn.style.minWidth = 60;
            tabBtn.style.paddingLeft = 8;
            tabBtn.style.paddingRight = 8;
            tabBtn.style.marginRight = -1;
            tabBtn.style.unityTextAlign = TextAnchor.MiddleCenter;
            tabBtn.style.fontSize = 11;
            tabBtn.style.borderBottomLeftRadius = 3;
            tabBtn.style.borderTopLeftRadius = 3;

            Button closeBtn;
            try { closeBtn = new ToolbarButton(); } catch { closeBtn = new Button(); }
            closeBtn.text = "×";
            closeBtn.clicked += () =>
            {
                s.tabs.RemoveAt(idx);
                FolderTabsState.Save(s);
                Rebuild(scroll);
            };
            closeBtn.style.width = 18;
            closeBtn.style.height = btnH;
            closeBtn.style.marginTop = 0;
            closeBtn.style.marginBottom = 0;
            closeBtn.style.paddingTop = 0;
            closeBtn.style.paddingBottom = 0;
            closeBtn.style.unityTextAlign = TextAnchor.MiddleCenter;
            closeBtn.style.fontSize = 12;
            closeBtn.style.borderBottomRightRadius = 3;
            closeBtn.style.borderTopRightRadius = 3;

            wrap.Add(tabBtn);
            wrap.Add(closeBtn);
            scroll.contentContainer.Add(wrap);
        }
    }
}
