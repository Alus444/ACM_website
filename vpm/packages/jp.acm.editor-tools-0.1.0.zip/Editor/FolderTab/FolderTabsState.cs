using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

[System.Serializable]
public class FolderTabEntry
{
    public string alias;
    public string path;
}

public class FolderTabsState : ScriptableObject
{
    public List<FolderTabEntry> tabs = new();

    const string Dir  = "Assets/ACM/Data";
    const string File = Dir + "/FolderTabs.asset";

    public static FolderTabsState LoadOrCreate()
    {
        if (!AssetDatabase.IsValidFolder("Assets/ACM"))
            AssetDatabase.CreateFolder("Assets", "ACM");
        if (!AssetDatabase.IsValidFolder(Dir))
            AssetDatabase.CreateFolder("Assets/ACM", "Data");

        var obj = AssetDatabase.LoadAssetAtPath<FolderTabsState>(File);
        if (!obj)
        {
            obj = CreateInstance<FolderTabsState>();
            AssetDatabase.CreateAsset(obj, File);
            AssetDatabase.SaveAssets();
        }
        return obj;
    }

    public static void Save(FolderTabsState s)
    {
        EditorUtility.SetDirty(s);
        AssetDatabase.SaveAssets();
    }

    public static bool TryAddFromCurrentSelection(out string reason)
    {
        reason = null;

        var guids = Selection.assetGUIDs;
        string path = null;

        if (guids != null && guids.Length > 0)
        {
            path = AssetDatabase.GUIDToAssetPath(guids[0]);
        }
        else
        {
            var o = Selection.activeObject;
            if (o) path = AssetDatabase.GetAssetPath(o);
        }

        if (string.IsNullOrEmpty(path))
        {
            reason = "Projectでフォルダを選択してから追加してください";
            return false;
        }

        if (!AssetDatabase.IsValidFolder(path))
        {
            var dir = Path.GetDirectoryName(path)?.Replace('\\', '/');
            if (!string.IsNullOrEmpty(dir) && AssetDatabase.IsValidFolder(dir))
                path = dir;
        }

        if (!AssetDatabase.IsValidFolder(path))
        {
            reason = "フォルダを選択していないため追加できません";
            return false;
        }

        var s = LoadOrCreate();
        if (s.tabs == null) s.tabs = new List<FolderTabEntry>();
        if (s.tabs.Any(t => t.path == path))
        {
            reason = "すでに登録済みです";
            return false;
        }

        s.tabs.Add(new FolderTabEntry { path = path, alias = Path.GetFileName(path) });
        Save(s);
        return true;
    }

    public static int AddFolders(IEnumerable<string> rawPaths)
    {
        var s = LoadOrCreate();
        if (s.tabs == null) s.tabs = new List<FolderTabEntry>();

        int added = 0;
        foreach (var p in rawPaths.Where(x => !string.IsNullOrEmpty(x)))
        {
            var path = p.Replace('\\', '/');

            if (!AssetDatabase.IsValidFolder(path))
            {
                var dir = Path.GetDirectoryName(path)?.Replace('\\', '/');
                if (string.IsNullOrEmpty(dir) || !AssetDatabase.IsValidFolder(dir)) continue;
                path = dir;
            }

            if (s.tabs.Any(t => t.path == path)) continue;

            s.tabs.Add(new FolderTabEntry
            {
                path = path,
                alias = Path.GetFileName(path)
            });
            added++;
        }

        if (added > 0) Save(s);
        return added;
    }

    public static int AddFromDragAndDrop()
    {
        var list = new List<string>();
        if (DragAndDrop.paths != null && DragAndDrop.paths.Length > 0)
            list.AddRange(DragAndDrop.paths);

        if (list.Count == 0 && DragAndDrop.objectReferences != null)
        {
            foreach (var o in DragAndDrop.objectReferences)
            {
                var p = AssetDatabase.GetAssetPath(o);
                if (!string.IsNullOrEmpty(p)) list.Add(p);
            }
        }

        return AddFolders(list);
    }

    public static void Ping(string path)
    {
        var o = AssetDatabase.LoadAssetAtPath<Object>(path);
        if (!o) return;
        Selection.activeObject = o;
        EditorGUIUtility.PingObject(o);
    }
}
