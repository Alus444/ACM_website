using System.Collections.Generic;
using UnityEngine;

namespace ACM.FolderTabs
{
    [System.Serializable]
    public class FolderTabEntry
    {
        public string alias;
        public string path;
    }

    public class FolderTabsAsset : ScriptableObject
    {
        public List<FolderTabEntry> tabs = new List<FolderTabEntry>();
        public int activeIndex = 0;

        public static FolderTabsAsset LoadOrCreate()
        {
            const string dir  = "Assets/ACM/Data";
            const string path = dir + "/FolderTabs.asset";
            #if UNITY_EDITOR
            if (!UnityEditor.AssetDatabase.IsValidFolder("Assets/ACM"))
                UnityEditor.AssetDatabase.CreateFolder("Assets", "ACM");
            if (!UnityEditor.AssetDatabase.IsValidFolder(dir))
                UnityEditor.AssetDatabase.CreateFolder("Assets/ACM", "Data");
            var obj = UnityEditor.AssetDatabase.LoadAssetAtPath<FolderTabsAsset>(path);
            if (!obj)
            {
                obj = ScriptableObject.CreateInstance<FolderTabsAsset>();
                UnityEditor.AssetDatabase.CreateAsset(obj, path);
                UnityEditor.AssetDatabase.SaveAssets();
            }
            return obj;
            #else
            return null;
            #endif
        }
    }
}
