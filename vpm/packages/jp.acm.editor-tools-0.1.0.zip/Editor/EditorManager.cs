using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

public class EditorManager : EditorWindow
{
    [Serializable]
    private sealed class WindowEntry
    {
        public string category;
        public string label;
        public Type windowType;

        public Vector2 size = new Vector2(390f, 620f);
        public bool includeInTile = true;

        public WindowEntry(
            string category,
            string label,
            Type type,
            float w = 390f,
            float h = 620f,
            bool includeInTile = true)
        {
            this.category = category;
            this.label = label;
            this.windowType = type;
            this.size = new Vector2(w, h);
            this.includeInTile = includeInTile;
        }
    }

    private Vector2 scroll;
    private string search = "";
    private bool groupByCategory = true;

    private const float TileGap = 10f;
    private const float TileOffsetY = 30f;

    private static readonly List<WindowEntry> Entries = new List<WindowEntry>
    {
        new WindowEntry("ACM", "AlignObjects", typeof(AlignObjects), 390, 600),
        new WindowEntry("ACM", "ActiveObjectEditor", typeof(ActiveObjectEditor), 390, 600),
        new WindowEntry("ACM", "MultibyteC_Destroyer", typeof(MultibyteC_Destroyer), 520, 650),
        new WindowEntry("ACM", "SyncFolder", typeof(SyncFolder), 420, 620),
        new WindowEntry("ACM", "PrefabProductInfo", typeof(ACM.PrefabProductInfoWindow), 540, 720),
    };

    [MenuItem("Tools/ACM/EditorManager", false, 1)]
    public static void ShowWindow()
    {
        var w = GetWindow<EditorManager>();
        w.titleContent = new GUIContent("EditorManager");
        w.minSize = new Vector2(260, 180);
        w.Show();
    }

    private void OnGUI()
    {
        DrawHeader();

        using (var sv = new EditorGUILayout.ScrollViewScope(scroll))
        {
            scroll = sv.scrollPosition;

            var list = FilteredEntries();

            if (groupByCategory)
            {
                foreach (var g in list.GroupBy(e => e.category))
                {
                    EditorGUILayout.Space(6);
                    using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                    {
                        EditorGUILayout.LabelField(g.Key, EditorStyles.boldLabel);
                        DrawEntryButtons(g.ToList());
                    }
                }
            }
            else
            {
                DrawEntryButtons(list.ToList());
            }
        }
    }

    private void DrawHeader()
    {
        using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Label("Search", GUILayout.Width(50));
                search = EditorGUILayout.TextField(search);

                groupByCategory = GUILayout.Toggle(groupByCategory, "Group", GUILayout.Width(70));
            }

            EditorGUILayout.Space(4);

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Open All"))
                {
                    foreach (var e in Entries)
                        OpenOrFocus(e);
                }

                if (GUILayout.Button("Tile (Included)"))
                {
                    TileIncludedWindows();
                }

                if (GUILayout.Button("Close All"))
                {
                    CloseAllExisting();
                }
            }
        }
    }

    private IEnumerable<WindowEntry> FilteredEntries()
    {
        if (string.IsNullOrEmpty(search))
            return Entries;

        var s = search.Trim();
        return Entries.Where(e =>
            (e.label?.IndexOf(s, StringComparison.OrdinalIgnoreCase) ?? -1) >= 0 ||
            (e.category?.IndexOf(s, StringComparison.OrdinalIgnoreCase) ?? -1) >= 0 ||
            (e.windowType?.Name?.IndexOf(s, StringComparison.OrdinalIgnoreCase) ?? -1) >= 0
        );
    }

    private void DrawEntryButtons(List<WindowEntry> list)
    {
        foreach (var e in list)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(e.label))
                    OpenOrFocus(e);

                e.includeInTile = GUILayout.Toggle(e.includeInTile, "Tile", GUILayout.Width(50));

                if (GUILayout.Button("X", GUILayout.Width(28)))
                    CloseIfExists(e.windowType);
            }
        }
    }

    private static void OpenOrFocus(WindowEntry e)
    {
        if (e.windowType == null) return;

        var existing = GetExistingWindow(e.windowType);
        if (existing != null)
        {
            existing.Focus();
            return;
        }

        var w = EditorWindow.GetWindow(e.windowType);
        if (w == null) return;

        w.titleContent = new GUIContent(e.label);
        w.minSize = new Vector2(200, 130);
        w.Show();
    }

    private static EditorWindow GetExistingWindow(Type t)
    {
        if (t == null) return null;

        var all = Resources.FindObjectsOfTypeAll(t);
        for (int i = 0; i < all.Length; i++)
        {
            var w = all[i] as EditorWindow;
            if (w == null) continue;
            if (w.GetType() == t) return w;
        }
        return null;
    }

    private void TileIncludedWindows()
    {

        var targets = new List<(WindowEntry entry, EditorWindow win)>();

        foreach (var e in Entries)
        {
            if (!e.includeInTile) continue;

            var w = GetExistingWindow(e.windowType);
            if (w == null)
            {
                OpenOrFocus(e);
                w = GetExistingWindow(e.windowType);
            }

            if (w != null)
                targets.Add((e, w));
        }

        if (targets.Count == 0) return;

        float startX = position.x;
        float startY = position.y + position.height + TileOffsetY;

        float x = startX;
        float y = startY;
        float rowMaxH = 0f;

        foreach (var t in targets)
        {
            var size = t.entry.size;

            t.win.minSize = new Vector2(200, 130);
            t.win.position = new Rect(x, y, size.x, size.y);
            t.win.Show();
            t.win.Focus();

            x += size.x + TileGap;
            rowMaxH = Mathf.Max(rowMaxH, size.y);
        }
    }

    private static void CloseIfExists(Type t)
    {
        var w = GetExistingWindow(t);
        if (w != null) w.Close();
    }

    private static void CloseAllExisting()
    {
        foreach (var e in Entries)
            CloseIfExists(e.windowType);
    }
}
