using UnityEditor;
using UnityEngine;
using System.IO;
using Debug = UnityEngine.Debug;
using System.Collections.Generic;
using System.Diagnostics;
using System;



public class ActiveObjectEditor : EditorWindow
{

    private Vector2 scrollPosition = Vector2.zero;
    private List<string> folderNames = new List<string> { "FBX", "Textures", "Materials" };
    private StaticEditorFlags staticFlags = StaticEditorFlags.ContributeGI;
    private bool usePreset1 = false;
    private bool usePreset2 = false;
    private int selectedLayer = 0;
    private List<string> layerNames = new List<string>();

    private string selectedTag = "";
    private List<GameObject> selectedObjects = new List<GameObject>();

    private Shader selectedShader;
    private GameObject[] selectedGameObjects;
    private Vector2 scrollPosition1;
    private Vector2 scrollPosition2;

    private Material sourceMaterial;




    [MenuItem("Tools/ACM/ActiveObjectEditor")]
    public static void OpenWindow()
    {

        EditorWindow window = GetWindow(typeof(ActiveObjectEditor));
        window.titleContent = new GUIContent("ActiveObjectEditor");
        window.minSize = new Vector2(300, 600);
        window.Show();
    }


    private void OnGUI()
    {
        scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
        EditorGUILayout.BeginVertical("box");
        GUILayout.Label("Folder Names to Create", EditorStyles.boldLabel);

        for (int i = 0; i < folderNames.Count; i++)
        {
            GUILayout.BeginHorizontal();

            folderNames[i] = EditorGUILayout.TextField("Folder " + (i + 1) + ":", folderNames[i]);

            if (GUILayout.Button("Delete", GUILayout.Width(60)))
            {
                DeleteFolderName(i);
            }

            GUILayout.EndHorizontal();
        }
        GUILayout.BeginHorizontal();

        //フォルダを作成
        if (GUILayout.Button("Create Folders"))
        {
            CreateFolders();
        }

        //フォルダを追加
        if (GUILayout.Button("Add", GUILayout.MaxWidth(60f)))
        {
            folderNames.Add("NewFolder");
        }


        GUILayout.EndHorizontal();

        EditorGUILayout.EndVertical();

        EditorGUILayout.BeginVertical("box");
        GUILayout.Label("Active switching of selected objects", EditorStyles.boldLabel);

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Toggle Active"))
        {
            foreach (GameObject selectedObject in Selection.gameObjects)
            {
                Undo.RecordObject(selectedObject, "Toggle Active");
                selectedObject.SetActive(!selectedObject.activeSelf);
            }
        }

        if (GUILayout.Button("Activate"))
        {
            foreach (GameObject selectedObject in Selection.gameObjects)
            {
                if (!selectedObject.activeSelf)
                {
                    Undo.RecordObject(selectedObject, "Activate");
                    selectedObject.SetActive(true);
                }
            }
        }

        if (GUILayout.Button("Deactivate"))
        {
            foreach (GameObject selectedObject in Selection.gameObjects)
            {
                if (selectedObject.activeSelf)
                {
                    Undo.RecordObject(selectedObject, "Deactivate");
                    selectedObject.SetActive(false);
                }
            }
        }
        GUILayout.EndHorizontal();
        EditorGUILayout.EndVertical();

        EditorGUILayout.BeginVertical("box");
        GUILayout.Label("Static Settings", EditorStyles.boldLabel);

        //プリセット1
        bool prevUsePreset1 = usePreset1;
        usePreset1 = EditorGUILayout.Toggle("Use Static1", usePreset1);

        //プリセット2
        bool prevUsePreset2 = usePreset2;
        usePreset2 = EditorGUILayout.Toggle("Use Static2", usePreset2);

        //他のプリセットのチェックを解除
        if (usePreset1 != prevUsePreset1 && usePreset1)
        {
            usePreset2 = false;
        }

        if (usePreset2 != prevUsePreset2 && usePreset2)
        {
            usePreset1 = false;
        }

        //設定の表示と設定
        if (usePreset1)
        {
            staticFlags = StaticEditorFlags.ContributeGI | StaticEditorFlags.BatchingStatic | StaticEditorFlags.OccludeeStatic | StaticEditorFlags.ReflectionProbeStatic;
            GUILayout.Label("Preset 1:\nContribute GI\nOccludee Static\nBatching Static\nReflection Probe Static");
        }
        else if (usePreset2)
        {
            staticFlags = StaticEditorFlags.OccludeeStatic | StaticEditorFlags.BatchingStatic | StaticEditorFlags.ReflectionProbeStatic;
            GUILayout.Label("Preset 2:\nOccludee Static\nBatching Static\nReflection Probe Static");
        }
        else
        {
            staticFlags = (StaticEditorFlags)EditorGUILayout.EnumFlagsField(staticFlags);
        }

        if (GUILayout.Button("Apply Static Settings"))
        {
            ApplyStaticSettings();
        }


        EditorGUILayout.EndVertical();
        EditorGUILayout.Space();
        EditorGUILayout.BeginVertical("box");
        GUILayout.BeginHorizontal();

        EditorGUILayout.BeginVertical("box");
        GUILayout.Label("Layer Select:", EditorStyles.boldLabel);
        GUILayout.BeginHorizontal();

        layerNames.Clear();
        for (int i = 0; i < 32; i++)
        {
            string layerName = LayerMask.LayerToName(i);
            if (!string.IsNullOrEmpty(layerName))
            {
                layerNames.Add(layerName);
            }
        }

        selectedLayer = EditorGUILayout.Popup(selectedLayer, layerNames.ToArray());

        if (GUILayout.Button("Set Layer", GUILayout.MaxWidth(70)))
        {
            SetLayerForSelectedObjects();
        }
        GUILayout.EndHorizontal();
        EditorGUILayout.EndVertical();

        EditorGUILayout.BeginVertical("box");

        GUILayout.Label("Tag Select:  ", EditorStyles.boldLabel);
        GUILayout.BeginHorizontal();
        selectedTag = EditorGUILayout.TagField(selectedTag);

        if (GUILayout.Button("Set Tag", GUILayout.MaxWidth(70)))
        {
            ApplyTag();
        }
        GUILayout.EndHorizontal();
        EditorGUILayout.EndVertical();

        GUILayout.EndHorizontal();
        EditorGUILayout.EndVertical();
        EditorGUILayout.Space();

        EditorGUILayout.BeginVertical("box");
        GUILayout.BeginHorizontal();
        GUILayout.Label("Select shader:", EditorStyles.boldLabel);
        selectedShader = DisplayShaderDropdown(selectedShader);


        selectedGameObjects = Selection.gameObjects;
        GUILayout.EndHorizontal();
        if (selectedGameObjects != null && selectedGameObjects.Length > 0)
        {

            if (GUILayout.Button("Apply"))
            {
                ApplyShaderToAllMaterials(selectedGameObjects);
            }

            EditorGUILayout.Space();

            GUILayout.Label("Materials and shaders contained in the selected object", EditorStyles.boldLabel);
            scrollPosition1 = EditorGUILayout.BeginScrollView(scrollPosition1, GUILayout.ExpandWidth(true));
            foreach (GameObject selectedObject in selectedGameObjects)
            {
                EditorGUILayout.BeginVertical("Box");
                EditorGUILayout.LabelField(selectedObject.name, EditorStyles.boldLabel);
                DisplayMaterials(selectedObject);
                EditorGUILayout.EndVertical();
            }
            EditorGUILayout.EndScrollView();
        }
        else
        {
            EditorGUILayout.HelpBox("No objects selected. Select one or more objects with Renderer components to change materials.", MessageType.Info);
        }

        EditorGUILayout.EndVertical();
        EditorGUILayout.EndScrollView();

    }
    private void ApplyStaticSettings()
    {
        GameObject[] selectedGameObjects = Selection.gameObjects;
        foreach (GameObject go in selectedGameObjects)
        {
            SetStaticRecursively(go, staticFlags);
        }

        UnityEngine.Debug.Log("Static settings applied to selected objects and their children.");
    }

    private void SetStaticRecursively(GameObject go, StaticEditorFlags flags)
    {
        GameObjectUtility.SetStaticEditorFlags(go, flags);
        foreach (Transform child in go.transform)
        {
            SetStaticRecursively(child.gameObject, flags);
        }
    }


    private void DeleteFolderName(int index)
    {
        if (index >= 0 && index < folderNames.Count)
        {
            folderNames.RemoveAt(index);
        }
    }
    private void CreateFolders()
    {
        string activeFolderPath = null;

#if UNITY_2020_1_OR_NEWER
        string[] selectedGUIDs = Selection.assetGUIDs;
        if (selectedGUIDs.Length > 0)
        {
            activeFolderPath = AssetDatabase.GUIDToAssetPath(selectedGUIDs[0]);
        }
#else
        UnityEngine.Object activeObject = Selection.activeObject;
        if (activeObject != null)
        {
            activeFolderPath = AssetDatabase.GetAssetPath(activeObject);
        }
#endif

        if (!string.IsNullOrEmpty(activeFolderPath) && AssetDatabase.IsValidFolder(activeFolderPath))
        {
            foreach (string folderName in folderNames)
            {
                string folderPath = Path.Combine(activeFolderPath, folderName);

                if (!Directory.Exists(folderPath))
                {
                    AssetDatabase.CreateFolder(activeFolderPath, folderName);
                    Debug.Log("Folder created: " + folderPath);
                }
                else
                {
                    Debug.LogWarning("Folder already exists: " + folderPath);
                }
            }
        }
        else
        {
            Debug.LogWarning("No valid folder selected.");
        }
    }

    private void SetLayerForSelectedObjects()
    {
        GameObject[] selectedGameObjects = Selection.gameObjects;
        foreach (GameObject go in selectedGameObjects)
        {
            SetLayerRecursively(go, LayerMask.NameToLayer(layerNames[selectedLayer]));
        }

        UnityEngine.Debug.Log("Layer set for selected objects and their children.");
    }

    private void SetLayerRecursively(GameObject go, int layer)
    {
        go.layer = layer;

        foreach (Transform child in go.transform)
        {
            SetLayerRecursively(child.gameObject, layer);
        }
    }
    private void ApplyTag()
    {
        if (string.IsNullOrEmpty(selectedTag) || Selection.gameObjects.Length == 0)
        {
            return;
        }

        foreach (GameObject obj in Selection.gameObjects)
        {
            SetTagRecursively(obj, selectedTag);
        }

        UnityEngine.Debug.Log("Applied tag '" + selectedTag + "' to selected objects and their children.");
    }

    private void SetTagRecursively(GameObject go, string tag)
    {
        go.tag = tag;
        //子オブジェクトに再帰的にタグを設定
        foreach (Transform child in go.transform)
        {
            SetTagRecursively(child.gameObject, tag);
        }
    }
    private Shader DisplayShaderDropdown(Shader currentShader)
    {
        Shader[] availableShaders = Resources.FindObjectsOfTypeAll<Shader>();
        string[] shaderNames = new string[availableShaders.Length];
        int selectedShaderIndex = -1;

        for (int i = 0; i < availableShaders.Length; i++)
        {
            shaderNames[i] = availableShaders[i].name;
            if (availableShaders[i] == currentShader)
            {
                selectedShaderIndex = i;
            }
        }

        selectedShaderIndex = EditorGUILayout.Popup(selectedShaderIndex, shaderNames);

        if (selectedShaderIndex >= 0 && selectedShaderIndex < availableShaders.Length)
        {
            currentShader = availableShaders[selectedShaderIndex];
        }

        return currentShader;
    }

    private void ApplyShaderToAllMaterials(GameObject[] selectedObjects)
    {
        foreach (GameObject selectedObject in selectedObjects)
        {
            Renderer[] renderers = selectedObject.GetComponentsInChildren<Renderer>();
            if (renderers.Length == 0)
            {
                continue;
            }

            foreach (Renderer renderer in renderers)
            {
                Material[] materials = renderer.sharedMaterials;

                for (int i = 0; i < materials.Length; i++)
                {
                    Material material = materials[i];
                    if (material != null)
                    {
                        material.shader = selectedShader;
                        EditorUtility.SetDirty(material);
                    }
                }
            }
        }

        UnityEngine.Debug.Log("Shader changed for all selected materials.");
    }

    private void DisplayMaterials(GameObject selectedObject)
    {
        Renderer[] renderers = selectedObject.GetComponentsInChildren<Renderer>();

        foreach (Renderer renderer in renderers)
        {
            Material[] materials = renderer.sharedMaterials;

            foreach (Material material in materials)
            {
                if (material != null)
                {
                    EditorGUILayout.BeginHorizontal();
                    EditorGUILayout.LabelField("Material: " + material.name, GUILayout.Width(150));
                    EditorGUILayout.LabelField("Shader: " + material.shader.name);
                    EditorGUILayout.EndHorizontal();
                }
            }
        }
    }

}

