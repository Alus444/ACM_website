﻿using System.Collections.Generic;
using System.Diagnostics;
using UnityEditor;
using UnityEngine;
using System.Linq;
using Random = UnityEngine.Random;
using Debug = UnityEngine.Debug;


public class AlignObjects : EditorWindow
{
    private Vector2 scrollPosition = Vector2.zero;
    private int spacing = 1;
    private float spacingX = 0.0f;
    private float spacingY = 0.0f;
    private float spacingZ = 0.0f;

    private bool alignToXAxis = false;
    private bool alignToYAxis = false;
    private bool alignToZAxis = false;

    private bool applyRandomOffsetX = false;
    private bool applyRandomOffsetY = false;
    private bool applyRandomOffsetZ = false;

    private float minXOffset = -2.0f;
    private float maxXOffset = 2.0f; 
    private float minYOffset = -2.0f;
    private float maxYOffset = 2.0f;
    private float minZOffset = -2.0f;
    private float maxZOffset = 2.0f;

    private Vector3 copiedPosition;

    private float scale = 1.0f;

    private GUIStyle darkLabelStyle;

    private string groupName = "NewGroup";
    private enum GroupPivot { BoundingBoxCenter, Origin, Average };
    private GroupPivot groupPivot = GroupPivot.BoundingBoxCenter;

    private int numberOfCopies = 1;
    private int maxValueCopy = 50;
    private bool overrideMaxValue = false;
    private int ovverrideMaxValueCopy = 10;

    private List<GameObject> copiedObjects = new List<GameObject>();


    private enum Axis
    {
        X,
        Y,
        Z
    }

    private enum AlignAnchor
    {
        Min,
        Center,
        Max
    }


    private enum Alignment
    {
        Left,
        Right,
        Top,
        Bottom,
        Front, //Z最小
        Back   //Z最大
    }


    private Alignment alignment = Alignment.Left;

    private void OnEnable()
    {
        ovverrideMaxValueCopy = maxValueCopy;
    }


    [MenuItem("Tools/ACM/AlignSelectedObjects")]

    public static void OpenWindow()
    {

        EditorWindow window = GetWindow(typeof(AlignObjects));
        window.titleContent = new GUIContent("AlignObjects");
        window.minSize = new Vector2(390, 60);
        window.Show();
    }



    private void OnGUI()
    {
        scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
        EditorGUILayout.BeginVertical("box");
        GUILayout.Label("Align Objects", EditorStyles.boldLabel);

        EditorGUILayout.BeginVertical("box");
        EditorGUILayout.BeginHorizontal();


        EditorGUILayout.BeginVertical("box", GUILayout.Width(90f));
        EditorGUILayout.BeginVertical();
        GUILayout.Label("Active Align", EditorStyles.boldLabel);
        EditorGUIUtility.labelWidth = 60f;
        alignToXAxis = EditorGUILayout.Toggle("X Axis", alignToXAxis);
        alignToYAxis = EditorGUILayout.Toggle("Y Axis", alignToYAxis);
        alignToZAxis = EditorGUILayout.Toggle("Z Axis", alignToZAxis);
        EditorGUIUtility.labelWidth = 0f;
        EditorGUILayout.EndVertical();
        EditorGUILayout.EndVertical();


        EditorGUILayout.BeginVertical("box", GUILayout.Width(65f));
        EditorGUILayout.BeginVertical();
        GUILayout.Label("Random", EditorStyles.boldLabel);
        EditorGUI.BeginDisabledGroup(!alignToXAxis);
        EditorGUILayout.BeginHorizontal();
        GUILayout.Space(20);
        applyRandomOffsetX = EditorGUILayout.Toggle(applyRandomOffsetX);
        EditorGUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        EditorGUI.BeginDisabledGroup(!alignToYAxis);
        EditorGUILayout.BeginHorizontal();
        GUILayout.Space(20);
        applyRandomOffsetY = EditorGUILayout.Toggle(applyRandomOffsetY);
        EditorGUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();

        EditorGUI.BeginDisabledGroup(!alignToZAxis);
        EditorGUILayout.BeginHorizontal();
        GUILayout.Space(20);
        applyRandomOffsetZ = EditorGUILayout.Toggle(applyRandomOffsetZ);
        EditorGUILayout.EndHorizontal();
        EditorGUI.EndDisabledGroup();
        EditorGUILayout.EndVertical();
        EditorGUILayout.EndVertical();


        EditorGUILayout.BeginVertical("box", GUILayout.MinWidth(150f), GUILayout.MaxWidth(2000f));
        GUILayout.Label("Spacing", EditorStyles.boldLabel);

        EditorGUI.BeginDisabledGroup(!alignToXAxis);
        float newSpacingX = EditorGUILayout.Slider(spacingX, -10.0f, 10.0f);
        EditorGUI.EndDisabledGroup();

        EditorGUI.BeginDisabledGroup(!alignToYAxis);
        float newSpacingY = EditorGUILayout.Slider(spacingY, -10.0f, 10.0f);
        EditorGUI.EndDisabledGroup();

        EditorGUI.BeginDisabledGroup(!alignToZAxis);
        float newSpacingZ = EditorGUILayout.Slider(spacingZ, -10.0f, 10.0f);
        EditorGUI.EndDisabledGroup();

        EditorGUILayout.EndVertical();



        EditorGUILayout.EndHorizontal();
        EditorGUILayout.EndVertical();







        EditorGUILayout.BeginVertical("box");
        //スケール調整
        int newSpacing = EditorGUILayout.IntSlider("magnification", spacing, 1, 100);

        EditorGUILayout.EndVertical();


        EditorGUILayout.BeginVertical("box");

        GUILayout.Label("Random Offset", EditorStyles.boldLabel);

        EditorGUILayout.BeginHorizontal();
        EditorGUI.BeginDisabledGroup(!applyRandomOffsetX || !alignToXAxis);
        EditorGUIUtility.labelWidth = 40f;
        GUILayout.Label("XRange");
        EditorGUIUtility.labelWidth = 30f;
        minXOffset = EditorGUILayout.Slider("Min", minXOffset, -10.0f, 10.0f);
        maxXOffset = EditorGUILayout.Slider("Max", maxXOffset, -10.0f, 10.0f);
        EditorGUI.EndDisabledGroup();
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUI.BeginDisabledGroup(!applyRandomOffsetY || !alignToYAxis);
        EditorGUIUtility.labelWidth = 40f;
        GUILayout.Label("YRange");
        EditorGUIUtility.labelWidth = 30f;
        minYOffset = EditorGUILayout.Slider("Min", minYOffset, -10.0f, 10.0f);
        maxYOffset = EditorGUILayout.Slider("Max", maxYOffset, -10.0f, 10.0f);
        EditorGUI.EndDisabledGroup();
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUI.BeginDisabledGroup(!applyRandomOffsetZ || !alignToZAxis);
        EditorGUIUtility.labelWidth = 40f;
        GUILayout.Label("ZRange");
        EditorGUIUtility.labelWidth = 30f;
        minZOffset = EditorGUILayout.Slider("Min", minZOffset, -10.0f, 10.0f);
        maxZOffset = EditorGUILayout.Slider("Max", maxZOffset, -10.0f, 10.0f);
        EditorGUI.EndDisabledGroup();
        EditorGUILayout.EndHorizontal();
        EditorGUIUtility.labelWidth = 0f;
        EditorGUILayout.EndVertical();

        EditorGUILayout.BeginVertical("box");

        float newScale = EditorGUILayout.Slider("Scale:", scale, 0.1f, 10.0f);

        //スライダー変更反映
        if (newSpacing != spacing)
        {
            spacing = newSpacing;
            AlignSelectedObjects();
        }

        if (newSpacingX != spacingX)
        {
            spacingX = newSpacingX;
            AlignSelectedObjects();
        }

        if (newSpacingY != spacingY)
        {
            spacingY = newSpacingY;
            AlignSelectedObjects();
        }

        if (newSpacingZ != spacingZ)
        {
            spacingZ = newSpacingZ;
            AlignSelectedObjects();
        }

        if (newScale != scale)
        {
            scale = newScale;
            OverwriteScaleSelectedObjects();
        }
        EditorGUILayout.EndVertical();

        //コピー周り
        EditorGUILayout.BeginVertical("box");

        GUILayout.Label("Copy selected objects", EditorStyles.boldLabel);

        EditorGUILayout.BeginHorizontal();
        overrideMaxValue = EditorGUILayout.Toggle("Override Max Value", overrideMaxValue);
        EditorGUI.BeginDisabledGroup(!overrideMaxValue);
        maxValueCopy = EditorGUILayout.IntField(maxValueCopy);
        EditorGUI.EndDisabledGroup();
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        numberOfCopies = Mathf.RoundToInt(EditorGUILayout.Slider("Copy", numberOfCopies, 1, maxValueCopy));
        if (!overrideMaxValue)
        {
            maxValueCopy = ovverrideMaxValueCopy;
        }

        if (GUILayout.Button("Apply"))
        {

            CopySelectedObjects();
            SortSelectedObjects();
        }
        EditorGUILayout.EndHorizontal();
        EditorGUILayout.EndVertical();

        if (GUILayout.Button("Sort Selected Objects by Name"))
        {
            SortSelectedObjects2();
        }
        EditorGUILayout.BeginVertical("box");
        GUILayout.Label("Select Alignment", EditorStyles.boldLabel);

        //整列方向
        alignment = (Alignment)EditorGUILayout.EnumPopup("Align Direction", alignment);

        if (GUILayout.Button("Align Selected Objects to Bounding Box"))
        {
            AlignBound();
        }
        //EditorGUILayout.EndVertical();


        GUILayout.Label("Align Selection To Bounds", EditorStyles.boldLabel);

        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("X Min")) AlignSelectionToBounds(Axis.X, AlignAnchor.Min);
        if (GUILayout.Button("X Center")) AlignSelectionToBounds(Axis.X, AlignAnchor.Center);
        if (GUILayout.Button("X Max")) AlignSelectionToBounds(Axis.X, AlignAnchor.Max);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Y Min")) AlignSelectionToBounds(Axis.Y, AlignAnchor.Min);
        if (GUILayout.Button("Y Center")) AlignSelectionToBounds(Axis.Y, AlignAnchor.Center);
        if (GUILayout.Button("Y Max")) AlignSelectionToBounds(Axis.Y, AlignAnchor.Max);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Z Min")) AlignSelectionToBounds(Axis.Z, AlignAnchor.Min);
        if (GUILayout.Button("Z Center")) AlignSelectionToBounds(Axis.Z, AlignAnchor.Center);
        if (GUILayout.Button("Z Max")) AlignSelectionToBounds(Axis.Z, AlignAnchor.Max);
        EditorGUILayout.EndHorizontal();



        EditorGUILayout.EndVertical();

        EditorGUILayout.EndVertical();

        EditorGUILayout.BeginVertical("box");
        GUILayout.Label("Object Reset", EditorStyles.boldLabel);

        int selectReset = 0;

        if (GUILayout.Button("Reset All"))
        {
            selectReset = 0;
            CenterSelectedObject(selectReset);
        }

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Reset centor"))
        {
            selectReset = 1;
            CenterSelectedObject(selectReset);
        }
        if (GUILayout.Button("Reset Rotation"))
        {
            selectReset = 2;
            CenterSelectedObject(selectReset);
        }

        if (GUILayout.Button("Reset Scale"))
        {
            selectReset = 3;
            CenterSelectedObject(selectReset);
        }
        GUILayout.EndHorizontal();

        EditorGUILayout.EndVertical();

        //グループ化

        EditorGUILayout.BeginVertical("box");

        GUILayout.Label("Group Selected Objects", EditorStyles.boldLabel);

        groupName = EditorGUILayout.TextField("Group Name:", groupName);

        groupPivot = (GroupPivot)EditorGUILayout.EnumPopup("Group Pivot:", groupPivot);

        if (GUILayout.Button("Grouping"))
        {
            GroupSelection();
        }
        EditorGUILayout.EndVertical();
        EditorGUILayout.EndScrollView();

    }

    private void AlignSelectedObjects()
    {
        //選択オブジェクト取得
        GameObject[] selectedObjects = Selection.gameObjects;

        if (selectedObjects.Length == 0)
        {
            UnityEngine.Debug.LogWarning("No objects selected.");
            return;
        }

        //0番オブジェクトの座標取得
        Vector3 referencePosition = selectedObjects[0].transform.position;
        int offset = 0;
        float offsetX = 0;
        float offsetY = 0;
        float offsetZ = 0;

        foreach (GameObject obj in selectedObjects)
        {
            Undo.RecordObject(obj.transform, "Align Objects");

            Vector3 newPosition = referencePosition;

            if (alignToXAxis && !applyRandomOffsetX)
            {

                newPosition.x += offsetX;

            }
            else if (alignToXAxis && applyRandomOffsetX)
            {

                newPosition.x += offsetX;
                float randomOffsetX = Random.Range(minXOffset, maxXOffset);
                newPosition.x *= randomOffsetX;

            }


            if (alignToYAxis && !applyRandomOffsetY)
            {

                newPosition.y += offsetY;
            }
            else if (alignToYAxis && applyRandomOffsetY)
            {

                newPosition.y += offsetY;
                float randomOffsetY = Random.Range(minYOffset, maxYOffset);
                newPosition.y *= randomOffsetY;

            }


            if (alignToZAxis && !applyRandomOffsetZ)
            {

                newPosition.z += offsetZ;
            }
            else if (alignToZAxis && applyRandomOffsetZ)
            {
                newPosition.z += offsetZ;
                float randomOffsetZ = Random.Range(minZOffset, maxZOffset);
                newPosition.z *= randomOffsetZ;
            }

            obj.transform.position = newPosition;

            offset = spacing;
            offsetX += spacingX * offset;
            offsetY += spacingY * offset;
            offsetZ += spacingZ * offset;

        }

        SceneView.RepaintAll();
    }
    private void OverwriteScaleSelectedObjects()
    {
        GameObject[] selectedObjects = Selection.gameObjects;

        if (selectedObjects.Length == 0)
        {
            UnityEngine.Debug.LogWarning("No objects selected.");
            return;
        }

        foreach (GameObject obj in selectedObjects)
        {
            Undo.RecordObject(obj.transform, "Overwrite Scale");

            //スライダーでスケールを上書き
            obj.transform.localScale = new Vector3(scale, scale, scale);
        }

        SceneView.RepaintAll();
    }

    private void CenterSelectedObject(int selectReset)
    {
        GameObject[] selectedObjects = Selection.gameObjects;

        if (selectedObjects.Length == 0)
        {
            UnityEngine.Debug.LogWarning("No objects selected.");
            return;
        }

        if (selectReset == 0)
        {
            foreach (GameObject obj in selectedObjects)
            {
                Undo.RecordObject(obj.transform, "Center Object");
                obj.transform.localPosition = Vector3.zero;
                obj.transform.localRotation = Quaternion.identity;
                obj.transform.localScale = Vector3.one;
            }
        }

        if (selectReset == 1)
        {
            foreach (GameObject obj in selectedObjects)
            {
                Undo.RecordObject(obj.transform, "Center Object");
                obj.transform.localPosition = Vector3.zero;

            }

        }

        if (selectReset == 2)
        {
            foreach (GameObject obj in selectedObjects)
            {
                Undo.RecordObject(obj.transform, "Center Object");
                obj.transform.localRotation = Quaternion.identity;

            }

        }

        if (selectReset == 3)
        {
            foreach (GameObject obj in selectedObjects)
            {
                Undo.RecordObject(obj.transform, "Center Object");
                obj.transform.localScale = Vector3.one;

            }

        }
        SceneView.RepaintAll();
    }

    private void AlignBound()
    {
        GameObject[] selectedObjects = Selection.gameObjects;
        if (selectedObjects.Length == 0)
        {
            Debug.LogWarning("No objects selected.");
            return;
        }

        GameObject referenceObject = selectedObjects[0];
        Bounds referenceBounds = GetObjectBounds(referenceObject);
        Vector3 referenceCenter = referenceBounds.center;

        float xOffset = 0f;
        float yOffset = 0f;
        float zOffset = 0f;

        foreach (GameObject obj in selectedObjects)
        {
            Undo.RecordObject(obj.transform, "Move Object");
        }

        foreach (GameObject obj in selectedObjects)
        {
            if (obj == referenceObject)
                continue;

            Bounds objectBounds = GetObjectBounds(obj);
            Vector3 objectCenter = objectBounds.center;
            Vector3 targetPosition = referenceCenter;

            switch (alignment)
            {
                case Alignment.Left:
                    targetPosition.x -= referenceBounds.extents.x + objectBounds.extents.x + xOffset;
                    xOffset += objectBounds.size.x;
                    break;
                case Alignment.Right:
                    targetPosition.x += referenceBounds.extents.x + objectBounds.extents.x + xOffset;
                    xOffset += objectBounds.size.x;
                    break;
                case Alignment.Top:
                    targetPosition.y += referenceBounds.extents.y + objectBounds.extents.y + yOffset;
                    yOffset += objectBounds.size.y;
                    break;
                case Alignment.Bottom:
                    targetPosition.y -= referenceBounds.extents.y + objectBounds.extents.y + yOffset;
                    yOffset += objectBounds.size.y;
                    break;
                case Alignment.Front:
                    targetPosition.z -= referenceBounds.extents.z + objectBounds.extents.z + zOffset;
                    zOffset += objectBounds.size.z;
                    break;
                case Alignment.Back:
                    targetPosition.z += referenceBounds.extents.z + objectBounds.extents.z + zOffset;
                    zOffset += objectBounds.size.z;
                    break;
            }

            Vector3 offsetFromCenter = objectCenter - obj.transform.position;
            Vector3 newPosition = targetPosition - offsetFromCenter;

            if (alignment == Alignment.Left || alignment == Alignment.Right)
            {
                newPosition.y = obj.transform.position.y;
                newPosition.z = obj.transform.position.z;
            }
            else if (alignment == Alignment.Top || alignment == Alignment.Bottom)
            {
                newPosition.x = obj.transform.position.x;
                newPosition.z = obj.transform.position.z;
            }
            else if (alignment == Alignment.Front || alignment == Alignment.Back)
            {
                newPosition.x = obj.transform.position.x;
                newPosition.y = obj.transform.position.y;
            }

            obj.transform.position = newPosition;

            Debug.Log("Aligned " + obj.name + " to the " + alignment + " of its bounding box.");
        }

        SceneView.RepaintAll();
    }


    private void AlignSelectionToBounds(Axis axis, AlignAnchor anchor)
    {
        GameObject[] selectedObjects = Selection.gameObjects;
        if (selectedObjects.Length == 0) return;

        Bounds combinedBounds = GetCombinedBounds(selectedObjects);
        float targetAnchorValue = GetAnchorOffset(combinedBounds, axis, anchor);

        foreach (GameObject obj in selectedObjects)
        {
            Undo.RecordObject(obj.transform, "Align To Bounds");

            Bounds objBounds = GetObjectBounds(obj);
            float objAnchorValue = GetAnchorOffset(objBounds, axis, anchor);
            Vector3 pos = obj.transform.position;

            float delta = targetAnchorValue - objAnchorValue;

            switch (axis)
            {
                case Axis.X:
                    pos.x += delta;
                    break;
                case Axis.Y:
                    pos.y += delta;
                    break;
                case Axis.Z:
                    pos.z += delta;
                    break;
            }

            obj.transform.position = pos;
        }

        SceneView.RepaintAll();
    }


    private float GetAnchorOffset(Bounds bounds, Axis axis, AlignAnchor anchor)
    {
        switch (anchor)
        {
            case AlignAnchor.Min:
                return axis == Axis.X ? bounds.min.x :
                       axis == Axis.Y ? bounds.min.y :
                       bounds.min.z;
            case AlignAnchor.Max:
                return axis == Axis.X ? bounds.max.x :
                       axis == Axis.Y ? bounds.max.y :
                       bounds.max.z;
            case AlignAnchor.Center:
            default:
                return axis == Axis.X ? bounds.center.x :
                       axis == Axis.Y ? bounds.center.y :
                       bounds.center.z;
        }
    }


    private Bounds GetCombinedBounds(GameObject[] objects)
    {
        Renderer[] renderers = objects.SelectMany(obj => obj.GetComponentsInChildren<Renderer>()).ToArray();

        if (renderers.Length == 0)
            return new Bounds(Vector3.zero, Vector3.zero);

        Bounds bounds = renderers[0].bounds;
        for (int i = 1; i < renderers.Length; i++)
        {
            bounds.Encapsulate(renderers[i].bounds);
        }

        return bounds;
    }


    private Bounds GetObjectBounds(GameObject obj)
    {
        Renderer[] renderers = obj.GetComponentsInChildren<Renderer>();

        if (renderers.Length == 0)
        {
            return new Bounds(obj.transform.position, Vector3.zero);
        }

        Bounds combinedBounds = renderers[0].bounds;
        for (int i = 1; i < renderers.Length; i++)
        {
            combinedBounds.Encapsulate(renderers[i].bounds);
        }

        return combinedBounds;
    }


    private void GroupSelection()
    {
        if (Selection.transforms.Length == 0)
        {
            UnityEngine.Debug.LogWarning("No objects selected to group.");
            return;
        }

        Undo.RecordObjects(Selection.transforms, "Group Selection");

        Vector3 groupPosition = Vector3.zero;

        //選択したオブジェクトのバウンディングボックスの中心の平均、原点を計算
        foreach (Transform obj in Selection.transforms)
        {
            if (groupPivot == GroupPivot.BoundingBoxCenter)
            {
                Bounds bounds = GetObjectBounds(obj.gameObject);
                groupPosition += bounds.center;
            }
            else if (groupPivot == GroupPivot.Origin)
            {
                groupPosition = Vector3.zero;
                break;
            }
            else 
            {
                groupPosition += obj.position;
            }
        }

        groupPosition /= Selection.transforms.Length;

        GameObject parent = new GameObject(groupName);
        parent.transform.position = groupPosition;

        foreach (Transform obj in Selection.transforms)
        {
            Undo.SetTransformParent(obj, parent.transform, "Group Selection");
        }

        Selection.activeGameObject = parent;
        UnityEngine.Debug.Log("Grouped " + Selection.transforms.Length + " objects into '" + groupName + "'");
    }

    void CopySelectedObjects()
    {
        GameObject[] selectedObjects = Selection.gameObjects;
        copiedObjects.Clear();

        List<GameObject> originalSelection = new List<GameObject>(selectedObjects);

        for (int i = 0; i < numberOfCopies; i++)
        {
            foreach (GameObject obj in selectedObjects)
            {
                //プレハブ確認
                if (PrefabUtility.IsPartOfPrefabInstance(obj))
                {
                    //プレハブルート取得
                    GameObject prefabRoot = PrefabUtility.GetCorrespondingObjectFromSource(obj);

                    GameObject copiedObject = (GameObject)PrefabUtility.InstantiatePrefab(prefabRoot);

                    copiedObject.name = obj.name + "Copy" + "_" + (i);
                    copiedObjects.Add(copiedObject);
                    Undo.RegisterCreatedObjectUndo(copiedObject, "Copy Selected Object");
                }
                else
                {
                    //プレハブじゃないとき
                    GameObject copiedObject = Instantiate(obj);
                    copiedObject.name = obj.name + "Copy" + "_" + (i); 
                    copiedObjects.Add(copiedObject);
                    Undo.RegisterCreatedObjectUndo(copiedObject, "Copy Selected Object");
                }
            }
        }

        List<GameObject> combinedSelection = new List<GameObject>(originalSelection);
        combinedSelection.AddRange(copiedObjects);

        Selection.objects = combinedSelection.ToArray();
    }

    void SortSelectedObjects()
    {
        GameObject[] selectedObjects = Selection.gameObjects;

        if (selectedObjects.Length == 0)
        {
            Debug.LogWarning("No objects selected.");
            return;
        }

        Transform[] originalParents = new Transform[selectedObjects.Length];
        for (int i = 0; i < selectedObjects.Length; i++)
        {
            originalParents[i] = selectedObjects[i].transform.parent;
        }

        //選択順に並べ替え
        for (int i = 1; i < selectedObjects.Length; i++)
        {
            selectedObjects[i].transform.SetSiblingIndex(selectedObjects[i - 1].transform.GetSiblingIndex() + 1);
        }

        //元の親に戻す
        for (int i = 0; i < selectedObjects.Length; i++)
        {
            selectedObjects[i].transform.SetParent(originalParents[i]);
        }

        //ヒエラルキー更新
        EditorApplication.RepaintHierarchyWindow();
    }

    static void SortSelectedObjects2()
    {
        GameObject[] selectedObjects = Selection.gameObjects;

        if (selectedObjects.Length == 0)
        {
            Debug.LogWarning("No objects selected for sorting.");
            return;
        }

        //最初に選択したオブジェクトの位置を取得
        Transform referenceTransform = selectedObjects[0].transform;
        int referenceSiblingIndex = referenceTransform.GetSiblingIndex();
        Transform parentTransform = referenceTransform.parent;

        System.Array.Sort(selectedObjects, (a, b) =>
        {
            string aName = a.name;
            string bName = b.name;

            //末尾から数字比較
            int aNumber, bNumber;
            int aIndex = aName.LastIndexOf('_');
            int bIndex = bName.LastIndexOf('_');
            if (aIndex != -1 && bIndex != -1)
            {
                if (!int.TryParse(aName.Substring(aIndex + 1), out aNumber))
                {
                    aNumber = int.MaxValue; // 数字に変換できない場合は最大値とする
                }
                if (!int.TryParse(bName.Substring(bIndex + 1), out bNumber))
                {
                    bNumber = int.MaxValue;
                }

                aName = aName.Substring(0, aIndex);
                bName = bName.Substring(0, bIndex);
            }
            else
            {
                aNumber = bNumber = int.MaxValue;
            }

            //名前の比較
            int nameComparison = string.Compare(aName, bName);
            if (nameComparison == 0)
            {
                //名前が同じ場合は数字で比較
                return aNumber.CompareTo(bNumber);
            }
            else
            {
                return nameComparison;
            }
        });

        //ソート後オブジェクト再配置
        foreach (var obj in selectedObjects)
        {
            obj.transform.SetAsLastSibling();
        }
        Selection.objects = selectedObjects;
    }


}