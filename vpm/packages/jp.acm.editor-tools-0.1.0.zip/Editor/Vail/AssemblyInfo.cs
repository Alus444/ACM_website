using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ACM.Vail.Editor.Tests")]
