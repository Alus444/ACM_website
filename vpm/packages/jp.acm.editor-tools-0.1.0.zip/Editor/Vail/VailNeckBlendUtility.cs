using System;
using System.Collections.Generic;
using Unity.Collections;
using UnityEditor;
using UnityEngine;

namespace ACM
{
    internal enum VailNeckBlendMode
    {
        Automatic = 0,
        HeadNeckWeights = 1,
        HeadNeckPlane = 2,
        ManualUv = 3,
        UvBoundary = 4
    }

    internal enum VailNeckBlendSource
    {
        Disabled = 0,
        HeadNeckWeights = 1,
        HeadNeckPlane = 2,
        ManualUv = 3,
        UvBoundary = 4
    }

    internal readonly struct VailNeckBlendVertexData
    {
        public VailNeckBlendVertexData(float[] values, VailNeckBlendSource source, string diagnostic)
        {
            Values = values;
            Source = source;
            Diagnostic = diagnostic;
        }

        public bool IsValid => Values != null;
        public float[] Values { get; }
        public VailNeckBlendSource Source { get; }
        public string Diagnostic { get; }
    }

    internal static class VailNeckBlendUtility
    {
        private const float MinimumWeightRange = 0.02f;

        public static VailNeckBlendVertexData Build(
            Mesh mesh,
            SkinnedMeshRenderer skinnedMeshRenderer,
            int uvChannel,
            VailNeckBlendMode mode,
            float offset,
            float width,
            float manualUvAngle,
            bool invert,
            IReadOnlyList<int> relevantVertexIndices = null,
            IReadOnlyList<int> relevantTriangleIndices = null)
        {
            if (mesh == null || mesh.vertexCount == 0)
            {
                return new VailNeckBlendVertexData(null, VailNeckBlendSource.Disabled, "Mesh has no vertices.");
            }

            if (mode == VailNeckBlendMode.Automatic)
            {
                if (TryBuildHeadNeckWeights(mesh, skinnedMeshRenderer, relevantVertexIndices, offset, width, invert, out var values, out var diagnostic))
                {
                    return new VailNeckBlendVertexData(values, VailNeckBlendSource.HeadNeckWeights, diagnostic);
                }

                float[] constrainedPlaneValues = null;
                string constrainedPlaneDiagnostic = null;
                if (TryBuildHeadNeckPlane(mesh, skinnedMeshRenderer, relevantVertexIndices, offset, width, invert, out values, out diagnostic))
                {
                    if (diagnostic.IndexOf("center was constrained", StringComparison.Ordinal) < 0)
                    {
                        return new VailNeckBlendVertexData(values, VailNeckBlendSource.HeadNeckPlane, diagnostic);
                    }

                    // A large anatomical-plane correction is useful as a last-resort safety net,
                    // but the actual neck-side UV perimeter is generally a better boundary.
                    constrainedPlaneValues = values;
                    constrainedPlaneDiagnostic = diagnostic;
                }

                if (TryBuildUvBoundary(
                        mesh,
                        skinnedMeshRenderer,
                        uvChannel,
                        relevantVertexIndices,
                        relevantTriangleIndices,
                        offset,
                        width,
                        manualUvAngle,
                        invert,
                        out values,
                        out diagnostic))
                {
                    return new VailNeckBlendVertexData(values, VailNeckBlendSource.UvBoundary, diagnostic);
                }

                if (constrainedPlaneValues != null)
                {
                    return new VailNeckBlendVertexData(
                        constrainedPlaneValues,
                        VailNeckBlendSource.HeadNeckPlane,
                        constrainedPlaneDiagnostic);
                }

                if (TryBuildManualUv(mesh, uvChannel, offset, width, manualUvAngle, invert, out values, out diagnostic))
                {
                    return new VailNeckBlendVertexData(values, VailNeckBlendSource.ManualUv, diagnostic);
                }

                return new VailNeckBlendVertexData(null, VailNeckBlendSource.Disabled, diagnostic);
            }

            if (mode == VailNeckBlendMode.HeadNeckWeights)
            {
                return TryBuildHeadNeckWeights(mesh, skinnedMeshRenderer, relevantVertexIndices, offset, width, invert, out var values, out var diagnostic)
                    ? new VailNeckBlendVertexData(values, VailNeckBlendSource.HeadNeckWeights, diagnostic)
                    : new VailNeckBlendVertexData(null, VailNeckBlendSource.Disabled, diagnostic);
            }

            if (mode == VailNeckBlendMode.HeadNeckPlane)
            {
                return TryBuildHeadNeckPlane(mesh, skinnedMeshRenderer, relevantVertexIndices, offset, width, invert, out var values, out var diagnostic)
                    ? new VailNeckBlendVertexData(values, VailNeckBlendSource.HeadNeckPlane, diagnostic)
                    : new VailNeckBlendVertexData(null, VailNeckBlendSource.Disabled, diagnostic);
            }

            if (mode == VailNeckBlendMode.UvBoundary)
            {
                return TryBuildUvBoundary(
                        mesh,
                        skinnedMeshRenderer,
                        uvChannel,
                        relevantVertexIndices,
                        relevantTriangleIndices,
                        offset,
                        width,
                        manualUvAngle,
                        invert,
                        out var values,
                        out var diagnostic)
                    ? new VailNeckBlendVertexData(values, VailNeckBlendSource.UvBoundary, diagnostic)
                    : new VailNeckBlendVertexData(null, VailNeckBlendSource.Disabled, diagnostic);
            }

            return TryBuildManualUv(mesh, uvChannel, offset, width, manualUvAngle, invert, out var manualValues, out var manualDiagnostic)
                ? new VailNeckBlendVertexData(manualValues, VailNeckBlendSource.ManualUv, manualDiagnostic)
                : new VailNeckBlendVertexData(null, VailNeckBlendSource.Disabled, manualDiagnostic);
        }

        internal static float EvaluateWeightMask(float headWeight, float offset, float width, bool invert)
        {
            var rawNeckMask = 1f - Mathf.Clamp01(headWeight);
            var center = 0.5f - Mathf.Clamp(offset, -1f, 1f) * 0.5f;
            var halfWidth = Mathf.Max(width, 0.001f) * 0.5f;
            var value = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(center - halfWidth, center + halfWidth, rawNeckMask));
            return invert ? 1f - value : value;
        }

        internal static float EvaluatePlaneMask(float signedDistance, float blendWidth, bool invert)
        {
            var halfWidth = Mathf.Max(blendWidth, 0.0001f) * 0.5f;
            var value = 1f - Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(-halfWidth, halfWidth, signedDistance));
            return invert ? 1f - value : value;
        }

        private static bool TryBuildHeadNeckWeights(
            Mesh mesh,
            SkinnedMeshRenderer skinnedMeshRenderer,
            IReadOnlyList<int> relevantVertexIndices,
            float offset,
            float width,
            bool invert,
            out float[] values,
            out string diagnostic)
        {
            values = null;
            if (!TryResolveHead(skinnedMeshRenderer, out var head, out diagnostic))
            {
                return false;
            }

            var bones = skinnedMeshRenderer.bones;
            if (bones == null || bones.Length == 0)
            {
                diagnostic = "The SkinnedMeshRenderer has no bones.";
                return false;
            }

            var headFamily = new bool[bones.Length];
            var hasHeadBone = false;
            for (var i = 0; i < bones.Length; i++)
            {
                var bone = bones[i];
                if (bone == null || (bone != head && !bone.IsChildOf(head)))
                {
                    continue;
                }

                headFamily[i] = true;
                hasHeadBone = true;
            }

            if (!hasHeadBone)
            {
                diagnostic = "The resolved Head transform is not present in the renderer bone list.";
                return false;
            }

            if (!TryReadHeadWeights(mesh, headFamily, mesh.vertexCount, out var headWeights) &&
                (skinnedMeshRenderer.sharedMesh == null ||
                 skinnedMeshRenderer.sharedMesh.vertexCount != mesh.vertexCount ||
                 !TryReadHeadWeights(skinnedMeshRenderer.sharedMesh, headFamily, mesh.vertexCount, out headWeights)))
            {
                diagnostic = "The mesh has no compatible bone weights.";
                return false;
            }

            for (var i = 0; i < headWeights.Length; i++)
            {
                headWeights[i] = Mathf.Clamp01(headWeights[i]);
            }

            var minWeight = float.MaxValue;
            var maxWeight = float.MinValue;
            var relevantVertexCount = 0;
            if (relevantVertexIndices != null && relevantVertexIndices.Count > 0)
            {
                for (var i = 0; i < relevantVertexIndices.Count; i++)
                {
                    var vertexIndex = relevantVertexIndices[i];
                    if (vertexIndex < 0 || vertexIndex >= headWeights.Length)
                    {
                        continue;
                    }

                    minWeight = Mathf.Min(minWeight, headWeights[vertexIndex]);
                    maxWeight = Mathf.Max(maxWeight, headWeights[vertexIndex]);
                    relevantVertexCount++;
                }
            }
            else
            {
                relevantVertexCount = headWeights.Length;
                for (var i = 0; i < headWeights.Length; i++)
                {
                    minWeight = Mathf.Min(minWeight, headWeights[i]);
                    maxWeight = Mathf.Max(maxWeight, headWeights[i]);
                }
            }

            if (relevantVertexCount < 2)
            {
                diagnostic = "The selected geometry does not contain enough weighted vertices.";
                return false;
            }

            var weightRange = maxWeight - minWeight;
            if (weightRange < MinimumWeightRange)
            {
                diagnostic = $"Head and skin weights were resolved, but the Head-family weight range inside the selected geometry is too small ({minWeight:0.###}-{maxWeight:0.###}).";
                return false;
            }

            values = new float[mesh.vertexCount];
            for (var i = 0; i < headWeights.Length; i++)
            {
                var normalizedHeadWeight = Mathf.InverseLerp(minWeight, maxWeight, headWeights[i]);
                values[i] = EvaluateWeightMask(normalizedHeadWeight, offset, width, invert);
            }

            diagnostic = $"Generated from Head/Neck skin weights normalized over the selected geometry ({minWeight:0.###}-{maxWeight:0.###}).";
            return true;
        }

        private static bool TryReadHeadWeights(Mesh mesh, IReadOnlyList<bool> headFamily, int expectedVertexCount, out float[] headWeights)
        {
            headWeights = null;
            if (mesh == null || mesh.vertexCount != expectedVertexCount)
            {
                return false;
            }

            NativeArray<byte> bonesPerVertex = default;
            NativeArray<BoneWeight1> allBoneWeights = default;
            try
            {
                bonesPerVertex = mesh.GetBonesPerVertex();
                allBoneWeights = mesh.GetAllBoneWeights();
                if (!bonesPerVertex.IsCreated || bonesPerVertex.Length != expectedVertexCount ||
                    !allBoneWeights.IsCreated || allBoneWeights.Length == 0)
                {
                    return false;
                }

                var values = new float[expectedVertexCount];
                var weightIndex = 0;
                for (var vertexIndex = 0; vertexIndex < expectedVertexCount; vertexIndex++)
                {
                    var influenceCount = bonesPerVertex[vertexIndex];
                    if (weightIndex + influenceCount > allBoneWeights.Length)
                    {
                        return false;
                    }

                    var headWeight = 0f;
                    for (var influenceIndex = 0; influenceIndex < influenceCount; influenceIndex++)
                    {
                        var boneWeight = allBoneWeights[weightIndex++];
                        if (boneWeight.weight > 0f && boneWeight.boneIndex >= 0 &&
                            boneWeight.boneIndex < headFamily.Count && headFamily[boneWeight.boneIndex])
                        {
                            headWeight += boneWeight.weight;
                        }
                    }

                    values[vertexIndex] = headWeight;
                }

                if (weightIndex != allBoneWeights.Length)
                {
                    return false;
                }

                headWeights = values;
                return true;
            }
            finally
            {
                if (allBoneWeights.IsCreated)
                {
                    allBoneWeights.Dispose();
                }

                if (bonesPerVertex.IsCreated)
                {
                    bonesPerVertex.Dispose();
                }
            }
        }

        private static bool TryBuildHeadNeckPlane(
            Mesh mesh,
            SkinnedMeshRenderer skinnedMeshRenderer,
            IReadOnlyList<int> relevantVertexIndices,
            float offset,
            float width,
            bool invert,
            out float[] values,
            out string diagnostic)
        {
            values = null;
            if (!TryResolveHeadAndNeck(skinnedMeshRenderer, out var head, out var neck, out diagnostic))
            {
                return false;
            }

            var rendererTransform = skinnedMeshRenderer.transform;
            var neckPosition = rendererTransform.InverseTransformPoint(neck.position);
            var headPosition = rendererTransform.InverseTransformPoint(head.position);
            var neckToHead = headPosition - neckPosition;
            var referenceLength = neckToHead.magnitude;
            if (referenceLength <= 0.0001f)
            {
                diagnostic = "Head and Neck transforms are at the same position.";
                return false;
            }

            var axis = neckToHead / referenceLength;
            var blendWidth = referenceLength * Mathf.Max(width, 0.001f);
            var vertices = mesh.vertices;
            if (!TryGetProjectionRange(
                    vertices,
                    relevantVertexIndices,
                    neckPosition,
                    axis,
                    out var minProjection,
                    out var maxProjection))
            {
                diagnostic = "The selected geometry does not contain enough vertices for the Head/Neck plane.";
                return false;
            }

            // Offset -1..1 maps from Neck to Head with 0 at the anatomical midpoint.
            // If the imported mesh starts above that interval (common for separately skinned
            // face meshes), keep the plane inside the selected geometry instead of saturating
            // the entire B mask and unnecessarily falling through to Manual UV.
            var requestedCenterProjection = referenceLength * (0.5f + Mathf.Clamp(offset, -1f, 1f) * 0.5f);
            var appliedCenterProjection = requestedCenterProjection;
            var projectionRange = maxProjection - minProjection;
            if (projectionRange > 0.0001f)
            {
                var halfBlendWidth = blendWidth * 0.5f;
                var minimumCenter = minProjection + halfBlendWidth;
                var maximumCenter = maxProjection - halfBlendWidth;
                if (minimumCenter <= maximumCenter)
                {
                    appliedCenterProjection = Mathf.Clamp(requestedCenterProjection, minimumCenter, maximumCenter);
                }
                else
                {
                    appliedCenterProjection = (minProjection + maxProjection) * 0.5f;
                }
            }

            var center = neckPosition + axis * appliedCenterProjection;
            values = new float[vertices.Length];
            for (var i = 0; i < vertices.Length; i++)
            {
                var signedDistance = Vector3.Dot(vertices[i] - center, axis);
                values[i] = EvaluatePlaneMask(signedDistance, blendWidth, invert);
            }

            if (!TryGetValueRange(values, relevantVertexIndices, out var minValue, out var maxValue))
            {
                values = null;
                diagnostic = "The selected geometry does not contain enough vertices for the Head/Neck plane.";
                return false;
            }

            if (maxValue - minValue < MinimumWeightRange)
            {
                values = null;
                diagnostic = $"Head and Neck transforms were resolved, but the plane mask is uniform inside the selected geometry ({minValue:0.###}-{maxValue:0.###}).";
                return false;
            }

            var requestedCenterRatio = requestedCenterProjection / referenceLength;
            var appliedCenterRatio = appliedCenterProjection / referenceLength;
            var centerAdjustment = Mathf.Abs(requestedCenterProjection - appliedCenterProjection) > referenceLength * 0.0001f
                ? $" The plane center was constrained from {requestedCenterRatio:0.###} to {appliedCenterRatio:0.###} of the Neck-to-Head distance to intersect the selected geometry."
                : string.Empty;
            diagnostic = $"Generated from a plane between the Neck and Head transforms ({minValue:0.###}-{maxValue:0.###} inside the selected geometry).{centerAdjustment}";
            return true;
        }

        private static bool TryGetProjectionRange(
            IReadOnlyList<Vector3> vertices,
            IReadOnlyList<int> relevantVertexIndices,
            Vector3 origin,
            Vector3 axis,
            out float minProjection,
            out float maxProjection)
        {
            minProjection = float.MaxValue;
            maxProjection = float.MinValue;
            var count = 0;

            if (relevantVertexIndices != null && relevantVertexIndices.Count > 0)
            {
                for (var i = 0; i < relevantVertexIndices.Count; i++)
                {
                    var index = relevantVertexIndices[i];
                    if (index < 0 || index >= vertices.Count)
                    {
                        continue;
                    }

                    var projection = Vector3.Dot(vertices[index] - origin, axis);
                    minProjection = Mathf.Min(minProjection, projection);
                    maxProjection = Mathf.Max(maxProjection, projection);
                    count++;
                }
            }
            else
            {
                for (var i = 0; i < vertices.Count; i++)
                {
                    var projection = Vector3.Dot(vertices[i] - origin, axis);
                    minProjection = Mathf.Min(minProjection, projection);
                    maxProjection = Mathf.Max(maxProjection, projection);
                    count++;
                }
            }

            return count >= 2;
        }

        private static bool TryGetValueRange(
            IReadOnlyList<float> values,
            IReadOnlyList<int> relevantVertexIndices,
            out float minValue,
            out float maxValue)
        {
            minValue = float.MaxValue;
            maxValue = float.MinValue;
            var count = 0;

            if (relevantVertexIndices != null && relevantVertexIndices.Count > 0)
            {
                for (var i = 0; i < relevantVertexIndices.Count; i++)
                {
                    var index = relevantVertexIndices[i];
                    if (index < 0 || index >= values.Count)
                    {
                        continue;
                    }

                    minValue = Mathf.Min(minValue, values[index]);
                    maxValue = Mathf.Max(maxValue, values[index]);
                    count++;
                }
            }
            else
            {
                for (var i = 0; i < values.Count; i++)
                {
                    minValue = Mathf.Min(minValue, values[i]);
                    maxValue = Mathf.Max(maxValue, values[i]);
                    count++;
                }
            }

            return count >= 2;
        }

        private static bool TryBuildManualUv(
            Mesh mesh,
            int uvChannel,
            float offset,
            float width,
            float angleDegrees,
            bool invert,
            out float[] values,
            out string diagnostic)
        {
            values = null;
            var uvs = new List<Vector4>();
            mesh.GetUVs(uvChannel, uvs);
            if (uvs.Count != mesh.vertexCount)
            {
                diagnostic = "The selected UV channel does not contain one UV per vertex.";
                return false;
            }

            var radians = angleDegrees * Mathf.Deg2Rad;
            var direction = new Vector2(Mathf.Cos(radians), Mathf.Sin(radians));
            var center = 0.5f + Mathf.Clamp(offset, -1f, 1f) * 0.5f;
            var halfWidth = Mathf.Max(width, 0.001f) * 0.5f;
            values = new float[uvs.Count];
            for (var i = 0; i < uvs.Count; i++)
            {
                var projected = Vector2.Dot(new Vector2(uvs[i].x, uvs[i].y) - new Vector2(0.5f, 0.5f), direction) + 0.5f;
                var value = 1f - Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(center - halfWidth, center + halfWidth, projected));
                values[i] = invert ? 1f - value : value;
            }

            diagnostic = "Generated from the manual UV gradient fallback.";
            return true;
        }

        private static bool TryBuildUvBoundary(
            Mesh mesh,
            SkinnedMeshRenderer skinnedMeshRenderer,
            int uvChannel,
            IReadOnlyList<int> relevantVertexIndices,
            IReadOnlyList<int> relevantTriangleIndices,
            float offset,
            float width,
            float fallbackAngleDegrees,
            bool invert,
            out float[] values,
            out string diagnostic)
        {
            values = null;
            var uvs = new List<Vector4>();
            mesh.GetUVs(uvChannel, uvs);
            if (uvs.Count != mesh.vertexCount)
            {
                diagnostic = "The selected UV channel does not contain one UV per vertex.";
                return false;
            }

            IReadOnlyList<int> triangles = relevantTriangleIndices;
            if (triangles == null || triangles.Count < 3)
            {
                triangles = mesh.triangles;
            }

            if (triangles == null || triangles.Count < 3)
            {
                diagnostic = "The selected geometry does not contain triangles for UV-boundary detection.";
                return false;
            }

            var vertices = mesh.vertices;
            var edgeUseCounts = new Dictionary<UvTopologyEdgeKey, UvBoundaryEdgeUsage>();
            var selectedVertices = new HashSet<int>();
            HashSet<int> allowedVertices = null;
            if (relevantVertexIndices != null && relevantVertexIndices.Count > 0)
            {
                allowedVertices = new HashSet<int>(relevantVertexIndices);
            }

            for (var triangle = 0; triangle + 2 < triangles.Count; triangle += 3)
            {
                var a = triangles[triangle];
                var b = triangles[triangle + 1];
                var c = triangles[triangle + 2];
                if (!IsValidTriangleVertex(a, mesh.vertexCount) ||
                    !IsValidTriangleVertex(b, mesh.vertexCount) ||
                    !IsValidTriangleVertex(c, mesh.vertexCount))
                {
                    continue;
                }

                if (allowedVertices != null &&
                    (!allowedVertices.Contains(a) || !allowedVertices.Contains(b) || !allowedVertices.Contains(c)))
                {
                    continue;
                }

                selectedVertices.Add(a);
                selectedVertices.Add(b);
                selectedVertices.Add(c);
                CountEdge(edgeUseCounts, vertices, uvs, a, b);
                CountEdge(edgeUseCounts, vertices, uvs, b, c);
                CountEdge(edgeUseCounts, vertices, uvs, c, a);
            }

            if (selectedVertices.Count < 3)
            {
                diagnostic = "The selected geometry does not contain enough vertices for UV-boundary detection.";
                return false;
            }

            var useAnatomicalDirection = TryResolveHeadAndNeck(skinnedMeshRenderer, out var head, out var neck, out _);
            var anatomicalOrigin = Vector3.zero;
            var anatomicalAxis = Vector3.zero;
            if (useAnatomicalDirection)
            {
                var rendererTransform = skinnedMeshRenderer.transform;
                anatomicalOrigin = rendererTransform.InverseTransformPoint(neck.position);
                var headPosition = rendererTransform.InverseTransformPoint(head.position);
                anatomicalAxis = headPosition - anatomicalOrigin;
                useAnatomicalDirection = anatomicalAxis.sqrMagnitude > 0.00000001f;
                if (useAnatomicalDirection)
                {
                    anatomicalAxis.Normalize();
                }
            }

            var radians = fallbackAngleDegrees * Mathf.Deg2Rad;
            var fallbackDirection = new Vector2(Mathf.Cos(radians), Mathf.Sin(radians));
            var boundaryEdges = new List<UvBoundaryEdge>();
            foreach (var pair in edgeUseCounts)
            {
                if (pair.Value.Count != 1)
                {
                    continue;
                }

                var a = pair.Value.A;
                var b = pair.Value.B;
                var uvA = new Vector2(uvs[a].x, uvs[a].y);
                var uvB = new Vector2(uvs[b].x, uvs[b].y);
                if ((uvB - uvA).sqrMagnitude <= 0.0000000001f)
                {
                    continue;
                }

                float score;
                if (useAnatomicalDirection)
                {
                    var midpoint = (vertices[a] + vertices[b]) * 0.5f;
                    score = Vector3.Dot(midpoint - anatomicalOrigin, anatomicalAxis);
                }
                else
                {
                    score = Vector2.Dot((uvA + uvB) * 0.5f, fallbackDirection);
                }

                boundaryEdges.Add(new UvBoundaryEdge(a, b, score));
            }

            if (boundaryEdges.Count == 0)
            {
                diagnostic = "No open UV perimeter was found in the selected geometry.";
                return false;
            }

            var sortedScores = new List<float>(boundaryEdges.Count);
            for (var i = 0; i < boundaryEdges.Count; i++)
            {
                sortedScores.Add(boundaryEdges[i].Score);
            }

            sortedScores.Sort();
            var cutoffIndex = Mathf.Clamp(Mathf.CeilToInt(sortedScores.Count * 0.15f) - 1, 0, sortedScores.Count - 1);
            var scoreRange = sortedScores[sortedScores.Count - 1] - sortedScores[0];
            var cutoff = sortedScores[cutoffIndex] + scoreRange * 0.02f;
            var neckSideCandidates = new List<UvBoundaryCandidate>();
            for (var i = 0; i < boundaryEdges.Count; i++)
            {
                var edge = boundaryEdges[i];
                if (edge.Score > cutoff)
                {
                    continue;
                }

                neckSideCandidates.Add(new UvBoundaryCandidate(
                    new UvTopologyVertexKey(vertices[edge.A], uvs[edge.A]),
                    new UvTopologyVertexKey(vertices[edge.B], uvs[edge.B]),
                    new UvSegment(
                        new Vector2(uvs[edge.A].x, uvs[edge.A].y),
                        new Vector2(uvs[edge.B].x, uvs[edge.B].y)),
                    edge.Score));
            }

            if (neckSideCandidates.Count == 0)
            {
                diagnostic = "The neck-side portion of the UV perimeter could not be isolated.";
                return false;
            }

            var components = BuildUvBoundaryComponents(neckSideCandidates);
            var primaryComponent = components[0];
            for (var componentIndex = 1; componentIndex < components.Count; componentIndex++)
            {
                if (components[componentIndex].UvLength > primaryComponent.UvLength)
                {
                    primaryComponent = components[componentIndex];
                }
            }

            var neckSideSegments = new List<UvSegment>();
            var componentScoreTolerance = Mathf.Max(scoreRange * 0.03f, 0.000001f);
            var minimumCompanionLength = primaryComponent.UvLength * 0.15f;
            for (var componentIndex = 0; componentIndex < components.Count; componentIndex++)
            {
                var component = components[componentIndex];
                if (component.UvLength < minimumCompanionLength ||
                    Mathf.Abs(component.AverageScore - primaryComponent.AverageScore) > componentScoreTolerance)
                {
                    continue;
                }

                neckSideSegments.AddRange(component.Segments);
            }

            var uvMin = new Vector2(float.MaxValue, float.MaxValue);
            var uvMax = new Vector2(float.MinValue, float.MinValue);
            foreach (var vertexIndex in selectedVertices)
            {
                var uv = new Vector2(uvs[vertexIndex].x, uvs[vertexIndex].y);
                uvMin = Vector2.Min(uvMin, uv);
                uvMax = Vector2.Max(uvMax, uv);
            }

            var uvScale = Mathf.Max(uvMax.x - uvMin.x, uvMax.y - uvMin.y);
            if (uvScale <= 0.000001f)
            {
                diagnostic = "The selected UV island has no usable extent.";
                return false;
            }

            var blendDistance = uvScale * Mathf.Max(width, 0.001f);
            var offsetDistance = Mathf.Clamp(offset, -1f, 1f) * blendDistance * 0.5f;
            var fadeStart = offsetDistance;
            var fadeEnd = offsetDistance + blendDistance;
            values = new float[uvs.Count];
            for (var vertexIndex = 0; vertexIndex < uvs.Count; vertexIndex++)
            {
                var uv = new Vector2(uvs[vertexIndex].x, uvs[vertexIndex].y);
                var distance = float.MaxValue;
                for (var segmentIndex = 0; segmentIndex < neckSideSegments.Count; segmentIndex++)
                {
                    distance = Mathf.Min(distance, DistanceToSegment(uv, neckSideSegments[segmentIndex]));
                }

                var value = 1f - Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(fadeStart, fadeEnd, distance));
                values[vertexIndex] = invert ? 1f - value : value;
            }

            var selectedVertexList = new List<int>(selectedVertices);
            if (!TryGetValueRange(values, selectedVertexList, out var minValue, out var maxValue) ||
                maxValue - minValue < MinimumWeightRange)
            {
                values = null;
                diagnostic = $"The UV-boundary mask is uniform inside the selected geometry ({minValue:0.###}-{maxValue:0.###}).";
                return false;
            }

            var directionSource = useAnatomicalDirection ? "the Neck-to-Head direction" : "the configured UV direction";
            diagnostic = $"Generated from {neckSideSegments.Count} neck-side UV boundary edge(s), selected using {directionSource} ({minValue:0.###}-{maxValue:0.###} inside the selected geometry).";
            return true;
        }

        private static bool IsValidTriangleVertex(int index, int vertexCount)
        {
            return index >= 0 && index < vertexCount;
        }

        private static void CountEdge(
            IDictionary<UvTopologyEdgeKey, UvBoundaryEdgeUsage> edgeUseCounts,
            IReadOnlyList<Vector3> vertices,
            IReadOnlyList<Vector4> uvs,
            int a,
            int b)
        {
            var key = new UvTopologyEdgeKey(
                new UvTopologyVertexKey(vertices[a], uvs[a]),
                new UvTopologyVertexKey(vertices[b], uvs[b]));
            if (edgeUseCounts.TryGetValue(key, out var usage))
            {
                edgeUseCounts[key] = new UvBoundaryEdgeUsage(usage.A, usage.B, usage.Count + 1);
            }
            else
            {
                edgeUseCounts[key] = new UvBoundaryEdgeUsage(a, b, 1);
            }
        }

        private static float DistanceToSegment(Vector2 point, UvSegment segment)
        {
            var delta = segment.B - segment.A;
            var lengthSquared = delta.sqrMagnitude;
            if (lengthSquared <= 0.0000000001f)
            {
                return Vector2.Distance(point, segment.A);
            }

            var t = Mathf.Clamp01(Vector2.Dot(point - segment.A, delta) / lengthSquared);
            return Vector2.Distance(point, segment.A + delta * t);
        }

        private static List<UvBoundaryComponent> BuildUvBoundaryComponents(IReadOnlyList<UvBoundaryCandidate> candidates)
        {
            var components = new List<UvBoundaryComponent>();
            var visited = new bool[candidates.Count];
            for (var seed = 0; seed < candidates.Count; seed++)
            {
                if (visited[seed])
                {
                    continue;
                }

                var component = new UvBoundaryComponent();
                var pending = new Queue<int>();
                pending.Enqueue(seed);
                visited[seed] = true;
                while (pending.Count > 0)
                {
                    var currentIndex = pending.Dequeue();
                    var current = candidates[currentIndex];
                    component.Add(current);
                    for (var candidateIndex = 0; candidateIndex < candidates.Count; candidateIndex++)
                    {
                        if (visited[candidateIndex] || !current.SharesEndpoint(candidates[candidateIndex]))
                        {
                            continue;
                        }

                        visited[candidateIndex] = true;
                        pending.Enqueue(candidateIndex);
                    }
                }

                components.Add(component);
            }

            return components;
        }

        private readonly struct UvBoundaryEdge
        {
            public UvBoundaryEdge(int a, int b, float score)
            {
                A = a;
                B = b;
                Score = score;
            }

            public int A { get; }
            public int B { get; }
            public float Score { get; }
        }

        private readonly struct UvBoundaryCandidate
        {
            public UvBoundaryCandidate(
                UvTopologyVertexKey a,
                UvTopologyVertexKey b,
                UvSegment segment,
                float score)
            {
                A = a;
                B = b;
                Segment = segment;
                Score = score;
            }

            public UvTopologyVertexKey A { get; }
            public UvTopologyVertexKey B { get; }
            public UvSegment Segment { get; }
            public float Score { get; }

            public bool SharesEndpoint(UvBoundaryCandidate other)
            {
                return A.Equals(other.A) || A.Equals(other.B) || B.Equals(other.A) || B.Equals(other.B);
            }
        }

        private sealed class UvBoundaryComponent
        {
            private float scoreSum;

            public List<UvSegment> Segments { get; } = new List<UvSegment>();
            public float UvLength { get; private set; }
            public float AverageScore => Segments.Count > 0 ? scoreSum / Segments.Count : 0f;

            public void Add(UvBoundaryCandidate candidate)
            {
                Segments.Add(candidate.Segment);
                UvLength += Vector2.Distance(candidate.Segment.A, candidate.Segment.B);
                scoreSum += candidate.Score;
            }
        }

        private readonly struct UvBoundaryEdgeUsage
        {
            public UvBoundaryEdgeUsage(int a, int b, int count)
            {
                A = a;
                B = b;
                Count = count;
            }

            public int A { get; }
            public int B { get; }
            public int Count { get; }
        }

        private readonly struct UvTopologyVertexKey : IEquatable<UvTopologyVertexKey>, IComparable<UvTopologyVertexKey>
        {
            private const float PositionPrecision = 100000f;
            private const float UvPrecision = 1000000f;

            public UvTopologyVertexKey(Vector3 position, Vector4 uv)
            {
                X = Mathf.RoundToInt(position.x * PositionPrecision);
                Y = Mathf.RoundToInt(position.y * PositionPrecision);
                Z = Mathf.RoundToInt(position.z * PositionPrecision);
                U = Mathf.RoundToInt(uv.x * UvPrecision);
                V = Mathf.RoundToInt(uv.y * UvPrecision);
            }

            private int X { get; }
            private int Y { get; }
            private int Z { get; }
            private int U { get; }
            private int V { get; }

            public int CompareTo(UvTopologyVertexKey other)
            {
                var comparison = X.CompareTo(other.X);
                if (comparison != 0) return comparison;
                comparison = Y.CompareTo(other.Y);
                if (comparison != 0) return comparison;
                comparison = Z.CompareTo(other.Z);
                if (comparison != 0) return comparison;
                comparison = U.CompareTo(other.U);
                return comparison != 0 ? comparison : V.CompareTo(other.V);
            }

            public bool Equals(UvTopologyVertexKey other)
            {
                return X == other.X && Y == other.Y && Z == other.Z && U == other.U && V == other.V;
            }

            public override bool Equals(object obj)
            {
                return obj is UvTopologyVertexKey other && Equals(other);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    var hash = X;
                    hash = hash * 397 ^ Y;
                    hash = hash * 397 ^ Z;
                    hash = hash * 397 ^ U;
                    return hash * 397 ^ V;
                }
            }
        }

        private readonly struct UvTopologyEdgeKey : IEquatable<UvTopologyEdgeKey>
        {
            public UvTopologyEdgeKey(UvTopologyVertexKey a, UvTopologyVertexKey b)
            {
                if (a.CompareTo(b) <= 0)
                {
                    A = a;
                    B = b;
                }
                else
                {
                    A = b;
                    B = a;
                }
            }

            private UvTopologyVertexKey A { get; }
            private UvTopologyVertexKey B { get; }

            public bool Equals(UvTopologyEdgeKey other)
            {
                return A.Equals(other.A) && B.Equals(other.B);
            }

            public override bool Equals(object obj)
            {
                return obj is UvTopologyEdgeKey other && Equals(other);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    return A.GetHashCode() * 397 ^ B.GetHashCode();
                }
            }
        }

        private readonly struct UvSegment
        {
            public UvSegment(Vector2 a, Vector2 b)
            {
                A = a;
                B = b;
            }

            public Vector2 A { get; }
            public Vector2 B { get; }
        }

        private static bool TryResolveHead(
            SkinnedMeshRenderer skinnedMeshRenderer,
            out Transform head,
            out string diagnostic)
        {
            head = null;
            if (skinnedMeshRenderer == null)
            {
                diagnostic = "The target is not backed by a SkinnedMeshRenderer.";
                return false;
            }

            var animator = FindAnimator(skinnedMeshRenderer);
            if (animator != null && animator.isHuman)
            {
                head = animator.GetBoneTransform(HumanBodyBones.Head);
            }

            if (head == null)
            {
                head = FindModelImporterHumanBone(skinnedMeshRenderer, HumanBodyBones.Head.ToString());
            }

            if (head == null)
            {
                head = FindNamedBone(skinnedMeshRenderer.bones, "Head") ??
                       FindNamedBone(GetRendererBoneHierarchy(skinnedMeshRenderer), "Head");
            }

            if (head == null)
            {
                diagnostic = "Could not resolve the Head transform from Humanoid mapping, FBX Configure mapping, or bone names.";
                return false;
            }

            diagnostic = string.Empty;
            return true;
        }

        private static bool TryResolveHeadAndNeck(
            SkinnedMeshRenderer skinnedMeshRenderer,
            out Transform head,
            out Transform neck,
            out string diagnostic)
        {
            head = null;
            neck = null;
            if (skinnedMeshRenderer == null)
            {
                diagnostic = "The target is not backed by a SkinnedMeshRenderer.";
                return false;
            }

            var animator = FindAnimator(skinnedMeshRenderer);
            if (animator != null && animator.isHuman)
            {
                head = animator.GetBoneTransform(HumanBodyBones.Head);
                neck = animator.GetBoneTransform(HumanBodyBones.Neck);
            }

            if (head == null)
            {
                head = FindModelImporterHumanBone(skinnedMeshRenderer, HumanBodyBones.Head.ToString());
            }

            if (neck == null)
            {
                neck = FindModelImporterHumanBone(skinnedMeshRenderer, HumanBodyBones.Neck.ToString());
            }

            var hierarchy = GetRendererBoneHierarchy(skinnedMeshRenderer);
            if (head == null)
            {
                head = FindNamedBone(skinnedMeshRenderer.bones, "Head") ?? FindNamedBone(hierarchy, "Head");
            }

            if (neck == null)
            {
                neck = FindNamedBone(skinnedMeshRenderer.bones, "Neck") ?? FindNamedBone(hierarchy, "Neck");
            }

            if (neck == null && head != null)
            {
                neck = FindNamedAncestor(head, "Neck") ?? FindDirectParentBone(skinnedMeshRenderer, head);
            }

            if (head == null || neck == null)
            {
                diagnostic = "Could not resolve both Head and Neck transforms from Humanoid mapping, FBX Configure mapping, bone names, or the direct Head parent.";
                return false;
            }

            diagnostic = string.Empty;
            return true;
        }

        private static Animator FindAnimator(SkinnedMeshRenderer skinnedMeshRenderer)
        {
            var animator = skinnedMeshRenderer.GetComponentInParent<Animator>();
            return animator != null ? animator : skinnedMeshRenderer.GetComponentInChildren<Animator>();
        }

        private static Transform FindModelImporterHumanBone(SkinnedMeshRenderer skinnedMeshRenderer, string humanBoneName)
        {
            var sourceMesh = skinnedMeshRenderer.sharedMesh;
            var assetPath = sourceMesh != null ? AssetDatabase.GetAssetPath(sourceMesh) : string.Empty;
            if (string.IsNullOrEmpty(assetPath) || !(AssetImporter.GetAtPath(assetPath) is ModelImporter modelImporter))
            {
                return null;
            }

            return FindConfiguredHumanBone(
                skinnedMeshRenderer.bones,
                GetRendererBoneHierarchy(skinnedMeshRenderer),
                modelImporter.humanDescription.human,
                humanBoneName);
        }

        internal static Transform FindConfiguredHumanBone(
            IEnumerable<Transform> rendererBones,
            IEnumerable<Transform> hierarchy,
            IReadOnlyList<HumanBone> configuredHumanBones,
            string humanBoneName)
        {
            if (configuredHumanBones == null || string.IsNullOrEmpty(humanBoneName))
            {
                return null;
            }

            for (var i = 0; i < configuredHumanBones.Count; i++)
            {
                var configuredBone = configuredHumanBones[i];
                if (!string.Equals(configuredBone.humanName, humanBoneName, StringComparison.OrdinalIgnoreCase) ||
                    string.IsNullOrEmpty(configuredBone.boneName))
                {
                    continue;
                }

                return FindExactBone(rendererBones, configuredBone.boneName) ??
                       FindExactBone(hierarchy, configuredBone.boneName);
            }

            return null;
        }

        private static IEnumerable<Transform> GetRendererBoneHierarchy(SkinnedMeshRenderer skinnedMeshRenderer)
        {
            var root = skinnedMeshRenderer.rootBone;
            if (root == null)
            {
                var bones = skinnedMeshRenderer.bones;
                if (bones != null)
                {
                    for (var i = 0; i < bones.Length; i++)
                    {
                        if (bones[i] == null)
                        {
                            continue;
                        }

                        for (var ancestor = bones[i]; ancestor != null; ancestor = ancestor.parent)
                        {
                            if (ancestor == skinnedMeshRenderer.transform || skinnedMeshRenderer.transform.IsChildOf(ancestor))
                            {
                                root = ancestor;
                                break;
                            }
                        }

                        break;
                    }
                }
            }

            return root != null ? root.GetComponentsInChildren<Transform>(true) : Array.Empty<Transform>();
        }

        private static Transform FindExactBone(IEnumerable<Transform> bones, string expectedName)
        {
            if (bones == null)
            {
                return null;
            }

            foreach (var bone in bones)
            {
                if (bone != null && string.Equals(bone.name, expectedName, StringComparison.OrdinalIgnoreCase))
                {
                    return bone;
                }
            }

            return null;
        }

        private static Transform FindNamedAncestor(Transform head, string expectedName)
        {
            for (var ancestor = head.parent; ancestor != null; ancestor = ancestor.parent)
            {
                if (IsExpectedBoneName(ancestor.name, expectedName))
                {
                    return ancestor;
                }
            }

            return null;
        }

        private static Transform FindDirectParentBone(SkinnedMeshRenderer skinnedMeshRenderer, Transform head)
        {
            var parent = head.parent;
            var bones = skinnedMeshRenderer.bones;
            if (parent == null || parent == skinnedMeshRenderer.transform || bones == null)
            {
                return null;
            }

            for (var i = 0; i < bones.Length; i++)
            {
                if (bones[i] == parent)
                {
                    return parent;
                }
            }

            return null;
        }

        private static Transform FindNamedBone(IEnumerable<Transform> bones, string expectedName)
        {
            if (bones == null)
            {
                return null;
            }

            foreach (var bone in bones)
            {
                if (bone == null)
                {
                    continue;
                }

                var normalizedName = bone.name;
                var separator = Mathf.Max(normalizedName.LastIndexOf(':'), normalizedName.LastIndexOf('|'));
                if (separator >= 0 && separator + 1 < normalizedName.Length)
                {
                    normalizedName = normalizedName.Substring(separator + 1);
                }

                if (IsExpectedBoneName(normalizedName, expectedName))
                {
                    return bone;
                }
            }

            return null;
        }

        private static bool IsExpectedBoneName(string boneName, string expectedName)
        {
            if (string.Equals(boneName, expectedName, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (string.IsNullOrEmpty(boneName) || boneName.Length <= expectedName.Length ||
                !boneName.EndsWith(expectedName, StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            var separator = boneName[boneName.Length - expectedName.Length - 1];
            return !char.IsLetterOrDigit(separator);
        }
    }
}
