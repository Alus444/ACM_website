# ACM Vail

Vail は、顔メッシュのUVへ左右ライティング用SDFをベイクし、1枚のPNGへ格納するUnity Editorツールです。Unity 2022.3.22f1で動作確認しています。

- メニュー: `Tools > ACM > Vail`
- R: 右側ライト用マップ
- G: 左側ライト用マップ
- B: 顔SDFと通常ライティングを首周辺で切り替えるマスク（任意）
- A: 255

Bマスクは既定で無効です。従来のR/G出力を変更せず、必要な場合だけ有効化できます。`自動`では次の順に安全に検出します。

1. 選択サブメッシュ内のHeadおよびHead配下ボーンのスキンウェイト（Headだけ解決できれば利用可能。観測範囲をBマスク全域へ正規化）
2. Neck–Head間の中央を基準にした3D平面（無理な位置補正なしで選択形状と交差する場合）
3. 選択サブメッシュの外周から、首に最も近いUV境界を自動抽出
4. UV境界を特定できない場合は、選択形状内へ安全に補正したNeck–Head平面
5. 手動UVグラデーション

基本操作、各ベイク方式、Bマスクの調整方法、トラブル対応は [Manual.md](Manual.md) を参照してください。

## クイックスタート

1. Vailを開き、顔の `SkinnedMeshRenderer` またはメッシュを持つGameObjectを「対象オブジェクト」へ指定します。
2. プレビュー右側にUVが表示されたら、「プレビュークリック動作」を「生成アイランド選択」に変更し、顔側のUVをクリックします。「同一UV島の後頭部を除外」は通常オンのまま使用します。
3. 必要に応じて「首なじませ(Bチャンネル) > Bマスクを生成」を有効にします。通常は「自動」のままで開始します。
4. `R`、`G`、`B` の個別プレビューを確認します。
5. 保存先が `Assets/` 内の `.png` であることを確認し、「PNGを書き出す」を押します。

## 保守情報

- Editor本体: `VailBakerWindow.cs`
- Bマスク検出: `VailNeckBlendUtility.cs`
- EditModeテスト: `Tests/VailNeckBlendUtilityTests.cs`
- Bマスクを含むベイクキャッシュのアルゴリズム版: 10

---

# ACM Vail (English)

Vail is a Unity Editor tool that bakes left/right face-lighting SDF maps into one PNG. It is verified with Unity 2022.3.22f1.

- Menu: `Tools > ACM > Vail`
- R: right-light map
- G: left-light map
- B: optional neck mask that blends from face SDF to regular lighting
- A: 255

The B mask is disabled by default, so existing R/G output remains compatible. Automatic detection uses this conservative fallback chain:

1. Skin weights from Head and descendants of Head inside the selected submesh (requires Head only and normalizes the observed range)
2. A 3D plane centered between Neck and Head when it intersects the selection without a large correction
3. The UV perimeter nearest the neck, extracted from the selected submesh
4. A safely constrained Neck-to-Head plane when no usable UV boundary exists
5. A manual UV gradient

See [Manual.md](Manual.md) for the complete workflow, bake-mode notes, B-mask tuning, and troubleshooting.

## Quick start

1. Open Vail and assign the face `SkinnedMeshRenderer` or a GameObject containing a mesh.
2. When the UV preview appears, set Preview Click Action to Select Bake Island and click the face-facing part of the UV. Normally leave Exclude Rear of Same UV Island enabled.
3. Enable Neck Blend (B Channel) only when needed. Start with Automatic.
4. Inspect the separate R, G, and B previews.
5. Confirm that the save path is a `.png` inside `Assets/`, then click Export PNG.
