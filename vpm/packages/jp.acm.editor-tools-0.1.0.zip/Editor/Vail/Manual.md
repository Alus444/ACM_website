# ACM Vail 説明書

## 1. 目的と出力

Vailは、顔用SDFシェーダーで利用する左右のライトマップをUV空間へ生成します。書き出しPNGのチャンネルは次の契約です。

| チャンネル | 内容 |
|---|---|
| R | 右側ライト用マップ（「R/Gを入れ替え」で交換可能） |
| G | 左側ライト用マップ（「R/Gを入れ替え」で交換可能） |
| B | 首なじませマスク。`0` = 顔SDF側、`1` = 通常ライティング側 |
| A | 常に255 |

Bは「Bマスクを生成」が無効なら0です。生成対象として選択していないUV島でもBは0になります。プレビューのシアン色は鼻ハイライト範囲を示すだけで、PNGには合成されません。

## 2. 開き方

Unityのメニューから `Tools > ACM > Vail` を選びます。右上の `JP / EN` で表示言語を切り替えられます。

## 3. 基本手順

1. 「対象オブジェクト」に `SkinnedMeshRenderer`、`Renderer`、`MeshFilter`、Meshアセット、またはそれらを持つGameObjectを指定します。複数のSkinnedMeshRendererを持つアバターRootを指定した場合、VailはRenderer名・Mesh名よりも顔用マテリアル名を強く優先して顔候補を選びます。意図と異なる場合は顔Rendererを直接指定してください。
2. アニメーションやBlendShapeを反映したい場合は「現在ポーズをBakeMesh」を有効にします。ポーズを変更した後は「現在状態からプレビューを再生成」を押します。
3. サブメッシュ番号を指定します。`-1` は全サブメッシュです。利用するUVチャンネルも確認します。
4. 調整中は低いプレビュー解像度を使います。書き出し解像度はPNG生成時だけ使われます。
5. 「プレビュークリック動作」を「生成アイランド選択」にし、顔側のUVをクリックします。複数島を選ぶ場合は続けてクリックします。「同一UV島の後頭部を除外」がオンの場合、顔と後頭部が同じUV島でも、クリック面と反対を向く3D三角形はR/G生成範囲から除外されます。方向を安全に判定できない場合はUV島全体へ自動的に戻ります。
6. 必要なら「穴境界補正追加」に切り替え、口内などの穴をクリックします。クリック地点が穴から外れた場合は「穴スナップ距離」内の近い穴へ吸着します。
7. ベイク方式とライト値を調整し、`最終結果 / R / G / B` を確認します。多角度方式では `9角度グリッド` も確認できます。
8. 保存先を `Assets/` 内の `.png` に設定して「PNGを書き出す」を押します。

## 4. ベイク方式

- ライト照射ベイク(GPU): メッシュ形状と自己影をGPUでUV空間へ焼きます。立体的な顔での基本方式です。
- 多角度ライトグラデーション(GPU): 複数方向を合成して安定した境界を作ります。4096pxでは18方向の描画と高解像度CPU処理を行うため、時間とメモリを多く使います。
- 3Dモデル法線: 頂点法線から左右ライト値を作る補助方式です。
- UVグラデーション: UV位置だけで単純な左右グラデーションを作るフォールバック方式です。

「ライト前後オフセット」はツール内部のY成分、「ライト上下オフセット」はZ成分へ対応します。これはVailのライト座標規約であり、表示名の取り違えではありません。

## 5. 首なじませ（Bチャンネル）

### 自動検出の順序

「検出方式 = 自動」は次の順で試し、最初に有効な結果を使います。

1. Head/Neckウェイト
   - 実行中のHumanoid AnimatorのHead割り当てを最優先し、次にFBX Import SettingsのRig > Configureで設定されたHuman mappingを参照します。
   - ウェイト方式に必要なのはHeadだけです。Neckを取得できなくてもウェイト境界は利用できます。
   - 割り当てで取得できない場合は、名前が `Head` のボーンを大文字小文字を区別せず探します。`Armature:Head`、`Rig|Head`、`J_Bip_C_Head` のように区切り記号付きで末尾が一致する一般的な名前も扱います。
   - Head自身とHead配下（Jaw、Eye等を含む）の全スキンウェイトを顔側として合計します。4ウェイトに限らずUnityの可変数ウェイトを扱います。
   - 判定には選択中のサブメッシュで使用される頂点だけを使います。他のサブメッシュの髪、目、身体などのウェイト差には影響されません。
   - 選択範囲で観測したHead系ウェイトの最小値から最大値をBマスク全域へ正規化するため、狭いウェイト差でも境界として利用できます。差がほぼ一定で首境界を特定できない場合だけ次へ進みます。
2. Head/Neck平面
   - NeckからHeadへ向かうローカル3D軸を作り、その軸に直交する平面で滑らかに分けます。
   - 境界オフセット0はNeckとHeadの中央です。-1がNeck側、+1がHead側です。
   - Head/NeckはHumanoid Animator、FBX Configure、ボーン名の順で解決します。Neckだけ解決できない場合は、Headの直上かつrendererのbonesに含まれる親ボーンだけを保守的にNeck候補として使います。離れた祖先は推定しません。
   - 自動では、指定位置が選択形状と無理なく交差する場合にこの結果を使います。平面を形状内へ大きく動かす必要がある場合は、先に首側UV境界を試します。
3. 首側UV境界
   - 選択サブメッシュで1枚の三角形にしか使われていない外周エッジを抽出し、Head/Neck方向で最も首に近い部分を境界にします。
   - 境界からUV内側への距離でBをなじませるため、顔全体がHead=1で身体とは別Rendererになっているモデルでも利用できます。
   - Head/Neckを取得できない通常Meshでは「UV方向(度)」を使って首側を判定します。別のUV島や選択外サブメッシュの境界は使いません。
4. 補正済みHead/Neck平面
   - 首側UV境界を抽出できない場合だけ、平面を選択形状内へ安全に制約して使用します。選択頂点がHead–Neck軸上で完全に同じ位置なら無効です。
5. 手動UVグラデーション
   - ボーン情報がない通常Meshでも利用できます。
   - 選択UVチャンネルに全頂点分のUVが必要です。

明示的な「Head/Neckウェイトのみ」「Head/Neck平面のみ」「首側UV境界のみ」は診断・強制指定用です。失敗しても別方式へ自動移行しません。警告下の「自動検出へ切り替える」または「自動（推奨）」を使ってください。別Rendererのウェイト差は、現在対象と同じマテリアルを共有する場合だけ候補表示します。ウェイト差があるという理由だけで髪・身体などUVと出力先の異なるRendererへ変更してはいけません。

### パラメーター

- 境界オフセット: 正方向でB=1（通常ライティング側）を頭側へ広げます。方式ごとの相対値です。
- ブレンド幅: 0から1へ移る範囲です。小さいほど境界が鋭く、大きいほど広くなじみます。
- UV方向(度): 手動UVと首側UV境界の強制指定時に表示します。0度はUV右方向、90度はUV上方向です。UV境界ではHead/Neckを取得できない場合だけ使います。
- Bマスクを反転: 接続先シェーダーが逆の規約を要求する場合だけ使います。

まず自動・既定値でBプレビューを確認し、顎下から首にかけて滑らかに黒から白へ変化するよう、オフセット、次に幅の順で調整してください。向きが逆の場合だけ反転します。

## 6. UV境界と仕上げ

- UV境界ガウス半径 / UV境界パディング: 選択UV境界をR/G最大値へ戻し、継ぎ目を抑えます。
- UV外側パディング: UV島の外側へ最終色（Bを含む）を押し出します。
- 穴境界補正: 選択した穴の周囲だけR/G最大値の帯を作ります。
- 頬ハイライト: 指定範囲をR/G最大へ混ぜます。
- 鼻ハイライト: 指定範囲でR/Gを入れ替えます。シアン表示はプレビュー専用です。

## 7. Importer設定

「Importer設定を適用」が有効な場合、出力はDefault、sRGB無効、Uncompressed、Clamp、Bilinearになり、最大サイズは書き出し解像度へ設定されます。「ミップマップ」は用途に合わせて選択できます。

## 8. トラブルシューティング

- プレビューが出ない: 対象、サブメッシュ番号、UVチャンネルを確認します。ポーズ変更後は再生成ボタンを押します。
- プレビュー設定の警告が消えない: 一時的な入力不成立は対象設定の直下へ表示され、条件を直して再生成すると消えます。書き出し結果など画面下部の通知は「閉じる」で消せます。同じ予期しない例外はConsoleへ繰り返し記録しません。
- 全体が黄色: R/G最大の初期表示です。「生成アイランド選択」にして、ベイクしたいUV島をクリックします。
- 後頭部までR/Gが変化する: 「同一UV島の後頭部を除外」をオンにして、必ず顔側をクリックし直してください。特殊な軸構造で必要部分まで除外される場合だけオフにします。
- Bが真っ黒: B生成が無効、生成アイランド未選択、または検出失敗です。「現在の生成元」と警告を確認します。
- ウェイト方式が使われない: HeadのHumanoid AnimatorまたはFBX Configure割り当て、ボーン名、rendererのbones、頂点ウェイトに実際の境界差があるか確認します。Neckはウェイト方式には不要です。顔メッシュが全てHead=1なら「自動（推奨）」が平面または首側UV境界へ移行するのが正常です。候補名だけを見て顔用Rendererから髪・身体Rendererへ変更しないでください。
- 平面の位置が合わない: Head/Neck Transformの位置を確認し、境界オフセットとブレンド幅を調整します。0はHead–Neck中央です。選択形状外から大きな補正が必要なら、自動は首側UV境界を優先します。
- UV境界が違う場所になる: 正しい顔サブメッシュだけを選択しているか確認します。Head/NeckがないMeshではUV方向を首から頭へ向く方向に合わせてください。
- 書き出せない: 保存先は必ず `Assets/` 内にし、拡張子を `.png` にします。`../` でAssets外へ出るパスは拒否されます。
- R/Gがシェーダーと逆: 「R/Gを入れ替え」を使います。B反転とは独立しています。

---

# ACM Vail Manual (English)

## Output contract

Vail packs the right-light map into R, the left-light map into G, the optional neck blend into B (`0` face SDF, `1` regular lighting), and 255 into A. B is zero when disabled or outside selected bake islands. The cyan nose overlay is preview-only.

## Workflow

1. Open `Tools > ACM > Vail` and assign a renderer, MeshFilter, Mesh asset, or GameObject containing a mesh. When an avatar root has multiple skinned renderers, Vail prioritizes face-material names over renderer or mesh names; assign the face renderer directly if the selected target is not the intended one.
2. Enable Bake Current Pose Mesh when animation or BlendShapes must be captured. Use Rebuild Preview from Current State after pose changes.
3. Choose the submesh (`-1` means all) and UV channel.
4. Set Preview Click Action to Select Bake Island and click the face-facing portion of each UV island. With Exclude Rear of Same UV Island enabled, 3D triangles facing away from the clicked surface are excluded from R/G even when the face and rear head share one UV island. If Vail cannot resolve the direction safely, it automatically keeps the full island. Use Add Hole Border Correction for mouth-like holes when needed.
5. Choose a bake mode and tune the lighting while inspecting Final, R, G, and B. Multi-angle mode also provides the 9-Angle Grid.
6. Save to a `.png` inside `Assets/` and click Export PNG.

## Automatic B-mask chain

Automatic uses the first reliable source: Head-family skin weights; an unconstrained Neck-to-Head 3D plane; the selected submesh's UV perimeter nearest the neck; a safely constrained plane; then a manual UV gradient. Bone resolution prefers the live Humanoid Animator, then the FBX Rig > Configure human mapping, then conservative name matching. Delimited suffix names such as `Armature:Head`, `Rig|Head`, and `J_Bip_C_Head` are recognized. Weight mode requires Head only. Head and all descendants count as the face family, and variable-influence Unity skin weights are supported. Only triangles and vertices used by the selected submesh participate. A nearly uniform weight field falls through to the plane. Plane offset 0 is the anatomical midpoint, -1 is Neck, and +1 is Head. When a separate Head=1 face mesh would require moving that plane substantially, Vail first extracts open UV-perimeter edges and selects the lowest portion along the Neck-to-Head direction. The B mask then fades inward by UV distance. If no bones are available, UV Direction identifies the neck side. A constrained plane remains a safety net when no usable UV boundary exists, and Manual UV remains the last fallback.

Positive Boundary Offset extends B=1 toward the head. Blend Width controls transition softness. UV Direction uses 0 degrees for UV-right and 90 degrees for UV-up; UV Boundary consults it only when Head/Neck cannot be resolved. Use Invert B Mask only when the consuming shader uses the opposite convention.

Explicit Weights Only, Plane Only, and Neck-Side UV Boundary Only modes do not fall through when they fail; use them for diagnosis or forced behavior. Use the Switch to Automatic Detection button when a warning appears. Vail reports another renderer only when it shares a material with the current target, and it never changes the target automatically because the UV layout may still differ.

## Common problems

- No preview: verify target, submesh, UV channel, and rebuild after a pose change.
- Preview warning persists: transient input problems appear below Target and clear after a successful rebuild. Bottom export/status messages can be dismissed. Identical unexpected exceptions are logged only once.
- All yellow: this is the initial R/G-max state; select the bake UV island.
- R/G changes on the rear head: enable Exclude Rear of Same UV Island, clear the bake islands, and click the face-facing portion again. Disable it only if an unusual mesh axis removes wanted areas.
- B is black: enable B, select a bake island, and check Active Source and its warning.
- Weight mode is skipped: verify the Head assignment in the Humanoid Animator or FBX Configure mapping, bone names, renderer bones, and actual weight variation. Neck is not required for weight mode. A face mesh weighted 100% to Head correctly falls back to the plane or neck-side UV boundary.
- Wrong UV boundary: verify that only the intended face submesh is selected. For meshes without Head/Neck, point UV Direction from neck toward head.
- Export fails: use a `.png` path inside `Assets/`; paths escaping with `../` are rejected.
- R/G are reversed in the shader: use Swap R/G. This is independent of B inversion.
