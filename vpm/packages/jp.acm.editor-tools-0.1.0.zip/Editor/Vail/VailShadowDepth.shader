Shader "Hidden/ACM/VailShadowDepth"
{
    SubShader
    {
        Tags { "RenderType" = "Opaque" }
        Cull Off
        ZWrite On
        ZTest LEqual
        Blend Off

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag

            float3 _LightCenter;
            float3 _LightRight;
            float3 _LightUp;
            float3 _LightForward;
            float2 _LightHalfExtent;
            float2 _LightDepthRange;

            struct appdata
            {
                float4 vertex : POSITION;
            };

            struct v2f
            {
                float4 pos : SV_POSITION;
                float depth : TEXCOORD0;
            };

            v2f vert(appdata v)
            {
                float3 offsetPosition = v.vertex.xyz - _LightCenter;
                float x = dot(offsetPosition, _LightRight) / max(_LightHalfExtent.x, 0.0001);
                float y = dot(offsetPosition, _LightUp) / max(_LightHalfExtent.y, 0.0001);
                float depth = (dot(offsetPosition, _LightForward) - _LightDepthRange.x) / max(_LightDepthRange.y - _LightDepthRange.x, 0.0001);

                v2f o;
                o.pos = float4(x, y, depth * 2.0 - 1.0, 1.0);
                o.depth = saturate(depth);
                return o;
            }

            fixed4 frag(v2f i) : SV_Target
            {
                return fixed4(i.depth, i.depth, i.depth, 1.0);
            }
            ENDCG
        }
    }
}
