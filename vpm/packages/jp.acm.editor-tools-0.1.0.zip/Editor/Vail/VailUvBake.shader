Shader "Hidden/ACM/VailUvBake"
{
    SubShader
    {
        Tags { "RenderType" = "Opaque" }
        Cull Off
        ZWrite Off
        ZTest Always
        Blend Off

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            float3 _LightDirection;
            float3 _LightPosition;
            sampler2D _ShadowTex;
            float3 _LightCenter;
            float3 _LightRight;
            float3 _LightUp;
            float3 _LightForward;
            float2 _LightHalfExtent;
            float2 _LightDepthRange;
            float _LightRangeFeather;
            float _LightCoverage;
            float _LightRadius;
            float _ChannelCenterOffset;
            float _Softness;
            float _Contrast;
            float _NormalWrap;
            float _ShadowBias;

            struct appdata
            {
                float4 vertex : POSITION;
                float3 normal : NORMAL;
                float3 originalPosition : TEXCOORD0;
            };

            struct v2f
            {
                float4 pos : SV_POSITION;
                float3 normal : TEXCOORD0;
                float3 originalPosition : TEXCOORD1;
            };

            v2f vert(appdata v)
            {
                v2f o;
                o.pos = float4(v.vertex.xy, 0.0, 1.0);
                o.normal = normalize(v.normal);
                o.originalPosition = v.originalPosition;
                return o;
            }

            fixed4 frag(v2f i) : SV_Target
            {
                float3 pointLightVector = _LightPosition - i.originalPosition;
                float lightDistance = max(length(pointLightVector), 0.0001);
                float3 pointLightDirection = pointLightVector / lightDistance;
                float ndotl = dot(normalize(i.normal), pointLightDirection);
                float radiusWrap = _LightRadius / lightDistance;
                float effectiveWrap = max(0.0, _NormalWrap + (_LightCoverage - 1.0) * 0.75 + radiusWrap);
                float wrapped = saturate((ndotl - _ChannelCenterOffset + effectiveWrap) / (1.0 + effectiveWrap));
                float value = saturate(0.5 + (wrapped - 0.5) / max(_Softness, 0.0001));
                value = pow(value, 1.0 / max(_Contrast, 0.0001));

                float3 offsetPosition = i.originalPosition - _LightCenter;
                float2 lightUv = float2(
                    dot(offsetPosition, _LightRight) / max(_LightHalfExtent.x, 0.0001),
                    dot(offsetPosition, _LightUp) / max(_LightHalfExtent.y, 0.0001)) * 0.5 + 0.5;
                float2 lightPlane = lightUv * 2.0 - 1.0;
                float rangeMask = saturate((1.0 - length(lightPlane)) / max(_LightRangeFeather, 0.0001));
                float depth = (dot(offsetPosition, _LightForward) - _LightDepthRange.x) / max(_LightDepthRange.y - _LightDepthRange.x, 0.0001);
                float shadowDepth = tex2D(_ShadowTex, lightUv).r;
                float insideShadowMap = step(0.0, lightUv.x) * step(lightUv.x, 1.0) * step(0.0, lightUv.y) * step(lightUv.y, 1.0);
                float visible = lerp(1.0, step(depth - _ShadowBias, shadowDepth), insideShadowMap);
                value *= visible * rangeMask;
                return fixed4(value, value, value, 1.0);
            }
            ENDCG
        }
    }
}
