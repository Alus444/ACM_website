using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Serialization;

namespace ACM
{
    public sealed class VailBakerWindow : EditorWindow
    {
        private const string DefaultSaveDirectory = "Assets/ACM/Export";
        private const string DefaultSavePath = DefaultSaveDirectory + "/Vail_SDF.png";
        private const float CheekScaleUiMin = 0.1f;
        private const float CheekScaleUiReference = 1f;
        private const float CheekScaleInternalMin = 0.001f;
        private const float CheekScaleInternalReference = 0.2f;
        private const float CheekScaleInternalMax = 0.5f;
        private const string SessionKeyPrefix = "ACM.Vail.";
        private const int BakeAlgorithmVersion = 11;
        private const float OppositeFacingDotThreshold = -0.15f;
        private const float MinimumFacingMaskCoverage = 0.35f;
        private static readonly float CheekScaleUiExponent = Mathf.Log(CheekScaleInternalReference / CheekScaleInternalMin, CheekScaleUiReference / CheekScaleUiMin);
        private enum PreviewClickMode
        {
            Inspect,
            SelectLightMapIsland,
            SelectInnerBorderMaxIsland
        }

        private enum PreviewDisplayMode
        {
            FinalResult,
            RedChannel,
            GreenChannel,
            MultiAngleGrid,
            BlueChannel
        }

        private enum LightMapBakeMode
        {
            GpuLightBake = 0,
            MeshNormals = 1,
            UvGradient = 2,
            MultiAngleGpuGradient = 3
        }

        private enum CheekShape
        {
            Round,
            TriangleUp,
            TriangleDown
        }

        private enum NoseHighlightShape
        {
            Round,
            Diamond
        }

        private enum UiLanguage
        {
            Japanese,
            English
        }

        [SerializeField] private UnityEngine.Object targetObject;
        [SerializeField] private bool useSkinnedMeshBake = true;
        [SerializeField] private int subMeshIndex = -1;
        [SerializeField] private int uvChannel;

        [SerializeField] private int previewResolution = 512;
        [FormerlySerializedAs("resolution")]
        [SerializeField] private int outputResolution = 2048;
        private int resolution = 512;
        [SerializeField] private float padding;

        [SerializeField] private LightMapBakeMode bakeMode = LightMapBakeMode.MultiAngleGpuGradient;
        [SerializeField] private float lightCenterOffset;
        [SerializeField] private float lightSoftness = 0.6f;
        [SerializeField] private float lightContrast = 1f;
        [SerializeField] private float normalLightWrap = 0.9f;
        [SerializeField] private float lightForwardOffset = 0.7f;
        [SerializeField] private float lightUpOffset = -0.3f;
        [SerializeField] private float lightProjectionScale = 1.1f;
        [SerializeField] private float lightDistance = 2f;
        [SerializeField] private float lightRadius = 0.2f;
        [SerializeField] private float multiAngleFrontWeight = 0.35f;
        [SerializeField] private float multiAngleBackWeight = 1.5f;
        [SerializeField] private float shadowBias = 0.2f;
        [SerializeField] private float shapeShadowStrength = 0.7f;
        [SerializeField] private int shapeShadowRadius = 1;
        [SerializeField] private bool cheekMaxEnabled = true;
        [SerializeField] private CheekShape cheekShape = CheekShape.TriangleDown;
        [SerializeField] private float cheekOffsetX = 0.13f;
        [SerializeField] private float cheekOffsetY = -0.2f;
        [SerializeField] private float cheekScaleX = CheekScaleUiToInternal(0.3f);
        [SerializeField] private float cheekScaleY = CheekScaleUiToInternal(0.2f);
        [SerializeField] private float cheekBlurPixels = 3f;
        [SerializeField] private bool noseHighlightEnabled;
        [SerializeField] private NoseHighlightShape noseHighlightShape;
        [SerializeField] private float noseOffsetX;
        [SerializeField] private float noseOffsetY;
        [SerializeField] private float noseScaleX = CheekScaleUiToInternal(0.2f);
        [SerializeField] private float noseScaleY = CheekScaleUiToInternal(0.2f);
        [SerializeField] private float noseBlurPixels = 3f;
        [FormerlySerializedAs("islandBorderFadePixels")]
        [SerializeField] private float uvBorderFadePixels = 50f;
        [SerializeField] private int uvBorderPaddingPixels = 1;
        [SerializeField] private int uvPaddingPixels = 3;
        [SerializeField] private float innerBorderFadePixels = 10.9f;
        [SerializeField] private int innerBorderPaddingPixels = 1;
        [SerializeField] private float finalBlurPixels = 8.3f;
        [SerializeField] private bool swapRG;

        [SerializeField] private bool neckBlendEnabled;
        [SerializeField] private VailNeckBlendMode neckBlendMode = VailNeckBlendMode.Automatic;
        [SerializeField] private float neckBlendOffset = 0.15f;
        [SerializeField] private float neckBlendWidth = 0.35f;
        [SerializeField] private float neckBlendManualUvAngle = 90f;
        [SerializeField] private bool neckBlendInvert;

        [SerializeField] private string savePath = DefaultSavePath;
        [SerializeField] private bool applyImportSettings = true;
        [SerializeField] private bool generateMipMaps;
        [SerializeField] private UiLanguage uiLanguage;
        [SerializeField] private PreviewClickMode previewClickMode;
        [SerializeField] private PreviewDisplayMode previewDisplayMode;
        [SerializeField] private float innerHoleSnapMaxPixels = 24f;
        [SerializeField] private bool excludeOppositeFacingUv = true;
        [SerializeField] private List<Vector2> lightMapIslandSeeds = new List<Vector2>();
        [SerializeField] private List<Vector2> innerBorderMaxSeeds = new List<Vector2>();

        private Texture2D previewTexture;
        private Texture2D finalPreviewTexture;
        private Texture2D redChannelPreviewTexture;
        private Texture2D greenChannelPreviewTexture;
        private Texture2D blueChannelPreviewTexture;
        private Texture2D multiAngleGridPreviewTexture;
        private Vector2 settingsScroll;
        private string statusMessage;
        private MessageType statusType = MessageType.Info;
        private string previewIssueMessage;
        private HashSet<string> loggedExceptionSignatures;
        private bool previewDirty = true;
        private string cachedBaseSignature;
        private BaseBakeData cachedBaseBakeData;
        private VailNeckBlendSource activeNeckBlendSource;
        private string neckBlendDiagnostic;
        private string neckBlendAlternativeRendererDiagnostic;

        [MenuItem("Tools/ACM/Vail")]
        private static void Open()
        {
            GetWindow<VailBakerWindow>("Vail");
        }

        private void OnEnable()
        {
            titleContent = new GUIContent("Vail");
            LoadSessionSettings();
            Undo.undoRedoPerformed += HandleUndoRedoPerformed;
        }

        private void OnDisable()
        {
            Undo.undoRedoPerformed -= HandleUndoRedoPerformed;
            DestroyPreviewTextures();
        }

        private void HandleUndoRedoPerformed()
        {
            previewDirty = true;
            Repaint();
        }

        private void OnGUI()
        {
            Undo.RecordObject(this, "Vail設定変更");
            EditorGUI.BeginChangeCheck();
            using (new EditorGUILayout.HorizontalScope())
            {
                var leftWidth = Mathf.Clamp(position.width * 0.38f, 340f, 460f);
                using (new EditorGUILayout.VerticalScope(GUILayout.Width(leftWidth)))
                {
                    settingsScroll = EditorGUILayout.BeginScrollView(settingsScroll);
                    DrawResetSection();
                    DrawUvPaintSection();
                    DrawTargetSection();
                    DrawBakeAreaSection();
                    DrawLightingSection();
                    DrawOutputSection();

                    EditorGUILayout.Space();
                    using (new EditorGUI.DisabledScope(targetObject == null))
                    {
                        if (GUILayout.Button(L("PNGを書き出す", "Export PNG"), GUILayout.Height(34f)))
                        {
                            Bake();
                        }
                    }

                    DrawStatusMessage();

                    EditorGUILayout.EndScrollView();
                }

                DrawPreviewPanel();
            }

            if (EditorGUI.EndChangeCheck())
            {
                EditorUtility.SetDirty(this);
                SaveSessionSettings();
                MarkPreviewDirty();
            }

            if (previewDirty && Event.current.type == EventType.Repaint)
            {
                RefreshPreview();
            }
        }

        private void MarkPreviewDirty()
        {
            previewDirty = true;
        }

        private void LoadSessionSettings()
        {
            useSkinnedMeshBake = SessionState.GetBool(SessionKeyPrefix + nameof(useSkinnedMeshBake), useSkinnedMeshBake);
            subMeshIndex = SessionState.GetInt(SessionKeyPrefix + nameof(subMeshIndex), subMeshIndex);
            uvChannel = SessionState.GetInt(SessionKeyPrefix + nameof(uvChannel), uvChannel);
            previewResolution = SessionState.GetInt(SessionKeyPrefix + nameof(previewResolution), previewResolution);
            outputResolution = SessionState.GetInt(SessionKeyPrefix + nameof(outputResolution), SessionState.GetInt(SessionKeyPrefix + "resolution", outputResolution));
            resolution = previewResolution;
            padding = SessionState.GetFloat(SessionKeyPrefix + nameof(padding), padding);
            bakeMode = (LightMapBakeMode)SessionState.GetInt(SessionKeyPrefix + nameof(bakeMode), (int)bakeMode);
            lightCenterOffset = SessionState.GetFloat(SessionKeyPrefix + nameof(lightCenterOffset), lightCenterOffset);
            lightSoftness = SessionState.GetFloat(SessionKeyPrefix + nameof(lightSoftness), lightSoftness);
            lightContrast = SessionState.GetFloat(SessionKeyPrefix + nameof(lightContrast), lightContrast);
            normalLightWrap = SessionState.GetFloat(SessionKeyPrefix + nameof(normalLightWrap), normalLightWrap);
            lightForwardOffset = SessionState.GetFloat(SessionKeyPrefix + nameof(lightForwardOffset), lightForwardOffset);
            lightUpOffset = SessionState.GetFloat(SessionKeyPrefix + nameof(lightUpOffset), lightUpOffset);
            lightProjectionScale = SessionState.GetFloat(SessionKeyPrefix + nameof(lightProjectionScale), lightProjectionScale);
            lightDistance = SessionState.GetFloat(SessionKeyPrefix + nameof(lightDistance), lightDistance);
            lightRadius = SessionState.GetFloat(SessionKeyPrefix + nameof(lightRadius), lightRadius);
            multiAngleFrontWeight = SessionState.GetFloat(SessionKeyPrefix + nameof(multiAngleFrontWeight), multiAngleFrontWeight);
            multiAngleBackWeight = SessionState.GetFloat(SessionKeyPrefix + nameof(multiAngleBackWeight), multiAngleBackWeight);
            shadowBias = SessionState.GetFloat(SessionKeyPrefix + nameof(shadowBias), shadowBias);
            shapeShadowStrength = SessionState.GetFloat(SessionKeyPrefix + nameof(shapeShadowStrength), shapeShadowStrength);
            shapeShadowRadius = SessionState.GetInt(SessionKeyPrefix + nameof(shapeShadowRadius), shapeShadowRadius);
            cheekMaxEnabled = SessionState.GetBool(SessionKeyPrefix + nameof(cheekMaxEnabled), cheekMaxEnabled);
            cheekShape = (CheekShape)SessionState.GetInt(SessionKeyPrefix + nameof(cheekShape), (int)cheekShape);
            cheekOffsetX = SessionState.GetFloat(SessionKeyPrefix + nameof(cheekOffsetX), cheekOffsetX);
            cheekOffsetY = SessionState.GetFloat(SessionKeyPrefix + nameof(cheekOffsetY), cheekOffsetY);
            cheekScaleX = SessionState.GetFloat(SessionKeyPrefix + nameof(cheekScaleX), cheekScaleX);
            cheekScaleY = SessionState.GetFloat(SessionKeyPrefix + nameof(cheekScaleY), cheekScaleY);
            cheekBlurPixels = SessionState.GetFloat(SessionKeyPrefix + nameof(cheekBlurPixels), cheekBlurPixels);
            noseHighlightEnabled = SessionState.GetBool(SessionKeyPrefix + nameof(noseHighlightEnabled), noseHighlightEnabled);
            noseHighlightShape = (NoseHighlightShape)SessionState.GetInt(SessionKeyPrefix + nameof(noseHighlightShape), (int)noseHighlightShape);
            noseOffsetX = SessionState.GetFloat(SessionKeyPrefix + nameof(noseOffsetX), noseOffsetX);
            noseOffsetY = SessionState.GetFloat(SessionKeyPrefix + nameof(noseOffsetY), noseOffsetY);
            noseScaleX = SessionState.GetFloat(SessionKeyPrefix + nameof(noseScaleX), noseScaleX);
            noseScaleY = SessionState.GetFloat(SessionKeyPrefix + nameof(noseScaleY), noseScaleY);
            noseBlurPixels = SessionState.GetFloat(SessionKeyPrefix + nameof(noseBlurPixels), noseBlurPixels);
            uvBorderFadePixels = SessionState.GetFloat(SessionKeyPrefix + nameof(uvBorderFadePixels), uvBorderFadePixels);
            uvBorderPaddingPixels = SessionState.GetInt(SessionKeyPrefix + nameof(uvBorderPaddingPixels), uvBorderPaddingPixels);
            uvPaddingPixels = SessionState.GetInt(SessionKeyPrefix + nameof(uvPaddingPixels), uvPaddingPixels);
            innerBorderFadePixels = SessionState.GetFloat(SessionKeyPrefix + nameof(innerBorderFadePixels), innerBorderFadePixels);
            innerBorderPaddingPixels = SessionState.GetInt(SessionKeyPrefix + nameof(innerBorderPaddingPixels), innerBorderPaddingPixels);
            finalBlurPixels = SessionState.GetFloat(SessionKeyPrefix + nameof(finalBlurPixels), finalBlurPixels);
            swapRG = SessionState.GetBool(SessionKeyPrefix + nameof(swapRG), swapRG);
            neckBlendEnabled = SessionState.GetBool(SessionKeyPrefix + nameof(neckBlendEnabled), neckBlendEnabled);
            neckBlendMode = (VailNeckBlendMode)SessionState.GetInt(SessionKeyPrefix + nameof(neckBlendMode), (int)neckBlendMode);
            neckBlendOffset = SessionState.GetFloat(SessionKeyPrefix + nameof(neckBlendOffset), neckBlendOffset);
            neckBlendWidth = SessionState.GetFloat(SessionKeyPrefix + nameof(neckBlendWidth), neckBlendWidth);
            neckBlendManualUvAngle = SessionState.GetFloat(SessionKeyPrefix + nameof(neckBlendManualUvAngle), neckBlendManualUvAngle);
            neckBlendInvert = SessionState.GetBool(SessionKeyPrefix + nameof(neckBlendInvert), neckBlendInvert);
            applyImportSettings = SessionState.GetBool(SessionKeyPrefix + nameof(applyImportSettings), applyImportSettings);
            generateMipMaps = SessionState.GetBool(SessionKeyPrefix + nameof(generateMipMaps), generateMipMaps);
            uiLanguage = (UiLanguage)SessionState.GetInt(SessionKeyPrefix + nameof(uiLanguage), (int)uiLanguage);
            previewClickMode = (PreviewClickMode)SessionState.GetInt(SessionKeyPrefix + nameof(previewClickMode), (int)previewClickMode);
            previewDisplayMode = (PreviewDisplayMode)SessionState.GetInt(SessionKeyPrefix + nameof(previewDisplayMode), (int)previewDisplayMode);
            innerHoleSnapMaxPixels = SessionState.GetFloat(SessionKeyPrefix + nameof(innerHoleSnapMaxPixels), innerHoleSnapMaxPixels);
            excludeOppositeFacingUv = SessionState.GetBool(SessionKeyPrefix + nameof(excludeOppositeFacingUv), excludeOppositeFacingUv);
            savePath = SessionState.GetString(SessionKeyPrefix + nameof(savePath), savePath);
        }

        private void SaveSessionSettings()
        {
            SessionState.SetBool(SessionKeyPrefix + nameof(useSkinnedMeshBake), useSkinnedMeshBake);
            SessionState.SetInt(SessionKeyPrefix + nameof(subMeshIndex), subMeshIndex);
            SessionState.SetInt(SessionKeyPrefix + nameof(uvChannel), uvChannel);
            SessionState.SetInt(SessionKeyPrefix + nameof(previewResolution), previewResolution);
            SessionState.SetInt(SessionKeyPrefix + nameof(outputResolution), outputResolution);
            SessionState.SetFloat(SessionKeyPrefix + nameof(padding), padding);
            SessionState.SetInt(SessionKeyPrefix + nameof(bakeMode), (int)bakeMode);
            SessionState.SetFloat(SessionKeyPrefix + nameof(lightCenterOffset), lightCenterOffset);
            SessionState.SetFloat(SessionKeyPrefix + nameof(lightSoftness), lightSoftness);
            SessionState.SetFloat(SessionKeyPrefix + nameof(lightContrast), lightContrast);
            SessionState.SetFloat(SessionKeyPrefix + nameof(normalLightWrap), normalLightWrap);
            SessionState.SetFloat(SessionKeyPrefix + nameof(lightForwardOffset), lightForwardOffset);
            SessionState.SetFloat(SessionKeyPrefix + nameof(lightUpOffset), lightUpOffset);
            SessionState.SetFloat(SessionKeyPrefix + nameof(lightProjectionScale), lightProjectionScale);
            SessionState.SetFloat(SessionKeyPrefix + nameof(lightDistance), lightDistance);
            SessionState.SetFloat(SessionKeyPrefix + nameof(lightRadius), lightRadius);
            SessionState.SetFloat(SessionKeyPrefix + nameof(multiAngleFrontWeight), multiAngleFrontWeight);
            SessionState.SetFloat(SessionKeyPrefix + nameof(multiAngleBackWeight), multiAngleBackWeight);
            SessionState.SetFloat(SessionKeyPrefix + nameof(shadowBias), shadowBias);
            SessionState.SetFloat(SessionKeyPrefix + nameof(shapeShadowStrength), shapeShadowStrength);
            SessionState.SetInt(SessionKeyPrefix + nameof(shapeShadowRadius), shapeShadowRadius);
            SessionState.SetBool(SessionKeyPrefix + nameof(cheekMaxEnabled), cheekMaxEnabled);
            SessionState.SetInt(SessionKeyPrefix + nameof(cheekShape), (int)cheekShape);
            SessionState.SetFloat(SessionKeyPrefix + nameof(cheekOffsetX), cheekOffsetX);
            SessionState.SetFloat(SessionKeyPrefix + nameof(cheekOffsetY), cheekOffsetY);
            SessionState.SetFloat(SessionKeyPrefix + nameof(cheekScaleX), cheekScaleX);
            SessionState.SetFloat(SessionKeyPrefix + nameof(cheekScaleY), cheekScaleY);
            SessionState.SetFloat(SessionKeyPrefix + nameof(cheekBlurPixels), cheekBlurPixels);
            SessionState.SetBool(SessionKeyPrefix + nameof(noseHighlightEnabled), noseHighlightEnabled);
            SessionState.SetInt(SessionKeyPrefix + nameof(noseHighlightShape), (int)noseHighlightShape);
            SessionState.SetFloat(SessionKeyPrefix + nameof(noseOffsetX), noseOffsetX);
            SessionState.SetFloat(SessionKeyPrefix + nameof(noseOffsetY), noseOffsetY);
            SessionState.SetFloat(SessionKeyPrefix + nameof(noseScaleX), noseScaleX);
            SessionState.SetFloat(SessionKeyPrefix + nameof(noseScaleY), noseScaleY);
            SessionState.SetFloat(SessionKeyPrefix + nameof(noseBlurPixels), noseBlurPixels);
            SessionState.SetFloat(SessionKeyPrefix + nameof(uvBorderFadePixels), uvBorderFadePixels);
            SessionState.SetInt(SessionKeyPrefix + nameof(uvBorderPaddingPixels), uvBorderPaddingPixels);
            SessionState.SetInt(SessionKeyPrefix + nameof(uvPaddingPixels), uvPaddingPixels);
            SessionState.SetFloat(SessionKeyPrefix + nameof(innerBorderFadePixels), innerBorderFadePixels);
            SessionState.SetInt(SessionKeyPrefix + nameof(innerBorderPaddingPixels), innerBorderPaddingPixels);
            SessionState.SetFloat(SessionKeyPrefix + nameof(finalBlurPixels), finalBlurPixels);
            SessionState.SetBool(SessionKeyPrefix + nameof(swapRG), swapRG);
            SessionState.SetBool(SessionKeyPrefix + nameof(neckBlendEnabled), neckBlendEnabled);
            SessionState.SetInt(SessionKeyPrefix + nameof(neckBlendMode), (int)neckBlendMode);
            SessionState.SetFloat(SessionKeyPrefix + nameof(neckBlendOffset), neckBlendOffset);
            SessionState.SetFloat(SessionKeyPrefix + nameof(neckBlendWidth), neckBlendWidth);
            SessionState.SetFloat(SessionKeyPrefix + nameof(neckBlendManualUvAngle), neckBlendManualUvAngle);
            SessionState.SetBool(SessionKeyPrefix + nameof(neckBlendInvert), neckBlendInvert);
            SessionState.SetBool(SessionKeyPrefix + nameof(applyImportSettings), applyImportSettings);
            SessionState.SetBool(SessionKeyPrefix + nameof(generateMipMaps), generateMipMaps);
            SessionState.SetInt(SessionKeyPrefix + nameof(uiLanguage), (int)uiLanguage);
            SessionState.SetInt(SessionKeyPrefix + nameof(previewClickMode), (int)previewClickMode);
            SessionState.SetInt(SessionKeyPrefix + nameof(previewDisplayMode), (int)previewDisplayMode);
            SessionState.SetFloat(SessionKeyPrefix + nameof(innerHoleSnapMaxPixels), innerHoleSnapMaxPixels);
            SessionState.SetBool(SessionKeyPrefix + nameof(excludeOppositeFacingUv), excludeOppositeFacingUv);
            SessionState.SetString(SessionKeyPrefix + nameof(savePath), savePath);
        }

        private void DrawTargetSection()
        {
            DrawBox(L("対象", "Target"), () =>
            {
                EditorGUI.BeginChangeCheck();
                targetObject = EditorGUILayout.ObjectField(
                    C("対象オブジェクト", "Target Object", "Renderer、MeshFilter、Meshアセット、またはメッシュを持つGameObjectを指定します。", "Renderer, MeshFilter, Mesh asset, or GameObject containing a mesh."),
                    targetObject,
                    typeof(UnityEngine.Object),
                    true);
                if (EditorGUI.EndChangeCheck())
                {
                    savePath = BuildDefaultSavePathForTarget();
                }

                useSkinnedMeshBake = EditorGUILayout.Toggle(L("現在ポーズをBakeMesh", "Bake Current Pose Mesh"), useSkinnedMeshBake);
                subMeshIndex = EditorGUILayout.IntField(C("サブメッシュ番号", "Submesh Index", "-1で全サブメッシュを使います。", "Use -1 to include all submeshes."), subMeshIndex);
                uvChannel = EditorGUILayout.IntSlider(L("UVチャンネル", "UV Channel"), uvChannel, 0, 7);
                using (new EditorGUI.DisabledScope(targetObject == null))
                {
                    if (GUILayout.Button(L("現在状態からプレビューを再生成", "Rebuild Preview from Current State")))
                    {
                        cachedBaseSignature = null;
                        cachedBaseBakeData = default(BaseBakeData);
                        previewDirty = true;
                    }
                }

                if (!string.IsNullOrEmpty(previewIssueMessage))
                {
                    EditorGUILayout.HelpBox(previewIssueMessage, MessageType.Warning);
                }
            });
        }

        private void DrawBakeAreaSection()
        {
            DrawBox(L("ベイク範囲", "Bake Area"), () =>
            {
                previewResolution = EditorGUILayout.IntPopup(C("プレビュー解像度", "Preview Resolution", "リアルタイムプレビュー用の解像度です。低くすると調整が軽くなります。", "Resolution used for realtime preview. Lower values make editing faster."), previewResolution, new[] { new GUIContent("128"), new GUIContent("256"), new GUIContent("512"), new GUIContent("1024"), new GUIContent("2048") }, new[] { 128, 256, 512, 1024, 2048 });
                outputResolution = EditorGUILayout.IntPopup(C("書き出し解像度", "Export Resolution", "PNG書き出し時だけ使う解像度です。高解像度は書き出し時のみ重くなります。", "Resolution used only when exporting PNG. Higher values are expensive only during export."), outputResolution, new[] { new GUIContent("128"), new GUIContent("256"), new GUIContent("512"), new GUIContent("1024"), new GUIContent("2048"), new GUIContent("4096") }, new[] { 128, 256, 512, 1024, 2048, 4096 });
                padding = EditorGUILayout.Slider(C("UVグラデーション用余白", "UV Gradient Padding", "UVグラデーションモードで使うUV AABBの余白です。ライト照射ベイクには基本的に影響しません。", "Padding for the UV AABB used by UV Gradient mode. It usually does not affect GPU Light Bake."), padding, 0f, 0.25f);
                if (outputResolution >= 4096 && bakeMode == LightMapBakeMode.MultiAngleGpuGradient)
                {
                    EditorGUILayout.HelpBox(L("4096pxの多角度ベイクは18方向のGPU描画と高解像度のCPU画像処理を行うため、時間とメモリを多く使用します。", "A 4096 px multi-angle bake performs 18 GPU renders plus high-resolution CPU image processing and can use substantial time and memory."), MessageType.Warning);
                }
            });
        }

        private void DrawResetSection()
        {
            DrawBox(L("設定", "Settings"), () =>
            {
                DrawLanguageSwitch();
                if (GUILayout.Button(L("初期値にリセット", "Reset to Defaults"), GUILayout.Height(26f)))
                {
                    if (EditorUtility.DisplayDialog(L("初期値にリセット", "Reset to Defaults"), L("ベイク設定、選択アイランド、穴境界補正を初期値に戻します。", "Reset bake settings, selected islands, and hole border corrections to defaults."), L("リセット", "Reset"), L("キャンセル", "Cancel")))
                    {
                        ResetToDefaults();
                    }
                }
            });
        }

        private void DrawLightingSection()
        {
            DrawBox(L("SDFテクスチャ", "SDF Texture"), () =>
            {
                DrawBox(L("ベイク", "Bake"), () =>
                {
                    bakeMode = (LightMapBakeMode)EditorGUILayout.IntPopup(
                        C("ベイク方式", "Bake Mode", "ライト照射ベイクはGPUでUV空間へ描画します。MeshNormalsとUVグラデーションは補助モードです。", "GPU Light Bake renders into UV space. Mesh Normals and UV Gradient are helper modes."),
                        (int)bakeMode,
                        new[] { new GUIContent(L("ライト照射ベイク(GPU)", "GPU Light Bake")), new GUIContent(L("多角度ライトグラデーション(GPU)", "Multi-Angle Light Gradient (GPU)")), new GUIContent(L("3Dモデル法線", "Mesh Normals")), new GUIContent(L("UVグラデーション", "UV Gradient")) },
                        new[] { (int)LightMapBakeMode.GpuLightBake, (int)LightMapBakeMode.MultiAngleGpuGradient, (int)LightMapBakeMode.MeshNormals, (int)LightMapBakeMode.UvGradient });
                });

                DrawNeckBlendSection();

                var isGpuMode = bakeMode == LightMapBakeMode.GpuLightBake || bakeMode == LightMapBakeMode.MultiAngleGpuGradient;
                var usesLightPosition = isGpuMode || bakeMode == LightMapBakeMode.MeshNormals;
                var usesLightShape = isGpuMode;
                var usesCenterOffset = bakeMode != LightMapBakeMode.MultiAngleGpuGradient;
                var usesNormalWrap = bakeMode != LightMapBakeMode.UvGradient;
                var usesShadowBias = isGpuMode;
                var usesShapeShadow = bakeMode != LightMapBakeMode.MultiAngleGpuGradient;

                if (bakeMode == LightMapBakeMode.MultiAngleGpuGradient)
                {
                    DrawBox(L("多角度合成", "Multi-Angle Composite"), () =>
                    {
                        multiAngleFrontWeight = EditorGUILayout.Slider(C("正面ウェイト", "Front Weight", "正面寄り角度の合成寄与です。下げるほど正面ライトの広い白が弱くなります。", "Contribution of front-facing angles. Lower values reduce broad front-light influence."), multiAngleFrontWeight, 0f, 2f);
                        multiAngleBackWeight = EditorGUILayout.Slider(C("背面ウェイト", "Back Weight", "背面寄り角度の合成寄与です。上げるほど背面側の影境界が強く出ます。", "Contribution of back-facing angles. Higher values emphasize rear-side shadow boundaries."), multiAngleBackWeight, 0f, 3f);
                    });
                }

                if (usesLightPosition)
                {
                    DrawBox(L("ライト位置", "Light Position"), () =>
                    {
                        lightUpOffset = EditorGUILayout.Slider(C("ライト前後オフセット", "Light Forward Offset", "左右対称のまま、ライト方向を前後へ振ります。", "Moves the light direction forward/back while keeping left and right symmetric."), lightUpOffset, -1f, 1f);
                        lightForwardOffset = EditorGUILayout.Slider(C("ライト上下オフセット", "Light Vertical Offset", "左右対称のまま、ライト方向を上下へ振ります。", "Moves the light direction up/down while keeping left and right symmetric."), lightForwardOffset, -1f, 1f);
                    });
                }

                if (usesLightShape)
                {
                    DrawBox(L("ライト形状", "Light Shape"), () =>
                    {
                        lightDistance = EditorGUILayout.Slider(C("ライト距離", "Light Distance", "モデルBounds基準の距離倍率です。小さいほど近いライトになり、鼻筋などの立体差が出やすくなります。", "Distance multiplier based on model bounds. Lower values make the light closer and emphasize depth."), lightDistance, 0.25f, 10f);
                        lightRadius = EditorGUILayout.Slider(C("光源半径", "Light Source Radius", "モデルBounds基準の光源半径です。0でもライト自体は消えず、大きいほど光が回り込み、影が柔らかくなります。", "Light source radius based on model bounds. Even at 0, the light remains on; higher values wrap light and soften shadows."), lightRadius, 0f, 2f);
                        lightProjectionScale = EditorGUILayout.Slider(C("ライト照射範囲", "Light Coverage", "ライトが回り込む照射角と、ライト視点の投影範囲に効きます。広げるほど光が当たる面積が増えます。", "Affects light wrap angle and light-view projection range. Higher values increase the lit area."), lightProjectionScale, 0.25f, 5f);
                    });
                }

                DrawBox(L("ライト値", "Light Values"), () =>
                {
                    if (usesCenterOffset)
                    {
                        lightCenterOffset = EditorGUILayout.Slider(C("中心オフセット", "Center Offset", "左右ライトの中心位置をずらします。3D法線ではNdotLのしきい値、UVグラデーションでは左右分割位置に効きます。", "Offsets the center point of the left/right light response."), lightCenterOffset, -0.5f, 0.5f);
                    }

                    lightSoftness = EditorGUILayout.Slider(C("ぼかし幅", "Softness", "左右ライトの遷移幅です。3D法線とUVグラデーションの両方に効きます。", "Transition width of the left/right light maps."), lightSoftness, 0.05f, 2f);
                    lightContrast = EditorGUILayout.Slider(C("コントラスト", "Contrast", "白黒の立ち上がりを調整します。", "Controls the black/white response curve."), lightContrast, 0.25f, 4f);
                    if (usesNormalWrap)
                    {
                        normalLightWrap = EditorGUILayout.Slider(C("法線ライト回り込み", "Normal Light Wrap", "3Dモデル法線時、横向きに近い面も明るく残す量です。", "Keeps side-facing surfaces brighter in Mesh Normals mode."), normalLightWrap, 0f, 1f);
                    }
                });

                if (usesShadowBias || usesShapeShadow)
                {
                    DrawBox(L("影", "Shadow"), () =>
                    {
                        if (usesShadowBias)
                        {
                            shadowBias = EditorGUILayout.Slider(C("影バイアス", "Shadow Bias", "ライト照射ベイク時、自己影のにじみやアクネを避けるための深度バイアスです。", "Depth bias to reduce acne and bleeding in GPU Light Bake."), shadowBias, 0f, 0.25f);
                        }

                        if (usesShapeShadow)
                        {
                            shapeShadowStrength = EditorGUILayout.Slider(C("形状影強調", "Shape Shadow Strength", "UV上の法線変化を見て、鼻筋や口周りなどの細い形状影を強調します。", "Emphasizes fine shadows from normal variation in UV space."), shapeShadowStrength, 0f, 2f);
                            using (new EditorGUI.DisabledScope(shapeShadowStrength <= 0f))
                            {
                                shapeShadowRadius = EditorGUILayout.IntSlider(C("形状影半径(px)", "Shape Shadow Radius (px)", "形状影強調で見る近傍半径です。小さいほど細い影を拾います。", "Neighbor radius for shape shadow enhancement. Smaller values pick up finer shadows."), shapeShadowRadius, 1, 8);
                            }
                        }
                    });
                }

                DrawBox(L("仕上げ", "Finishing"), () =>
                {
                    finalBlurPixels = EditorGUILayout.Slider(C("最終結果ぼかし(px)", "Final Blur (px)", "左右ライトマップの最終結果だけをぼかします。UV境界MAXにはかけません。", "Blurs only the final left/right light maps. UV border MAX is not blurred by this."), finalBlurPixels, 0f, 16f);
                });

                DrawBox(L("頬ハイライト", "Cheek Highlight"), () =>
                {
                    cheekMaxEnabled = EditorGUILayout.Toggle(C("頬ハイライトを有効にする", "Enable Cheek Highlight", "頬位置にR/G最大値の影無し領域を追加します。", "Adds R/G max no-shadow highlight regions on the cheeks."), cheekMaxEnabled);
                    using (new EditorGUI.DisabledScope(!cheekMaxEnabled))
                    {
                        cheekShape = (CheekShape)EditorGUILayout.Popup(
                            C("形状", "Shape", "頬ハイライトの形です。黄色はR/G両方MAXを意味します。", "Cheek highlight shape. Yellow means both R and G are max."),
                            (int)cheekShape,
                            new[] { L("丸", "Circle"), L("三角(上向き)", "Triangle Up"), L("三角(下向き)", "Triangle Down") });
                        cheekOffsetX = EditorGUILayout.Slider(C("左右位置", "Horizontal Position", "顔UV中心から左右へ離す量です。左右対称に配置します。", "Horizontal distance from the face UV center. Placed symmetrically."), cheekOffsetX, 0f, 1f);
                        cheekOffsetY = EditorGUILayout.Slider(C("上下位置", "Vertical Position", "顔UV中心から上下へずらす量です。", "Vertical offset from the face UV center."), cheekOffsetY, -1f, 1f);
                        cheekScaleY = DrawCheekScaleSlider(C("縦スケール", "Vertical Scale", "1.0がおおよそ標準サイズです。選択UV範囲に対する頬ハイライトの縦幅です。", "1.0 is approximately the standard size. Controls cheek highlight height relative to the selected UV area."), cheekScaleY);
                        cheekScaleX = DrawCheekScaleSlider(C("横スケール", "Horizontal Scale", "1.0がおおよそ標準サイズです。選択UV範囲に対する頬ハイライトの横幅です。", "1.0 is approximately the standard size. Controls cheek highlight width relative to the selected UV area."), cheekScaleX);
                        cheekBlurPixels = EditorGUILayout.Slider(C("ぼかし(px)", "Blur (px)", "頬ハイライト形状の外側だけをぼかしてR/G最大値へ混ぜます。", "Gaussian-blurs the cheek highlight max-source into the light maps."), cheekBlurPixels, 0f, 64f);
                    }
                });

                DrawBox(L("鼻ハイライト", "Nose Highlight"), () =>
                {
                    noseHighlightEnabled = EditorGUILayout.Toggle(C("鼻ハイライトを有効にする", "Enable Nose Highlight", "指定範囲内のR/Gチャンネルを入れ替えます。", "Swaps R/G channels inside the specified nose highlight area."), noseHighlightEnabled);
                    EditorGUILayout.HelpBox(L("シアンの範囲表示はプレビュー専用です。書き出しPNGにはシアン色は入りません。", "The cyan area overlay is preview-only. The exported PNG does not include the cyan color."), MessageType.Info);
                    using (new EditorGUI.DisabledScope(!noseHighlightEnabled))
                    {
                        noseHighlightShape = (NoseHighlightShape)EditorGUILayout.Popup(
                            C("形状", "Shape", "鼻ハイライトの形です。", "Nose highlight shape."),
                            (int)noseHighlightShape,
                            new[] { L("丸", "Circle"), L("四角", "Diamond") });
                        noseOffsetX = EditorGUILayout.Slider(C("左右位置", "Horizontal Position", "顔UV中心から左右へずらす量です。", "Horizontal offset from the face UV center."), noseOffsetX, -1f, 1f);
                        noseOffsetY = EditorGUILayout.Slider(C("上下位置", "Vertical Position", "顔UV中心から上下へずらす量です。", "Vertical offset from the face UV center."), noseOffsetY, -1f, 1f);
                        noseScaleY = DrawCheekScaleSlider(C("縦スケール", "Vertical Scale", "1.0がおおよそ標準サイズです。選択UV範囲に対する鼻ハイライトの縦幅です。", "1.0 is approximately the standard size. Controls nose highlight height relative to the selected UV area."), noseScaleY);
                        noseScaleX = DrawCheekScaleSlider(C("横スケール", "Horizontal Scale", "1.0がおおよそ標準サイズです。選択UV範囲に対する鼻ハイライトの横幅です。", "1.0 is approximately the standard size. Controls nose highlight width relative to the selected UV area."), noseScaleX);
                        noseBlurPixels = EditorGUILayout.Slider(C("ぼかし(px)", "Blur (px)", "鼻ハイライト範囲のチャンネル入れ替えをガウスぼかしで混ぜます。", "Gaussian-blends the channel swap inside the nose highlight area."), noseBlurPixels, 0f, 64f);
                    }
                });

                DrawBox(L("UV境界", "UV Border"), () =>
                {
                    uvBorderFadePixels = EditorGUILayout.Slider(C("UV境界ガウス半径(px)", "UV Border Gaussian Radius (px)", "選択UV境界をR/G最大値に戻し、指定半径の内側だけガウスカーブでぼかします。", "Blends selected UV borders back to R/G max with a Gaussian influence radius."), uvBorderFadePixels, 0f, 64f);
                    uvBorderPaddingPixels = EditorGUILayout.IntSlider(C("UV境界パディング(px)", "UV Border Padding (px)", "UV境界の内側へ、R/G最大値のソースを押し出す幅です。", "Width for pushing the R/G max source inward from UV borders."), uvBorderPaddingPixels, 0, 24);
                    uvPaddingPixels = EditorGUILayout.IntSlider(C("UV外側パディング(px)", "UV Outer Padding (px)", "UV境界の外側へ最終色を押し出します。境界線や黒フチ対策です。", "Dilates final colors outside UV borders to avoid seams or black edges."), uvPaddingPixels, 0, 24);
                });

                DrawBox(L("穴境界補正", "Hole Border Correction"), () =>
                {
                    innerBorderFadePixels = EditorGUILayout.Slider(C("穴境界ガウス半径(px)", "Hole Border Gaussian Radius (px)", "穴境界補正で指定した穴の周囲だけに使うガウス半径です。", "Gaussian radius used only around holes selected for hole border correction."), innerBorderFadePixels, 0f, 64f);
                    innerBorderPaddingPixels = EditorGUILayout.IntSlider(C("穴境界パディング(px)", "Hole Border Padding (px)", "穴境界補正で指定した穴の周囲へ、R/G最大値の帯を押し出す幅です。", "Width for pushing R/G max around selected hole borders."), innerBorderPaddingPixels, 0, 24);
                });

                if (bakeMode != LightMapBakeMode.MultiAngleGpuGradient)
                {
                    DrawBox(L("チャンネル", "Channels"), () =>
                    {
                        swapRG = EditorGUILayout.Toggle(C("R/Gを入れ替え", "Swap R/G", "出力チャンネルだけを入れ替えます。白黒値は反転しません。", "Swaps only the output channels. It does not invert black/white values."), swapRG);
                    });
                }
            });
        }

        private void DrawNeckBlendSection()
        {
            DrawBox(L("首なじませ(Bチャンネル)", "Neck Blend (B Channel)"), () =>
            {
                neckBlendEnabled = EditorGUILayout.Toggle(C("Bマスクを生成", "Generate B Mask", "顔SDFから通常影へ首周辺でなじませるマスクをBチャンネルへ生成します。B=0は顔SDF側、B=1は通常影側です。", "Writes a neck transition mask to B. B=0 is the face-SDF side and B=1 is the regular-lighting side."), neckBlendEnabled);
                using (new EditorGUI.DisabledScope(!neckBlendEnabled))
                {
                    var neckBlendModes = new[]
                    {
                        VailNeckBlendMode.Automatic,
                        VailNeckBlendMode.HeadNeckWeights,
                        VailNeckBlendMode.HeadNeckPlane,
                        VailNeckBlendMode.UvBoundary,
                        VailNeckBlendMode.ManualUv
                    };
                    var selectedModeIndex = Array.IndexOf(neckBlendModes, neckBlendMode);
                    selectedModeIndex = EditorGUILayout.Popup(
                        C("検出方式", "Detection Mode", "自動はHead/Neckウェイト、無補正のHead/Neck平面、首側UV境界、補正済み平面、手動UVの順に試します。「のみ」は診断・強制指定用です。", "Automatic tries Head/Neck weights, an unconstrained Head/Neck plane, the neck-side UV boundary, a constrained plane, then manual UV. 'Only' modes are for diagnosis or forced selection."),
                        Mathf.Max(0, selectedModeIndex),
                        new[]
                        {
                            L("自動（推奨）", "Automatic (Recommended)"),
                            L("Head/Neckウェイトのみ", "Head/Neck Weights Only"),
                            L("Head/Neck平面のみ", "Head/Neck Plane Only"),
                            L("首側UV境界のみ", "Neck-Side UV Boundary Only"),
                            L("手動UVグラデーション", "Manual UV Gradient")
                        });
                    neckBlendMode = neckBlendModes[Mathf.Clamp(selectedModeIndex, 0, neckBlendModes.Length - 1)];
                    neckBlendOffset = EditorGUILayout.Slider(C("境界オフセット", "Boundary Offset", "正方向で通常影側のBマスクを頭側へ広げます。方式ごとの基準範囲に対する相対値です。", "Positive values extend the regular-lighting B mask toward the head. The value is relative to the selected detection method."), neckBlendOffset, -1f, 1f);
                    neckBlendWidth = EditorGUILayout.Slider(C("ブレンド幅", "Blend Width", "0と1の間をなだらかに遷移させる幅です。", "Width of the smooth transition between 0 and 1."), neckBlendWidth, 0.01f, 1.5f);
                    if (neckBlendMode == VailNeckBlendMode.ManualUv || neckBlendMode == VailNeckBlendMode.UvBoundary)
                    {
                        neckBlendManualUvAngle = EditorGUILayout.Slider(C("UV方向(度)", "UV Direction (deg)", "0度はUVの右方向、90度は上方向です。UV境界方式ではHead/Neckを取得できない場合だけ首側の判定に使用します。", "0 degrees is UV-right and 90 degrees is UV-up. UV Boundary uses this only when Head/Neck cannot be resolved."), neckBlendManualUvAngle, -180f, 180f);
                    }

                    neckBlendInvert = EditorGUILayout.Toggle(C("Bマスクを反転", "Invert B Mask", "B=0とB=1の向きを反転します。接続先シェーダーの仕様に合わせて使用します。", "Inverts B=0 and B=1 for shaders that expect the opposite convention."), neckBlendInvert);

                    var sourceLabel = GetNeckBlendSourceLabel(activeNeckBlendSource);
                    if (!string.IsNullOrEmpty(sourceLabel))
                    {
                        EditorGUILayout.LabelField(L("現在の生成元", "Active Source"), sourceLabel);
                    }

                    if (!string.IsNullOrEmpty(neckBlendDiagnostic))
                    {
                        EditorGUILayout.HelpBox(neckBlendDiagnostic, activeNeckBlendSource == VailNeckBlendSource.Disabled ? MessageType.Warning : MessageType.Info);
                    }

                    if (activeNeckBlendSource == VailNeckBlendSource.Disabled &&
                        (neckBlendMode == VailNeckBlendMode.HeadNeckWeights ||
                         neckBlendMode == VailNeckBlendMode.HeadNeckPlane ||
                         neckBlendMode == VailNeckBlendMode.UvBoundary) &&
                        GUILayout.Button(L("自動検出へ切り替える", "Switch to Automatic Detection")))
                    {
                        neckBlendMode = VailNeckBlendMode.Automatic;
                        cachedBaseSignature = null;
                        cachedBaseBakeData = default(BaseBakeData);
                        previewDirty = true;
                    }

                    if (!string.IsNullOrEmpty(neckBlendAlternativeRendererDiagnostic))
                    {
                        EditorGUILayout.HelpBox(neckBlendAlternativeRendererDiagnostic, MessageType.Info);
                    }
                }
            });
        }

        private string GetNeckBlendSourceLabel(VailNeckBlendSource source)
        {
            switch (source)
            {
                case VailNeckBlendSource.HeadNeckWeights:
                    return L("Head/Neckウェイト", "Head/Neck Weights");
                case VailNeckBlendSource.HeadNeckPlane:
                    return L("Head/Neck平面", "Head/Neck Plane");
                case VailNeckBlendSource.UvBoundary:
                    return L("首側UV境界", "Neck-Side UV Boundary");
                case VailNeckBlendSource.ManualUv:
                    return L("手動UVグラデーション", "Manual UV Gradient");
                default:
                    return string.Empty;
            }
        }

        private void DrawBox(string label, Action drawContent)
        {
            EditorGUILayout.Space(4f);
            using (new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EditorGUILayout.LabelField(label, EditorStyles.boldLabel);
                drawContent();
            }
        }

        private void DrawLanguageSwitch()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                uiLanguage = (UiLanguage)GUILayout.Toolbar((int)uiLanguage, new[] { "JP", "EN" }, GUILayout.Width(74f));
            }
        }

        private string L(string japanese, string english)
        {
            return uiLanguage == UiLanguage.Japanese ? japanese : english;
        }

        private GUIContent C(string japanese, string english, string japaneseTooltip = null, string englishTooltip = null)
        {
            return new GUIContent(L(japanese, english), L(japaneseTooltip ?? string.Empty, englishTooltip ?? string.Empty));
        }

        private static float DrawCheekScaleSlider(GUIContent label, float internalValue)
        {
            var uiMax = CheekScaleInternalToUi(CheekScaleInternalMax);
            var uiValue = CheekScaleInternalToUi(internalValue);
            var nextUiValue = EditorGUILayout.Slider(label, uiValue, CheekScaleUiMin, uiMax);
            return CheekScaleUiToInternal(nextUiValue);
        }

        private static float CheekScaleInternalToUi(float internalValue)
        {
            var clamped = Mathf.Clamp(internalValue, CheekScaleInternalMin, CheekScaleInternalMax);
            return CheekScaleUiMin * Mathf.Pow(clamped / CheekScaleInternalMin, 1f / CheekScaleUiExponent);
        }

        private static float CheekScaleUiToInternal(float uiValue)
        {
            var uiMax = CheekScaleInternalToUi(CheekScaleInternalMax);
            var clamped = Mathf.Clamp(uiValue, CheekScaleUiMin, uiMax);
            return CheekScaleInternalMin * Mathf.Pow(clamped / CheekScaleUiMin, CheekScaleUiExponent);
        }

        private void DrawUvPaintSection()
        {
            DrawBox(L("UVペイント", "UV Paint"), () =>
            {
                previewClickMode = (PreviewClickMode)EditorGUILayout.Popup(
                    C("プレビュークリック動作", "Preview Click Action", "生成アイランド選択はUV島をクリックします。穴境界補正追加は口などの黒い穴部分をクリックします。", "Select Bake Island clicks UV islands. Add Hole Border Correction clicks dark hole areas such as the mouth."),
                    (int)previewClickMode,
                    new[] { L("確認のみ", "Inspect Only"), L("生成アイランド選択", "Select Bake Island"), L("穴境界補正追加", "Add Hole Border Correction") });
                excludeOppositeFacingUv = EditorGUILayout.Toggle(
                    C(
                        "同一UV島の後頭部を除外",
                        "Exclude Rear of Same UV Island",
                        "顔側をクリックしたとき、同じUV島の中で3D法線が反対を向く部分をR/G生成範囲から除外します。判定できないモデルでは従来どおりUV島全体を使用します。",
                        "When the face side is clicked, excludes portions of the same UV island whose 3D normals face the opposite direction from R/G generation. If the direction cannot be resolved safely, the full UV island is used."),
                    excludeOppositeFacingUv);
                using (new EditorGUI.DisabledScope(previewClickMode != PreviewClickMode.SelectInnerBorderMaxIsland))
                {
                    innerHoleSnapMaxPixels = EditorGUILayout.Slider(C("穴スナップ距離(px)", "Hole Snap Distance (px)", "穴境界補正追加時、クリック位置が穴でない場合に近くの穴へ吸着する最大距離です。", "Maximum distance to snap to the nearest hole when the click is not directly on a hole."), innerHoleSnapMaxPixels, 0f, 128f);
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(L("生成アイランド数", "Bake Islands"), lightMapIslandSeeds.Count.ToString());
                    using (new EditorGUI.DisabledScope(lightMapIslandSeeds.Count == 0))
                    {
                        if (GUILayout.Button(L("クリア", "Clear"), GUILayout.Width(80f)))
                        {
                            Undo.RecordObject(this, L("生成アイランドをクリア", "Clear Bake Islands"));
                            lightMapIslandSeeds.Clear();
                            EditorUtility.SetDirty(this);
                            previewDirty = true;
                        }
                    }
                }

                using (new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(L("穴境界補正数", "Hole Corrections"), innerBorderMaxSeeds.Count.ToString());
                    using (new EditorGUI.DisabledScope(innerBorderMaxSeeds.Count == 0))
                    {
                        if (GUILayout.Button(L("クリア", "Clear"), GUILayout.Width(80f)))
                        {
                            Undo.RecordObject(this, L("穴境界補正をクリア", "Clear Hole Corrections"));
                            innerBorderMaxSeeds.Clear();
                            EditorUtility.SetDirty(this);
                            previewDirty = true;
                        }
                    }
                }
            });
        }

        private void DrawOutputSection()
        {
            DrawBox(L("出力", "Output"), () =>
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    savePath = EditorGUILayout.TextField(L("保存先", "Save Path"), savePath);
                    if (GUILayout.Button("...", GUILayout.Width(32f)))
                    {
                        var selectedPath = EditorUtility.SaveFilePanelInProject(
                            L("Vail SDFを保存", "Save Vail SDF"),
                            GetDefaultOutputFileName(),
                            "png",
                            L("出力PNGの保存先を選んでください。", "Choose where to save the output PNG."),
                            DefaultSaveDirectory);

                        if (!string.IsNullOrEmpty(selectedPath))
                        {
                            savePath = selectedPath;
                        }
                    }
                }

                applyImportSettings = EditorGUILayout.Toggle(L("Importer設定を適用", "Apply Importer Settings"), applyImportSettings);
                generateMipMaps = EditorGUILayout.Toggle(L("ミップマップ", "Mip Maps"), generateMipMaps);
            });
        }

        private string BuildDefaultSavePathForTarget()
        {
            var rootName = GetTargetRootName();
            var fileName = string.IsNullOrWhiteSpace(rootName)
                ? "Vail_SDF"
                : SanitizeFileName(rootName) + "_Vail_SDF";
            return DefaultSaveDirectory + "/" + fileName + ".png";
        }

        private string GetDefaultOutputFileName()
        {
            return Path.GetFileNameWithoutExtension(BuildDefaultSavePathForTarget());
        }

        private string GetTargetRootName()
        {
            switch (targetObject)
            {
                case GameObject gameObject:
                    return gameObject.transform.root.name;
                case Component component:
                    return component.transform.root.name;
                case Mesh mesh:
                    return mesh.name;
                default:
                    return string.Empty;
            }
        }

        private static string SanitizeFileName(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                return "Vail_SDF";
            }

            var invalidChars = Path.GetInvalidFileNameChars();
            var sanitized = fileName.Trim();
            for (var i = 0; i < invalidChars.Length; i++)
            {
                sanitized = sanitized.Replace(invalidChars[i], '_');
            }

            return string.IsNullOrWhiteSpace(sanitized) ? "Vail_SDF" : sanitized;
        }

        private void DrawPreviewPanel()
        {
            using (new EditorGUILayout.VerticalScope())
            {
                EditorGUILayout.LabelField(L("プレビュー", "Preview"), EditorStyles.boldLabel);
                EditorGUILayout.HelpBox(L("赤 = R / 緑 = G / 青 = 首なじませB / 黄 = R/G最大 / 水色 = 鼻ハイライト範囲(プレビュー専用)", "Red = R / Green = G / Blue = neck-blend B / Yellow = R/G max / Cyan = nose-highlight area (preview only)"), MessageType.None);
                var canShowMultiAngleGrid = bakeMode == LightMapBakeMode.MultiAngleGpuGradient;
                var previewModes = canShowMultiAngleGrid
                    ? new[] { PreviewDisplayMode.FinalResult, PreviewDisplayMode.RedChannel, PreviewDisplayMode.GreenChannel, PreviewDisplayMode.BlueChannel, PreviewDisplayMode.MultiAngleGrid }
                    : new[] { PreviewDisplayMode.FinalResult, PreviewDisplayMode.RedChannel, PreviewDisplayMode.GreenChannel, PreviewDisplayMode.BlueChannel };
                var previewLabels = canShowMultiAngleGrid
                    ? new[] { L("最終結果", "Final"), "R", "G", "B", L("9角度グリッド", "9-Angle Grid") }
                    : new[] { L("最終結果", "Final"), "R", "G", "B" };
                var selectedPreviewIndex = Array.IndexOf(previewModes, previewDisplayMode);
                if (selectedPreviewIndex < 0)
                {
                    selectedPreviewIndex = 0;
                    previewDisplayMode = PreviewDisplayMode.FinalResult;
                }

                var wasChanged = GUI.changed;
                var nextPreviewIndex = GUILayout.Toolbar(selectedPreviewIndex, previewLabels);
                if (nextPreviewIndex != selectedPreviewIndex)
                {
                    previewDisplayMode = previewModes[nextPreviewIndex];
                    previewTexture = GetSelectedPreviewTexture();
                    if (previewDisplayMode == PreviewDisplayMode.MultiAngleGrid && multiAngleGridPreviewTexture == null)
                    {
                        previewDirty = true;
                    }

                    SaveSessionSettings();
                    Repaint();
                }

                GUI.changed = wasChanged;

                var area = GUILayoutUtility.GetRect(256f, 8192f, 256f, 8192f, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
                var size = Mathf.Min(area.width, area.height);
                var rect = new Rect(
                    area.x + (area.width - size) * 0.5f,
                    area.y,
                    size,
                    size);

                EditorGUI.DrawRect(rect, Color.black);
                if (previewTexture != null)
                {
                    EditorGUI.DrawPreviewTexture(rect, previewTexture, null, ScaleMode.ScaleToFit);
                    if (previewTexture == finalPreviewTexture)
                    {
                        HandlePreviewClick(rect);
                    }
                }
                else
                {
                    var labelStyle = new GUIStyle(EditorStyles.centeredGreyMiniLabel)
                    {
                        alignment = TextAnchor.MiddleCenter,
                        wordWrap = true
                    };
                    EditorGUI.LabelField(rect, L("まだプレビューはありません。\n対象を指定すると自動更新されます。", "No preview yet.\nAssign a target to update automatically."), labelStyle);
                }
            }
        }

        private void HandlePreviewClick(Rect rect)
        {
            var currentEvent = Event.current;
            if (previewClickMode == PreviewClickMode.Inspect || currentEvent.type != EventType.MouseDown || currentEvent.button != 0)
            {
                return;
            }

            if (!rect.Contains(currentEvent.mousePosition))
            {
                return;
            }

            var normalizedX = Mathf.InverseLerp(rect.xMin, rect.xMax, currentEvent.mousePosition.x);
            var normalizedY = 1f - Mathf.InverseLerp(rect.yMin, rect.yMax, currentEvent.mousePosition.y);
            var uv = new Vector2(Mathf.Clamp01(normalizedX), Mathf.Clamp01(normalizedY));
            if (previewClickMode == PreviewClickMode.SelectLightMapIsland)
            {
                if (!TryResolveLightMapIslandSeed(uv, out uv, out var message))
                {
                    SetStatus(message, MessageType.Info);
                    currentEvent.Use();
                    return;
                }

                Undo.RecordObject(this, L("生成アイランドを追加", "Add Bake Island"));
                lightMapIslandSeeds.Add(uv);
            }
            else if (previewClickMode == PreviewClickMode.SelectInnerBorderMaxIsland)
            {
                if (!TryResolveInnerHoleSeed(uv, out uv, out var message))
                {
                    SetStatus(message, MessageType.Info);
                    currentEvent.Use();
                    return;
                }

                Undo.RecordObject(this, L("穴境界補正を追加", "Add Hole Border Correction"));
                innerBorderMaxSeeds.Add(uv);
            }

            EditorUtility.SetDirty(this);
            currentEvent.Use();
            previewDirty = true;
        }

        private bool TryResolveLightMapIslandSeed(Vector2 clickedUv, out Vector2 seedUv, out string message)
        {
            seedUv = clickedUv;
            message = string.Empty;

            Mesh temporaryMesh = null;
            try
            {
                if (!TryGetMesh(out var mesh, out temporaryMesh, out _))
                {
                    message = L("対象からメッシュを取得できませんでした。", "Could not get a mesh from the target.");
                    return false;
                }

                var targetUvData = CollectTargetUvData(mesh, uvChannel, subMeshIndex);
                if (targetUvData.TriangleUvs.Count == 0)
                {
                    message = L("指定したUVチャンネルまたはサブメッシュにUV三角形がありません。", "The selected UV channel or submesh has no UV triangles.");
                    return false;
                }

                var uvCoverageMask = GenerateUvCoverageMask(targetUvData.TriangleUvs);
                var seedX = Mathf.Clamp(Mathf.FloorToInt(clickedUv.x * resolution), 0, resolution - 1);
                var seedY = Mathf.Clamp(Mathf.FloorToInt(clickedUv.y * resolution), 0, resolution - 1);
                var seedIndex = seedX + seedY * resolution;
                if (!uvCoverageMask[seedIndex])
                {
                    message = L("クリック位置にUVアイランドがありません。", "There is no UV island at the clicked position.");
                    return false;
                }

                var selectedMask = GenerateUnrestrictedLightMapIslandMask(uvCoverageMask);
                if (selectedMask[seedIndex])
                {
                    message = L("この生成アイランドはすでに追加済みです。", "This bake island has already been added.");
                    return false;
                }

                seedUv = PixelCenterToUv(seedX, seedY);
                return true;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                LogUnexpectedExceptionOnce(ex);
                return false;
            }
            finally
            {
                if (temporaryMesh != null)
                {
                    DestroyImmediate(temporaryMesh);
                }
            }
        }

        private bool TryResolveInnerHoleSeed(Vector2 clickedUv, out Vector2 seedUv, out string message)
        {
            seedUv = clickedUv;
            message = string.Empty;

            if (!TryBuildCurrentLightMapIslandMask(out var lightMapIslandMask, out var errorMessage))
            {
                message = errorMessage;
                return false;
            }

            if (lightMapIslandSeeds.Count == 0)
            {
                message = L("生成アイランドが未選択です。先に生成アイランドをクリックしてください。", "No bake island is selected. Click a bake island first.");
                return false;
            }

            var exteriorOutsideMask = BuildExteriorOutsideMask(lightMapIslandMask);
            var clickedX = Mathf.Clamp(Mathf.FloorToInt(clickedUv.x * resolution), 0, resolution - 1);
            var clickedY = Mathf.Clamp(Mathf.FloorToInt(clickedUv.y * resolution), 0, resolution - 1);
            var clickedIndex = clickedX + clickedY * resolution;
            if (IsInteriorHolePixel(lightMapIslandMask, exteriorOutsideMask, clickedIndex))
            {
                seedUv = PixelCenterToUv(clickedX, clickedY);
                return !IsAlreadySelectedInnerHole(lightMapIslandMask, seedUv, out message);
            }

            var radius = Mathf.RoundToInt(innerHoleSnapMaxPixels);
            if (radius <= 0)
            {
                message = L("クリック位置は内側の穴ではありません。", "The clicked position is not an inner hole.");
                return false;
            }

            var bestIndex = -1;
            var bestDistanceSquared = radius * radius + 1;
            var minX = Mathf.Max(0, clickedX - radius);
            var maxX = Mathf.Min(resolution - 1, clickedX + radius);
            var minY = Mathf.Max(0, clickedY - radius);
            var maxY = Mathf.Min(resolution - 1, clickedY + radius);

            for (var y = minY; y <= maxY; y++)
            {
                for (var x = minX; x <= maxX; x++)
                {
                    var offsetX = x - clickedX;
                    var offsetY = y - clickedY;
                    var distanceSquared = offsetX * offsetX + offsetY * offsetY;
                    if (distanceSquared > radius * radius || distanceSquared >= bestDistanceSquared)
                    {
                        continue;
                    }

                    var index = x + y * resolution;
                    if (!IsInteriorHolePixel(lightMapIslandMask, exteriorOutsideMask, index))
                    {
                        continue;
                    }

                    bestDistanceSquared = distanceSquared;
                    bestIndex = index;
                }
            }

            if (bestIndex < 0)
            {
                message = L("近くに内側の穴がありません。穴スナップ距離を広げるか、穴の上をクリックしてください。", "No inner hole was found nearby. Increase the snap distance or click directly on a hole.");
                return false;
            }

            seedUv = PixelCenterToUv(bestIndex % resolution, bestIndex / resolution);
            return !IsAlreadySelectedInnerHole(lightMapIslandMask, seedUv, out message);
        }

        private bool TryBuildCurrentLightMapIslandMask(out bool[] lightMapIslandMask, out string errorMessage)
        {
            lightMapIslandMask = null;
            errorMessage = string.Empty;

            Mesh temporaryMesh = null;
            try
            {
                if (!TryGetMesh(out var mesh, out temporaryMesh, out _))
                {
                    errorMessage = L("対象からメッシュを取得できませんでした。", "Could not get a mesh from the target.");
                    return false;
                }

                var targetUvData = CollectTargetUvData(mesh, uvChannel, subMeshIndex);
                if (targetUvData.TriangleUvs.Count == 0)
                {
                    errorMessage = L("指定したUVチャンネルまたはサブメッシュにUV三角形がありません。", "The selected UV channel or submesh has no UV triangles.");
                    return false;
                }

                var uvCoverageMask = GenerateUvCoverageMask(targetUvData.TriangleUvs);
                lightMapIslandMask = GenerateLightMapIslandMask(targetUvData, uvCoverageMask);
                return true;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                LogUnexpectedExceptionOnce(ex);
                return false;
            }
            finally
            {
                if (temporaryMesh != null)
                {
                    DestroyImmediate(temporaryMesh);
                }
            }
        }

        private bool IsAlreadySelectedInnerHole(bool[] lightMapIslandMask, Vector2 seedUv, out string message)
        {
            var existingHoleMask = GenerateInnerBorderHoleMask(lightMapIslandMask);
            var seedX = Mathf.Clamp(Mathf.FloorToInt(seedUv.x * resolution), 0, resolution - 1);
            var seedY = Mathf.Clamp(Mathf.FloorToInt(seedUv.y * resolution), 0, resolution - 1);
            var seedIndex = seedX + seedY * resolution;
            if (existingHoleMask[seedIndex])
            {
                message = L("この穴境界補正はすでに追加済みです。", "This hole border correction has already been added.");
                return true;
            }

            message = string.Empty;
            return false;
        }

        private static bool IsInteriorHolePixel(bool[] islandMask, bool[] exteriorOutsideMask, int index)
        {
            return !islandMask[index] && !exteriorOutsideMask[index];
        }

        private Vector2 PixelCenterToUv(int x, int y)
        {
            return new Vector2((x + 0.5f) / resolution, (y + 0.5f) / resolution);
        }

        private void ResetToDefaults()
        {
            Undo.RecordObject(this, "Vail設定を初期化");
            useSkinnedMeshBake = true;
            subMeshIndex = -1;
            uvChannel = 0;
            previewResolution = 512;
            outputResolution = 2048;
            resolution = previewResolution;
            padding = 0f;
            bakeMode = LightMapBakeMode.MultiAngleGpuGradient;
            lightCenterOffset = 0f;
            lightSoftness = 0.6f;
            lightContrast = 1f;
            normalLightWrap = 0.9f;
            lightForwardOffset = 0.7f;
            lightUpOffset = -0.3f;
            lightProjectionScale = 1.1f;
            lightDistance = 2f;
            lightRadius = 0.2f;
            multiAngleFrontWeight = 0.35f;
            multiAngleBackWeight = 1.5f;
            shadowBias = 0.2f;
            shapeShadowStrength = 0.7f;
            shapeShadowRadius = 1;
            cheekMaxEnabled = true;
            cheekShape = CheekShape.TriangleDown;
            cheekOffsetX = 0.13f;
            cheekOffsetY = -0.2f;
            cheekScaleX = CheekScaleUiToInternal(0.3f);
            cheekScaleY = CheekScaleUiToInternal(0.2f);
            cheekBlurPixels = 3f;
            noseHighlightEnabled = false;
            noseHighlightShape = NoseHighlightShape.Round;
            noseOffsetX = 0f;
            noseOffsetY = 0f;
            noseScaleX = CheekScaleUiToInternal(0.2f);
            noseScaleY = CheekScaleUiToInternal(0.2f);
            noseBlurPixels = 3f;
            uvBorderFadePixels = 50f;
            uvBorderPaddingPixels = 1;
            uvPaddingPixels = 3;
            innerBorderFadePixels = 10.9f;
            innerBorderPaddingPixels = 1;
            finalBlurPixels = 8.3f;
            swapRG = false;
            neckBlendEnabled = false;
            neckBlendMode = VailNeckBlendMode.Automatic;
            neckBlendOffset = 0.15f;
            neckBlendWidth = 0.35f;
            neckBlendManualUvAngle = 90f;
            neckBlendInvert = false;
            activeNeckBlendSource = VailNeckBlendSource.Disabled;
            neckBlendDiagnostic = string.Empty;
            ClearNeckBlendAlternativeRendererDiagnostic();
            previewIssueMessage = string.Empty;
            applyImportSettings = true;
            generateMipMaps = false;
            previewClickMode = PreviewClickMode.Inspect;
            previewDisplayMode = PreviewDisplayMode.FinalResult;
            innerHoleSnapMaxPixels = 24f;
            excludeOppositeFacingUv = true;
            lightMapIslandSeeds.Clear();
            innerBorderMaxSeeds.Clear();
            statusMessage = L("設定を初期値に戻しました。", "Settings were reset to defaults.");
            statusType = MessageType.Info;
            EditorUtility.SetDirty(this);
            SaveSessionSettings();
            previewDirty = true;
            Repaint();
        }

        private void Bake()
        {
            if (!TryGenerateBakeResult(out var bakeResult, out var errorMessage, true, outputResolution))
            {
                resolution = previewResolution;
                SetStatus(errorMessage, MessageType.Error);
                return;
            }

            try
            {
                SavePng(bakeResult.LightTexture, savePath, true);

                previewDirty = true;
                resolution = previewResolution;

                SetStatus(L("Vail SDFを保存しました: ", "Saved Vail SDF: ") + savePath, MessageType.Info);
            }
            catch (Exception ex)
            {
                SetStatus(ex.Message, MessageType.Error);
                LogUnexpectedExceptionOnce(ex);
            }
            finally
            {
                resolution = previewResolution;
                if (bakeResult.LightTexture != null)
                {
                    DestroyImmediate(bakeResult.LightTexture);
                }

                if (bakeResult.DebugPreviewTexture != null)
                {
                    DestroyImmediate(bakeResult.DebugPreviewTexture);
                }

                if (bakeResult.RedChannelPreviewTexture != null)
                {
                    DestroyImmediate(bakeResult.RedChannelPreviewTexture);
                }

                if (bakeResult.GreenChannelPreviewTexture != null)
                {
                    DestroyImmediate(bakeResult.GreenChannelPreviewTexture);
                }

                if (bakeResult.BlueChannelPreviewTexture != null)
                {
                    DestroyImmediate(bakeResult.BlueChannelPreviewTexture);
                }

                if (bakeResult.MultiAngleGridPreviewTexture != null)
                {
                    DestroyImmediate(bakeResult.MultiAngleGridPreviewTexture);
                }
            }
        }

        private void RefreshPreview()
        {
            previewDirty = false;
            if (targetObject == null)
            {
                previewIssueMessage = string.Empty;
                activeNeckBlendSource = VailNeckBlendSource.Disabled;
                neckBlendDiagnostic = string.Empty;
                ClearNeckBlendAlternativeRendererDiagnostic();
                cachedBaseSignature = null;
                cachedBaseBakeData = default(BaseBakeData);
                DestroyPreviewTextures();
                return;
            }

            if (!TryGenerateBakeResult(out var bakeResult, out var errorMessage, false, previewResolution))
            {
                previewIssueMessage = errorMessage;
                Repaint();
                return;
            }

            previewIssueMessage = string.Empty;
            ReplacePreviewTextures(bakeResult.DebugPreviewTexture, bakeResult.RedChannelPreviewTexture, bakeResult.GreenChannelPreviewTexture, bakeResult.BlueChannelPreviewTexture, bakeResult.MultiAngleGridPreviewTexture);
            if (bakeResult.LightTexture != null)
            {
                DestroyImmediate(bakeResult.LightTexture);
            }
        }

        private bool TryGenerateBakeResult(out BakeResult bakeResult, out string errorMessage, bool forceBaseRefresh, int requestedResolution)
        {
            bakeResult = default(BakeResult);
            errorMessage = string.Empty;
            resolution = Mathf.Max(1, requestedResolution);

            try
            {
                var signature = BuildBaseBakeSignature();
                if (!forceBaseRefresh && cachedBaseBakeData.IsValid && cachedBaseSignature == signature)
                {
                    bakeResult = BuildTextures(
                        cachedBaseBakeData.UvCoverageMask,
                        cachedBaseBakeData.LightMapIslandMask,
                        cachedBaseBakeData.LightMapUvBounds,
                        cachedBaseBakeData.MultiAnglePreviewMaps,
                        cachedBaseBakeData.IsMultiAngleGradient,
                        (byte[])cachedBaseBakeData.LeftLightMap.Clone(),
                        (byte[])cachedBaseBakeData.RightLightMap.Clone(),
                        (byte[])cachedBaseBakeData.NeckBlendMap.Clone());
                    return true;
                }

                if (!TryGetMesh(out var mesh, out var temporaryMesh, out var sourceSkinnedMeshRenderer))
                {
                    activeNeckBlendSource = VailNeckBlendSource.Disabled;
                    neckBlendDiagnostic = string.Empty;
                    ClearNeckBlendAlternativeRendererDiagnostic();
                    errorMessage = L("対象からメッシュを取得できませんでした。", "Could not get a mesh from the target.");
                    return false;
                }

                try
                {
                    var targetUvData = CollectTargetUvData(mesh, uvChannel, subMeshIndex, sourceSkinnedMeshRenderer);
                    if (targetUvData.BoundsUvs.Count == 0)
                    {
                        errorMessage = L("指定したUVチャンネルまたはサブメッシュにUVがありません。\n", "The selected UV channel or submesh has no UVs.\n") + BuildMeshUvSummary(mesh);
                        return false;
                    }

                    if (targetUvData.TriangleUvs.Count == 0)
                    {
                        errorMessage = L("指定したサブメッシュに有効なUV三角形がありません。サブメッシュ番号とUVチャンネルを確認してください。", "The selected submesh has no valid UV triangles. Check the submesh index and UV channel.");
                        return false;
                    }

                    var uvBounds = CalculateUvBounds(targetUvData.BoundsUvs, padding);
                    bakeResult = GenerateTextures(uvBounds, targetUvData, forceBaseRefresh);
                    return true;
                }
                finally
                {
                    if (temporaryMesh != null)
                    {
                        DestroyImmediate(temporaryMesh);
                    }
                }
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                LogUnexpectedExceptionOnce(ex);
                return false;
            }
        }

        private void ReplacePreviewTextures(Texture2D finalTexture, Texture2D redChannelTexture, Texture2D greenChannelTexture, Texture2D blueChannelTexture, Texture2D multiAngleGridTexture)
        {
            DestroyPreviewTextures();
            finalPreviewTexture = finalTexture;
            redChannelPreviewTexture = redChannelTexture;
            greenChannelPreviewTexture = greenChannelTexture;
            blueChannelPreviewTexture = blueChannelTexture;
            multiAngleGridPreviewTexture = multiAngleGridTexture;
            if (multiAngleGridPreviewTexture == null && previewDisplayMode == PreviewDisplayMode.MultiAngleGrid)
            {
                previewDisplayMode = PreviewDisplayMode.FinalResult;
            }

            previewTexture = GetSelectedPreviewTexture();
            Repaint();
        }

        private Texture2D GetSelectedPreviewTexture()
        {
            if (previewDisplayMode == PreviewDisplayMode.MultiAngleGrid && multiAngleGridPreviewTexture != null)
            {
                return multiAngleGridPreviewTexture;
            }
            if (previewDisplayMode == PreviewDisplayMode.RedChannel && redChannelPreviewTexture != null)
            {
                return redChannelPreviewTexture;
            }
            if (previewDisplayMode == PreviewDisplayMode.GreenChannel && greenChannelPreviewTexture != null)
            {
                return greenChannelPreviewTexture;
            }
            if (previewDisplayMode == PreviewDisplayMode.BlueChannel && blueChannelPreviewTexture != null)
            {
                return blueChannelPreviewTexture;
            }

            return finalPreviewTexture;
        }

        private void DestroyPreviewTextures()
        {
            if (finalPreviewTexture != null)
            {
                DestroyImmediate(finalPreviewTexture);
            }

            if (multiAngleGridPreviewTexture != null)
            {
                DestroyImmediate(multiAngleGridPreviewTexture);
            }
            if (redChannelPreviewTexture != null)
            {
                DestroyImmediate(redChannelPreviewTexture);
            }
            if (greenChannelPreviewTexture != null)
            {
                DestroyImmediate(greenChannelPreviewTexture);
            }
            if (blueChannelPreviewTexture != null)
            {
                DestroyImmediate(blueChannelPreviewTexture);
            }

            finalPreviewTexture = null;
            redChannelPreviewTexture = null;
            greenChannelPreviewTexture = null;
            blueChannelPreviewTexture = null;
            multiAngleGridPreviewTexture = null;
            previewTexture = null;
        }

        private bool TryGetMesh(out Mesh mesh, out Mesh temporaryMesh, out SkinnedMeshRenderer sourceSkinnedMeshRenderer)
        {
            mesh = null;
            temporaryMesh = null;
            sourceSkinnedMeshRenderer = null;

            if (targetObject == null)
            {
                return false;
            }

            if (targetObject is Mesh directMesh)
            {
                mesh = directMesh;
                return true;
            }

            if (targetObject is GameObject gameObject)
            {
                if (!gameObject.TryGetComponent<SkinnedMeshRenderer>(out var gameObjectSkinnedMeshRenderer))
                {
                    gameObjectSkinnedMeshRenderer = FindBestTargetSkinnedMeshRenderer(gameObject);
                }

                if (gameObjectSkinnedMeshRenderer != null)
                {
                    sourceSkinnedMeshRenderer = gameObjectSkinnedMeshRenderer;
                    return TryGetMeshFromSkinnedRenderer(gameObjectSkinnedMeshRenderer, out mesh, out temporaryMesh);
                }

                if (!gameObject.TryGetComponent<MeshFilter>(out var gameObjectMeshFilter))
                {
                    gameObjectMeshFilter = gameObject.GetComponentInChildren<MeshFilter>();
                }

                if (gameObjectMeshFilter != null && gameObjectMeshFilter.sharedMesh != null)
                {
                    mesh = gameObjectMeshFilter.sharedMesh;
                    return true;
                }

                return false;
            }

            if (targetObject is SkinnedMeshRenderer skinnedMeshRenderer)
            {
                sourceSkinnedMeshRenderer = skinnedMeshRenderer;
                return TryGetMeshFromSkinnedRenderer(skinnedMeshRenderer, out mesh, out temporaryMesh);
            }

            if (targetObject is MeshFilter directMeshFilter && directMeshFilter.sharedMesh != null)
            {
                mesh = directMeshFilter.sharedMesh;
                return true;
            }

            if (targetObject is Renderer renderer && renderer.TryGetComponent<MeshFilter>(out var meshFilter) && meshFilter.sharedMesh != null)
            {
                mesh = meshFilter.sharedMesh;
                return true;
            }

            return false;
        }

        private bool TryGetMeshFromSkinnedRenderer(SkinnedMeshRenderer skinnedMeshRenderer, out Mesh mesh, out Mesh temporaryMesh)
        {
            mesh = null;
            temporaryMesh = null;

            if (skinnedMeshRenderer.sharedMesh == null)
            {
                return false;
            }

            if (useSkinnedMeshBake)
            {
                temporaryMesh = new Mesh
                {
                    name = skinnedMeshRenderer.sharedMesh.name + "_BakedForVail"
                };
                skinnedMeshRenderer.BakeMesh(temporaryMesh);
                CopyUvAndTopologyIfNeeded(skinnedMeshRenderer.sharedMesh, temporaryMesh);
                mesh = temporaryMesh;
                return true;
            }

            mesh = skinnedMeshRenderer.sharedMesh;
            return true;
        }

        private static void CopyUvAndTopologyIfNeeded(Mesh sourceMesh, Mesh bakedMesh)
        {
            if (sourceMesh == null || bakedMesh == null)
            {
                return;
            }

            if (bakedMesh.vertexCount != sourceMesh.vertexCount)
            {
                return;
            }

            for (var channel = 0; channel < 8; channel++)
            {
                var bakedUvs = new List<Vector4>();
                bakedMesh.GetUVs(channel, bakedUvs);
                if (bakedUvs.Count > 0)
                {
                    continue;
                }

                var sourceUvs = new List<Vector4>();
                sourceMesh.GetUVs(channel, sourceUvs);
                if (sourceUvs.Count == sourceMesh.vertexCount)
                {
                    bakedMesh.SetUVs(channel, sourceUvs);
                }
            }

            if (bakedMesh.subMeshCount > 0 && bakedMesh.subMeshCount == sourceMesh.subMeshCount && bakedMesh.GetIndexCount(0) > 0)
            {
                return;
            }

            bakedMesh.subMeshCount = sourceMesh.subMeshCount;
            for (var subMesh = 0; subMesh < sourceMesh.subMeshCount; subMesh++)
            {
                bakedMesh.SetTriangles(sourceMesh.GetTriangles(subMesh), subMesh);
            }
        }

        private TargetUvData CollectTargetUvData(Mesh mesh, int channel, int selectedSubMesh, SkinnedMeshRenderer sourceSkinnedMeshRenderer = null)
        {
            var allUv4 = new List<Vector4>();
            mesh.GetUVs(channel, allUv4);
            if (allUv4.Count == 0)
            {
                activeNeckBlendSource = VailNeckBlendSource.Disabled;
                neckBlendDiagnostic = neckBlendEnabled ? L("選択UVチャンネルに頂点UVがありません。", "The selected UV channel has no vertex UVs.") : string.Empty;
                ClearNeckBlendAlternativeRendererDiagnostic();
                return new TargetUvData(new List<Vector2>(), new List<Vector2>(), new List<Vector3>(), new List<Vector3>(), new List<float>());
            }

            var allUvs = new List<Vector2>(allUv4.Count);
            for (var i = 0; i < allUv4.Count; i++)
            {
                allUvs.Add(new Vector2(allUv4[i].x, allUv4[i].y));
            }

            var triangleIndices = new List<int>();
            if (selectedSubMesh == -1)
            {
                for (var subMesh = 0; subMesh < mesh.subMeshCount; subMesh++)
                {
                    triangleIndices.AddRange(mesh.GetTriangles(subMesh));
                }
            }
            else if (selectedSubMesh >= 0 && selectedSubMesh < mesh.subMeshCount)
            {
                triangleIndices.AddRange(mesh.GetTriangles(selectedSubMesh));
            }
            else
            {
                activeNeckBlendSource = VailNeckBlendSource.Disabled;
                neckBlendDiagnostic = neckBlendEnabled
                    ? L("選択サブメッシュが対象メッシュの範囲外です。", "The selected submesh is outside the target mesh range.")
                    : string.Empty;
                ClearNeckBlendAlternativeRendererDiagnostic();
                return new TargetUvData(allUvs, new List<Vector2>(), new List<Vector3>(), new List<Vector3>(), new List<float>());
            }

            if (triangleIndices.Count == 0)
            {
                activeNeckBlendSource = VailNeckBlendSource.Disabled;
                neckBlendDiagnostic = neckBlendEnabled
                    ? L("選択サブメッシュに有効な三角形がありません。", "The selected submesh has no usable triangles.")
                    : string.Empty;
                ClearNeckBlendAlternativeRendererDiagnostic();
                return new TargetUvData(allUvs, new List<Vector2>(), new List<Vector3>(), new List<Vector3>(), new List<float>());
            }

            var usedIndices = new HashSet<int>(triangleIndices);
            var relevantVertexIndices = new List<int>(usedIndices);
            float[] allNeckBlendValues = null;
            if (neckBlendEnabled)
            {
                var neckBlendData = VailNeckBlendUtility.Build(
                    mesh,
                    sourceSkinnedMeshRenderer,
                    channel,
                    neckBlendMode,
                    neckBlendOffset,
                    neckBlendWidth,
                    neckBlendManualUvAngle,
                    neckBlendInvert,
                    relevantVertexIndices,
                    triangleIndices);
                allNeckBlendValues = neckBlendData.Values;
                activeNeckBlendSource = neckBlendData.Source;
                neckBlendDiagnostic = LocalizeNeckBlendDiagnostic(neckBlendData.Source, neckBlendData.Diagnostic);
                UpdateNeckBlendAlternativeRendererDiagnostic(sourceSkinnedMeshRenderer, neckBlendData.Source);
            }
            else
            {
                activeNeckBlendSource = VailNeckBlendSource.Disabled;
                neckBlendDiagnostic = string.Empty;
                ClearNeckBlendAlternativeRendererDiagnostic();
            }

            var allNormals = mesh.normals;
            var normalsAreUsable = allNormals != null && allNormals.Length == mesh.vertexCount;
            var allVertices = mesh.vertices;
            var verticesAreUsable = allVertices != null && allVertices.Length == mesh.vertexCount;
            var result = new List<Vector2>(usedIndices.Count);

            foreach (var index in usedIndices)
            {
                if (index >= 0 && index < allUvs.Count)
                {
                    result.Add(allUvs[index]);
                }
            }

            var triangleUvs = new List<Vector2>(triangleIndices.Count);
            var triangleNormals = new List<Vector3>(triangleIndices.Count);
            var trianglePositions = new List<Vector3>(triangleIndices.Count);
            var triangleNeckBlendValues = new List<float>(triangleIndices.Count);
            for (var i = 0; i < triangleIndices.Count; i++)
            {
                var index = triangleIndices[i];
                if (index >= 0 && index < allUvs.Count)
                {
                    triangleUvs.Add(allUvs[index]);
                    triangleNormals.Add(normalsAreUsable ? allNormals[index] : Vector3.forward);
                    trianglePositions.Add(verticesAreUsable ? allVertices[index] : Vector3.zero);
                    triangleNeckBlendValues.Add(allNeckBlendValues != null && index < allNeckBlendValues.Length ? allNeckBlendValues[index] : 0f);
                }
            }

            return new TargetUvData(result, triangleUvs, triangleNormals, trianglePositions, triangleNeckBlendValues);
        }

        private void UpdateNeckBlendAlternativeRendererDiagnostic(
            SkinnedMeshRenderer currentRenderer,
            VailNeckBlendSource source)
        {
            ClearNeckBlendAlternativeRendererDiagnostic();
            if (source != VailNeckBlendSource.Disabled ||
                neckBlendMode != VailNeckBlendMode.HeadNeckWeights ||
                currentRenderer == null)
            {
                return;
            }

            var animator = currentRenderer.GetComponentInParent<Animator>();
            var searchRoot = animator != null ? animator.transform : currentRenderer.transform.root;
            var renderers = searchRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            var bestScore = int.MinValue;
            SkinnedMeshRenderer bestRenderer = null;

            for (var rendererIndex = 0; rendererIndex < renderers.Length; rendererIndex++)
            {
                var candidate = renderers[rendererIndex];
                if (candidate == null || candidate == currentRenderer || candidate.sharedMesh == null)
                {
                    continue;
                }

                if (!SharesAnyMaterial(currentRenderer, candidate))
                {
                    continue;
                }

                try
                {
                    var relevantIndices = GetRelevantVertexIndices(candidate.sharedMesh, subMeshIndex);
                    var candidateData = VailNeckBlendUtility.Build(
                        candidate.sharedMesh,
                        candidate,
                        uvChannel,
                        VailNeckBlendMode.HeadNeckWeights,
                        neckBlendOffset,
                        neckBlendWidth,
                        neckBlendManualUvAngle,
                        neckBlendInvert,
                        relevantIndices);
                    if (!candidateData.IsValid || candidateData.Source != VailNeckBlendSource.HeadNeckWeights)
                    {
                        continue;
                    }

                    var score = ScoreNeckBlendRendererCandidate(candidate);
                    if (score <= bestScore)
                    {
                        continue;
                    }

                    bestScore = score;
                    bestRenderer = candidate;
                }
                catch (Exception)
                {
                    // Some imported meshes do not expose CPU-readable topology. Skip only that candidate.
                }
            }

            if (bestRenderer == null)
            {
                return;
            }

            neckBlendAlternativeRendererDiagnostic = L(
                $"同じアバター内で対象と同じマテリアルを共有する「{bestRenderer.name}」にはHead系ウェイト差があります。UV配置が一致するとは限らないため対象は自動変更しません。出力先と一致する場合だけ選択してください。",
                $"'{bestRenderer.name}' in the same avatar shares a target material and has a usable Head-family weight range. The target was not changed because its UV layout may still differ; select it only when it matches the intended output.");
        }

        private static SkinnedMeshRenderer FindBestTargetSkinnedMeshRenderer(GameObject root)
        {
            var renderers = root != null
                ? root.GetComponentsInChildren<SkinnedMeshRenderer>(false)
                : Array.Empty<SkinnedMeshRenderer>();
            var bestScore = int.MinValue;
            SkinnedMeshRenderer bestRenderer = null;
            for (var i = 0; i < renderers.Length; i++)
            {
                var candidate = renderers[i];
                if (candidate == null || candidate.sharedMesh == null)
                {
                    continue;
                }

                var score = ScoreVailTargetRendererCandidate(candidate);
                if (bestRenderer != null && score <= bestScore)
                {
                    continue;
                }

                bestScore = score;
                bestRenderer = candidate;
            }

            return bestRenderer;
        }

        private static bool SharesAnyMaterial(SkinnedMeshRenderer left, SkinnedMeshRenderer right)
        {
            if (left == null || right == null)
            {
                return false;
            }

            var leftMaterials = left.sharedMaterials;
            var rightMaterials = right.sharedMaterials;
            for (var leftIndex = 0; leftIndex < leftMaterials.Length; leftIndex++)
            {
                var material = leftMaterials[leftIndex];
                if (material == null)
                {
                    continue;
                }

                for (var rightIndex = 0; rightIndex < rightMaterials.Length; rightIndex++)
                {
                    if (rightMaterials[rightIndex] == material)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private static List<int> GetRelevantVertexIndices(Mesh mesh, int selectedSubMesh)
        {
            var indices = new HashSet<int>();
            if (selectedSubMesh >= 0 && selectedSubMesh < mesh.subMeshCount)
            {
                indices.UnionWith(mesh.GetTriangles(selectedSubMesh));
            }
            else
            {
                for (var subMesh = 0; subMesh < mesh.subMeshCount; subMesh++)
                {
                    indices.UnionWith(mesh.GetTriangles(subMesh));
                }
            }

            return new List<int>(indices);
        }

        private static int ScoreNeckBlendRendererCandidate(SkinnedMeshRenderer renderer)
        {
            var score = ScoreVailTargetName(renderer.name);
            if (renderer.sharedMesh != null)
            {
                score += ScoreVailTargetName(renderer.sharedMesh.name);
            }

            var materials = renderer.sharedMaterials;
            for (var i = 0; i < materials.Length; i++)
            {
                if (materials[i] != null)
                {
                    score += ScoreVailTargetName(materials[i].name) * 3;
                }
            }

            return score;
        }

        private static int ScoreVailTargetRendererCandidate(SkinnedMeshRenderer renderer)
        {
            return ScoreNeckBlendRendererCandidate(renderer);
        }

        private static int ScoreVailTargetName(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return 0;
            }

            var normalized = value.ToLowerInvariant();
            var score = 0;
            if (normalized.Contains("face") || normalized.Contains("kao") || normalized.Contains("顔"))
            {
                score += 100;
            }

            if (normalized.Contains("head") || normalized.Contains("atama") || normalized.Contains("頭"))
            {
                score += 40;
            }

            if (normalized.Contains("hair") || normalized.Contains("kami") || normalized.Contains("髪"))
            {
                score -= 100;
            }

            if (normalized.Contains("costume") || normalized.Contains("cloth") || normalized.Contains("wear"))
            {
                score -= 100;
            }

            if (normalized.Contains("body"))
            {
                score -= 10;
            }

            return score;
        }

        private void ClearNeckBlendAlternativeRendererDiagnostic()
        {
            neckBlendAlternativeRendererDiagnostic = string.Empty;
        }

        private string LocalizeNeckBlendDiagnostic(VailNeckBlendSource source, string diagnostic)
        {
            switch (source)
            {
                case VailNeckBlendSource.HeadNeckWeights:
                    return L("選択サブメッシュ内のHead/Neck系ウェイトを正規化してBマスクを生成しました。", "Generated the B mask by normalizing Head/Neck-family weights inside the selected submesh.");
                case VailNeckBlendSource.HeadNeckPlane:
                {
                    var planeWasConstrained = !string.IsNullOrEmpty(diagnostic) &&
                                              diagnostic.IndexOf("center was constrained", StringComparison.Ordinal) >= 0;
                    if (neckBlendMode == VailNeckBlendMode.Automatic)
                    {
                        return planeWasConstrained
                            ? L("選択サブメッシュ内に有効なウェイト差がなかったため、Neck–Head平面を選択形状の範囲内へ安全に補正してBマスクを生成しました。", "No usable weight difference was found inside the selected submesh, so the Neck-to-Head plane was safely constrained to the selected geometry before generating the B mask.")
                            : L("選択サブメッシュ内に有効なウェイト差がなかったため、NeckからHeadへ向かう平面でBマスクを生成しました。", "No usable weight difference was found inside the selected submesh, so the B mask was generated from the Neck-to-Head plane.");
                    }

                    return planeWasConstrained
                        ? L("Neck–Head平面を選択形状の範囲内へ補正してBマスクを生成しました。", "Generated the B mask after constraining the Neck-to-Head plane to the selected geometry.")
                        : L("NeckからHeadへ向かう平面でBマスクを生成しました。", "Generated the B mask from the Neck-to-Head plane.");
                }
                case VailNeckBlendSource.ManualUv:
                    return neckBlendMode == VailNeckBlendMode.Automatic
                        ? L("ウェイト境界、Head/Neck平面、首側UV境界のいずれも有効な差を作れなかったため、手動UVグラデーションへ切り替えました。", "The weight boundary, Head/Neck plane, and neck-side UV boundary could not produce a usable range, so Automatic switched to the manual UV gradient.")
                        : L("手動UVグラデーションでBマスクを生成しました。", "Generated the B mask with the manual UV gradient.");
                case VailNeckBlendSource.UvBoundary:
                    return neckBlendMode == VailNeckBlendMode.Automatic
                        ? L("ウェイト境界がなく、Head/Neck平面を形状内へ大きく補正する必要があったため、首に近いUV外周からBマスクを生成しました。", "No usable weight boundary was found and the Head/Neck plane required a large correction, so the B mask was generated from the UV perimeter nearest the neck.")
                        : L("首に近いUV外周からBマスクを生成しました。", "Generated the B mask from the UV perimeter nearest the neck.");
                default:
                    if (uiLanguage == UiLanguage.Japanese)
                    {
                        return LocalizeDisabledNeckBlendDiagnostic(diagnostic);
                    }

                    return string.IsNullOrEmpty(diagnostic)
                        ? "Could not generate the B mask. Check the target mesh, UVs, Head/Neck bones, and detection mode."
                        : diagnostic;
            }
        }

        private static string LocalizeDisabledNeckBlendDiagnostic(string diagnostic)
        {
            if (string.IsNullOrEmpty(diagnostic))
            {
                return "Bマスクを生成できませんでした。対象メッシュ、UV、Head/Neckボーン、および検出方式を確認してください。";
            }

            if (diagnostic.StartsWith("Head and skin weights were resolved", StringComparison.Ordinal))
            {
                return "Head/Neckボーンとスキンウェイトは取得できましたが、選択範囲のHead系ウェイトが一定" +
                       ExtractDiagnosticDetail(diagnostic) + "のため、ウェイト境界を生成できません。";
            }

            if (diagnostic.StartsWith("Head and Neck transforms were resolved", StringComparison.Ordinal))
            {
                return "Head/Neckボーンは取得できましたが、現在の境界オフセットと幅では選択範囲の平面マスクが一定" +
                       ExtractDiagnosticDetail(diagnostic) + "です。";
            }

            if (diagnostic == "The target is not backed by a SkinnedMeshRenderer.")
            {
                return "対象がSkinnedMeshRendererではないため、Head/Neckボーンを参照できません。";
            }

            if (diagnostic.StartsWith("Could not resolve the Head", StringComparison.Ordinal))
            {
                return "Humanoid設定、FBX Configure、またはボーン名からHeadを取得できませんでした。";
            }

            if (diagnostic.StartsWith("Could not resolve both Head and Neck", StringComparison.Ordinal))
            {
                return "Humanoid設定、FBX Configure、ボーン名、またはHeadの親からHead/Neckを取得できませんでした。";
            }

            if (diagnostic == "The SkinnedMeshRenderer has no bones.")
            {
                return "対象のSkinnedMeshRendererにボーンがありません。";
            }

            if (diagnostic == "The resolved Head transform is not present in the renderer bone list.")
            {
                return "Headは取得できましたが、対象Rendererのボーン一覧に含まれていません。";
            }

            if (diagnostic == "The mesh has no compatible bone weights.")
            {
                return "対象メッシュから互換性のあるスキンウェイトを読み取れませんでした。";
            }

            if (diagnostic == "The selected UV channel does not contain one UV per vertex.")
            {
                return "選択UVチャンネルのUV数が頂点数と一致しません。";
            }

            if (diagnostic == "No open UV perimeter was found in the selected geometry.")
            {
                return "選択サブメッシュ内に利用できるUV外周がありません。閉じた形状またはUVのない形状では首側UV境界を生成できません。";
            }

            if (diagnostic.StartsWith("The selected geometry does not contain", StringComparison.Ordinal))
            {
                return "選択サブメッシュにUV境界判定に必要な三角形または頂点がありません。";
            }

            if (diagnostic.StartsWith("The UV-boundary mask is uniform", StringComparison.Ordinal))
            {
                return "選択範囲の首側UV境界マスクが一定" + ExtractDiagnosticDetail(diagnostic) + "のため使用できません。";
            }

            return "Bマスクを生成できませんでした。";
        }

        private static string ExtractDiagnosticDetail(string diagnostic)
        {
            var open = diagnostic.LastIndexOf('(');
            var close = diagnostic.LastIndexOf(')');
            return open >= 0 && close > open
                ? "（" + diagnostic.Substring(open + 1, close - open - 1) + "）"
                : string.Empty;
        }

        private static Rect CalculateUvBounds(IReadOnlyList<Vector2> uvs, float boundsPadding)
        {
            var min = new Vector2(float.MaxValue, float.MaxValue);
            var max = new Vector2(float.MinValue, float.MinValue);

            for (var i = 0; i < uvs.Count; i++)
            {
                min = Vector2.Min(min, uvs[i]);
                max = Vector2.Max(max, uvs[i]);
            }

            var size = max - min;
            min -= size * boundsPadding;
            max += size * boundsPadding;

            return Rect.MinMaxRect(min.x, min.y, max.x, max.y);
        }

        private string BuildMeshUvSummary(Mesh mesh)
        {
            if (mesh == null)
            {
                return L("メッシュ情報: なし", "Mesh info: none");
            }

            var summary = L("メッシュ: ", "Mesh: ") + mesh.name + L(" / 頂点数: ", " / Vertices: ") + mesh.vertexCount + L(" / サブメッシュ数: ", " / Submeshes: ") + mesh.subMeshCount;
            for (var channel = 0; channel < 8; channel++)
            {
                var uvs = new List<Vector4>();
                mesh.GetUVs(channel, uvs);
                summary += "\nUV" + channel + ": " + uvs.Count;
            }

            return summary;
        }

        private BakeResult GenerateTextures(Rect uvBounds, TargetUvData targetUvData, bool forceBaseRefresh)
        {
            var size = uvBounds.size;
            if (size.x <= 0f || size.y <= 0f)
            {
                throw new InvalidOperationException("UV範囲のサイズが0です。");
            }

            var baseBakeData = GetBaseBakeData(uvBounds, targetUvData, forceBaseRefresh);
            return BuildTextures(
                baseBakeData.UvCoverageMask,
                baseBakeData.LightMapIslandMask,
                baseBakeData.LightMapUvBounds,
                baseBakeData.MultiAnglePreviewMaps,
                baseBakeData.IsMultiAngleGradient,
                (byte[])baseBakeData.LeftLightMap.Clone(),
                (byte[])baseBakeData.RightLightMap.Clone(),
                (byte[])baseBakeData.NeckBlendMap.Clone());
        }

        private BaseBakeData GetBaseBakeData(Rect uvBounds, TargetUvData targetUvData, bool forceBaseRefresh)
        {
            var signature = BuildBaseBakeSignature();
            if (!forceBaseRefresh && cachedBaseBakeData.IsValid && cachedBaseSignature == signature)
            {
                return cachedBaseBakeData;
            }

            var uvCoverageMask = GenerateUvCoverageMask(targetUvData.TriangleUvs);
            var lightMapIslandMask = GenerateLightMapIslandMask(targetUvData, uvCoverageMask);
            var lightMapUvBounds = CalculateMaskUvBounds(lightMapIslandMask);
            var neckBlendMap = GenerateNeckBlendMap(targetUvData, lightMapIslandMask);
            byte[][] multiAnglePreviewMaps = null;
            var isMultiAngleGradient = false;
            byte[] leftLightMap;
            byte[] rightLightMap;
            if (bakeMode == LightMapBakeMode.GpuLightBake)
            {
                GenerateGpuLightBakeMaps(targetUvData, lightMapIslandMask, out leftLightMap, out rightLightMap);
                Swap(ref leftLightMap, ref rightLightMap);
                ApplyShapeShadowEnhancement(targetUvData, lightMapIslandMask, leftLightMap, rightLightMap);
            }
            else if (bakeMode == LightMapBakeMode.MultiAngleGpuGradient)
            {
                GenerateMultiAngleGpuGradientMaps(targetUvData, lightMapIslandMask, out leftLightMap, out rightLightMap, out multiAnglePreviewMaps);
                isMultiAngleGradient = true;
            }
            else if (bakeMode == LightMapBakeMode.MeshNormals)
            {
                GenerateMeshNormalLightMaps(targetUvData, uvCoverageMask, lightMapIslandMask, out leftLightMap, out rightLightMap);
                Swap(ref leftLightMap, ref rightLightMap);
                ApplyShapeShadowEnhancement(targetUvData, lightMapIslandMask, leftLightMap, rightLightMap);
            }
            else
            {
                GenerateUvGradientLightMaps(uvBounds, uvCoverageMask, lightMapIslandMask, out leftLightMap, out rightLightMap);
                ApplyShapeShadowEnhancement(targetUvData, lightMapIslandMask, leftLightMap, rightLightMap);
            }

            cachedBaseSignature = signature;
            cachedBaseBakeData = new BaseBakeData(uvCoverageMask, lightMapIslandMask, lightMapUvBounds, multiAnglePreviewMaps, isMultiAngleGradient, leftLightMap, rightLightMap, neckBlendMap);
            return cachedBaseBakeData;
        }

        private string BuildBaseBakeSignature()
        {
            var builder = new StringBuilder(256);
            builder.Append(BakeAlgorithmVersion).Append('|');
            builder.Append(targetObject != null ? targetObject.GetInstanceID() : 0).Append('|');
            builder.Append(useSkinnedMeshBake).Append('|');
            builder.Append(subMeshIndex).Append('|');
            builder.Append(uvChannel).Append('|');
            builder.Append(resolution).Append('|');
            builder.Append(padding).Append('|');
            builder.Append(bakeMode).Append('|');
            builder.Append(lightCenterOffset).Append('|');
            builder.Append(lightSoftness).Append('|');
            builder.Append(lightContrast).Append('|');
            builder.Append(normalLightWrap).Append('|');
            builder.Append(lightForwardOffset).Append('|');
            builder.Append(lightUpOffset).Append('|');
            builder.Append(lightProjectionScale).Append('|');
            builder.Append(lightDistance).Append('|');
            builder.Append(lightRadius).Append('|');
            builder.Append(multiAngleFrontWeight).Append('|');
            builder.Append(multiAngleBackWeight).Append('|');
            builder.Append(shadowBias).Append('|');
            builder.Append(shapeShadowStrength).Append('|');
            builder.Append(shapeShadowRadius).Append('|');
            builder.Append(neckBlendEnabled).Append('|');
            builder.Append(neckBlendMode).Append('|');
            builder.Append(neckBlendOffset).Append('|');
            builder.Append(neckBlendWidth).Append('|');
            builder.Append(neckBlendManualUvAngle).Append('|');
            builder.Append(neckBlendInvert).Append('|');
            builder.Append(excludeOppositeFacingUv).Append('|');
            builder.Append(lightMapIslandSeeds.Count).Append('|');
            for (var i = 0; i < lightMapIslandSeeds.Count; i++)
            {
                builder.Append(lightMapIslandSeeds[i].x).Append(',').Append(lightMapIslandSeeds[i].y).Append('|');
            }

            return builder.ToString();
        }

        private BakeResult BuildTextures(bool[] uvCoverageMask, bool[] lightMapIslandMask, Rect lightMapUvBounds, byte[][] multiAnglePreviewMaps, bool isMultiAngleGradient, byte[] leftLightMap, byte[] rightLightMap, byte[] neckBlendMap)
        {
            if (isMultiAngleGradient)
            {
                ApplyFinalBlur(leftLightMap, rightLightMap, lightMapIslandMask);
                ApplyCheekMax(leftLightMap, rightLightMap, lightMapIslandMask, lightMapUvBounds);
                ApplyNoseHighlightChannelSwap(leftLightMap, rightLightMap, lightMapIslandMask, lightMapUvBounds);
                ApplyUvBorderMax(leftLightMap, rightLightMap, lightMapIslandMask);
                var multiAngleInnerBorderHoleMask = GenerateInnerBorderHoleMask(lightMapIslandMask);
                ApplyInnerHoleBorderMax(leftLightMap, rightLightMap, lightMapIslandMask, multiAngleInnerBorderHoleMask);
                var multiAngleOutputLightMapIslandMask = (bool[])lightMapIslandMask.Clone();
                var multiAngleOutputCoverageMask = ExpandUvPadding(uvCoverageMask, multiAngleOutputLightMapIslandMask, leftLightMap, rightLightMap, neckBlendMap);
                return BuildMultiAngleGradientTextures(multiAngleOutputCoverageMask, multiAngleOutputLightMapIslandMask, multiAnglePreviewMaps, rightLightMap, leftLightMap, neckBlendMap, lightMapUvBounds);
            }

            ApplyFinalBlur(leftLightMap, rightLightMap, lightMapIslandMask);
            ApplyCheekMax(leftLightMap, rightLightMap, lightMapIslandMask, lightMapUvBounds);
            ApplyNoseHighlightChannelSwap(leftLightMap, rightLightMap, lightMapIslandMask, lightMapUvBounds);
            ApplyUvBorderMax(leftLightMap, rightLightMap, lightMapIslandMask);
            var innerBorderHoleMask = GenerateInnerBorderHoleMask(lightMapIslandMask);
            ApplyInnerHoleBorderMax(leftLightMap, rightLightMap, lightMapIslandMask, innerBorderHoleMask);
            var outputLightMapIslandMask = (bool[])lightMapIslandMask.Clone();
            var outputCoverageMask = ExpandUvPadding(uvCoverageMask, outputLightMapIslandMask, leftLightMap, rightLightMap, neckBlendMap);

            var lightTexture = new Texture2D(resolution, resolution, TextureFormat.RGBA32, generateMipMaps, true)
            {
                name = Path.GetFileNameWithoutExtension(savePath),
                filterMode = FilterMode.Bilinear,
                wrapMode = TextureWrapMode.Clamp
            };

            var lightPixels = new Color32[resolution * resolution];
            for (var i = 0; i < lightPixels.Length; i++)
            {
                byte red = 0;
                byte green = 0;
                byte blue = 0;
                if (outputCoverageMask[i])
                {
                    red = 255;
                    green = 255;
                    if (outputLightMapIslandMask[i])
                    {
                        red = swapRG ? leftLightMap[i] : rightLightMap[i];
                        green = swapRG ? rightLightMap[i] : leftLightMap[i];
                        blue = neckBlendEnabled ? neckBlendMap[i] : (byte)0;
                    }
                }

                lightPixels[i] = new Color32(red, green, blue, 255);
            }

            lightTexture.SetPixels32(lightPixels);
            lightTexture.Apply(generateMipMaps, false);

            var noseHighlightPreviewMask = GenerateNoseHighlightPreviewMask(lightMapIslandMask, lightMapUvBounds);
            var debugPreviewTexture = GenerateDebugPreviewTexture(leftLightMap, rightLightMap, neckBlendMap, outputCoverageMask, outputLightMapIslandMask, noseHighlightPreviewMask, isMultiAngleGradient);
            var redChannelPreviewTexture = GenerateChannelPreviewTexture(lightPixels, 0);
            var greenChannelPreviewTexture = GenerateChannelPreviewTexture(lightPixels, 1);
            var blueChannelPreviewTexture = GenerateChannelPreviewTexture(lightPixels, 2);
            var multiAngleGridPreviewTexture = GenerateMultiAngleGridPreviewTexture(multiAnglePreviewMaps);
            return new BakeResult(lightTexture, debugPreviewTexture, redChannelPreviewTexture, greenChannelPreviewTexture, blueChannelPreviewTexture, multiAngleGridPreviewTexture);
        }

        private BakeResult BuildMultiAngleGradientTextures(bool[] outputCoverageMask, bool[] outputLightMapIslandMask, byte[][] multiAnglePreviewMaps, byte[] leftLightMap, byte[] rightLightMap, byte[] neckBlendMap, Rect lightMapUvBounds)
        {
            var lightTexture = new Texture2D(resolution, resolution, TextureFormat.RGBA32, generateMipMaps, true)
            {
                name = Path.GetFileNameWithoutExtension(savePath),
                filterMode = FilterMode.Bilinear,
                wrapMode = TextureWrapMode.Clamp
            };

            var pixels = new Color32[resolution * resolution];
            var redPreviewPixels = new Color32[resolution * resolution];
            var greenPreviewPixels = new Color32[resolution * resolution];
            for (var i = 0; i < pixels.Length; i++)
            {
                if (!outputCoverageMask[i])
                {
                    pixels[i] = new Color32(0, 0, 0, 255);
                    redPreviewPixels[i] = new Color32(0, 0, 0, 255);
                    greenPreviewPixels[i] = new Color32(0, 0, 0, 255);
                    continue;
                }

                var red = outputLightMapIslandMask[i] ? rightLightMap[i] : (byte)255;
                var green = outputLightMapIslandMask[i] ? leftLightMap[i] : (byte)255;
                var blue = outputLightMapIslandMask[i] && neckBlendEnabled ? neckBlendMap[i] : (byte)0;
                pixels[i] = new Color32(red, green, blue, 255);
                redPreviewPixels[i] = new Color32(red, red, red, 255);
                greenPreviewPixels[i] = new Color32(green, green, green, 255);
            }

            lightTexture.SetPixels32(pixels);
            lightTexture.Apply(generateMipMaps, false);

            var noseHighlightPreviewMask = GenerateNoseHighlightPreviewMask(outputLightMapIslandMask, lightMapUvBounds);
            var previewTexture = GenerateDebugPreviewTexture(leftLightMap, rightLightMap, neckBlendMap, outputCoverageMask, outputLightMapIslandMask, noseHighlightPreviewMask, true);
            var redPreviewTexture = CreatePreviewTexture("_R", redPreviewPixels, FilterMode.Bilinear);
            var greenPreviewTexture = CreatePreviewTexture("_G", greenPreviewPixels, FilterMode.Bilinear);
            var bluePreviewTexture = GenerateChannelPreviewTexture(pixels, 2);
            var multiAngleGridPreviewTexture = GenerateMultiAngleGridPreviewTexture(multiAnglePreviewMaps);
            return new BakeResult(lightTexture, previewTexture, redPreviewTexture, greenPreviewTexture, bluePreviewTexture, multiAngleGridPreviewTexture);
        }

        private void GenerateUvGradientLightMaps(Rect uvBounds, bool[] uvCoverageMask, bool[] lightMapIslandMask, out byte[] leftLightMap, out byte[] rightLightMap)
        {
            leftLightMap = new byte[resolution * resolution];
            rightLightMap = new byte[resolution * resolution];

            var centerX = uvBounds.center.x + uvBounds.size.x * lightCenterOffset;
            var halfWidth = Mathf.Max(uvBounds.size.x * 0.5f, 0.0001f);

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    var index = x + y * resolution;
                    if (!uvCoverageMask[index] || !lightMapIslandMask[index])
                    {
                        continue;
                    }

                    var uvX = (x + 0.5f) / resolution;
                    var uvY = (y + 0.5f) / resolution;
                    var verticalBias = (uvY - uvBounds.center.y) / Mathf.Max(uvBounds.size.y * 0.5f, 0.0001f) * lightUpOffset;
                    var signedSide = (uvX - centerX) / halfWidth + verticalBias;
                    var rightValue = EvaluateDirectionalLightValue(signedSide);
                    var leftValue = EvaluateDirectionalLightValue(-signedSide);
                    rightLightMap[index] = (byte)Mathf.RoundToInt(rightValue * 255f);
                    leftLightMap[index] = (byte)Mathf.RoundToInt(leftValue * 255f);
                }
            }
        }

        private void GenerateGpuLightBakeMaps(TargetUvData targetUvData, bool[] lightMapIslandMask, out byte[] leftLightMap, out byte[] rightLightMap)
        {
            var shader = Shader.Find("Hidden/ACM/VailUvBake");
            if (shader == null)
            {
                throw new InvalidOperationException(L("ライト照射ベイク用Shaderが見つかりません。Hidden/ACM/VailUvBake を確認してください。", "GPU Light Bake shader was not found. Check Hidden/ACM/VailUvBake."));
            }

            var shadowShader = Shader.Find("Hidden/ACM/VailShadowDepth");
            if (shadowShader == null)
            {
                throw new InvalidOperationException(L("ライト照射ベイク用Shadow Shaderが見つかりません。Hidden/ACM/VailShadowDepth を確認してください。", "GPU Light Bake shadow shader was not found. Check Hidden/ACM/VailShadowDepth."));
            }

            var uvBakeMesh = BuildUvBakeMesh(targetUvData, lightMapIslandMask);
            var shadowMesh = BuildShadowCasterMesh(targetUvData);
            var material = new Material(shader)
            {
                hideFlags = HideFlags.HideAndDontSave
            };
            var shadowMaterial = new Material(shadowShader)
            {
                hideFlags = HideFlags.HideAndDontSave
            };

            try
            {
                material.SetFloat("_Softness", Mathf.Max(lightSoftness, 0.0001f));
                material.SetFloat("_Contrast", Mathf.Max(lightContrast, 0.0001f));
                material.SetFloat("_NormalWrap", normalLightWrap);
                material.SetFloat("_ShadowBias", shadowBias);
                material.SetFloat("_LightRangeFeather", 0.12f);
                material.SetFloat("_LightCoverage", lightProjectionScale);

                var rightLightDirection = new Vector3(1f, lightUpOffset, lightForwardOffset).normalized;
                var leftLightDirection = new Vector3(-1f, lightUpOffset, lightForwardOffset).normalized;
                rightLightMap = RenderGpuLightBakeChannel(uvBakeMesh, shadowMesh, material, shadowMaterial, rightLightDirection, lightCenterOffset, lightMapIslandMask);
                leftLightMap = RenderGpuLightBakeChannel(uvBakeMesh, shadowMesh, material, shadowMaterial, leftLightDirection, -lightCenterOffset, lightMapIslandMask);
            }
            finally
            {
                DestroyImmediate(shadowMaterial);
                DestroyImmediate(material);
                DestroyImmediate(shadowMesh);
                DestroyImmediate(uvBakeMesh);
            }
        }

        private void GenerateMultiAngleGpuGradientMaps(TargetUvData targetUvData, bool[] lightMapIslandMask, out byte[] leftLightMap, out byte[] rightLightMap, out byte[][] previewMaps)
        {
            var shader = Shader.Find("Hidden/ACM/VailUvBake");
            if (shader == null)
            {
                throw new InvalidOperationException(L("ライト照射ベイク用Shaderが見つかりません。Hidden/ACM/VailUvBake を確認してください。", "GPU Light Bake shader was not found. Check Hidden/ACM/VailUvBake."));
            }

            var shadowShader = Shader.Find("Hidden/ACM/VailShadowDepth");
            if (shadowShader == null)
            {
                throw new InvalidOperationException(L("ライト照射ベイク用Shadow Shaderが見つかりません。Hidden/ACM/VailShadowDepth を確認してください。", "GPU Light Bake shadow shader was not found. Check Hidden/ACM/VailShadowDepth."));
            }

            var uvBakeMesh = BuildUvBakeMesh(targetUvData, lightMapIslandMask);
            var shadowMesh = BuildShadowCasterMesh(targetUvData);
            var material = new Material(shader)
            {
                hideFlags = HideFlags.HideAndDontSave
            };
            var shadowMaterial = new Material(shadowShader)
            {
                hideFlags = HideFlags.HideAndDontSave
            };

            try
            {
                material.SetFloat("_Softness", Mathf.Max(lightSoftness, 0.0001f));
                material.SetFloat("_Contrast", Mathf.Max(lightContrast, 0.0001f));
                material.SetFloat("_NormalWrap", normalLightWrap);
                material.SetFloat("_ShadowBias", shadowBias);
                material.SetFloat("_LightRangeFeather", 0.12f);
                material.SetFloat("_LightCoverage", lightProjectionScale);

                rightLightMap = GenerateMultiAngleCompositeMap(uvBakeMesh, shadowMesh, material, shadowMaterial, lightMapIslandMask, 1f, out previewMaps);
                leftLightMap = GenerateMultiAngleCompositeMap(uvBakeMesh, shadowMesh, material, shadowMaterial, lightMapIslandMask, -1f, out _);
            }
            finally
            {
                DestroyImmediate(shadowMaterial);
                DestroyImmediate(material);
                DestroyImmediate(shadowMesh);
                DestroyImmediate(uvBakeMesh);
            }
        }

        private byte[] GenerateMultiAngleCompositeMap(Mesh uvBakeMesh, Mesh shadowMesh, Material material, Material shadowMaterial, bool[] lightMapIslandMask, float sideSign, out byte[][] previewMaps)
        {
            previewMaps = new byte[9][];
            for (var angleIndex = 0; angleIndex < previewMaps.Length; angleIndex++)
            {
                var angle = 180f - angleIndex * 22.5f;
                var radians = angle * Mathf.Deg2Rad;
                var lightDirection = new Vector3(sideSign * Mathf.Sin(radians), Mathf.Cos(radians) + lightUpOffset, lightForwardOffset).normalized;
                previewMaps[angleIndex] = RenderGpuLightBakeChannel(uvBakeMesh, shadowMesh, material, shadowMaterial, lightDirection, 0f, lightMapIslandMask);
            }

            return CompositeMultiAngleGradientMap(previewMaps, lightMapIslandMask);
        }

        private byte[] CompositeMultiAngleGradientMap(byte[][] previewMaps, bool[] lightMapIslandMask)
        {
            var compositeValues = new float[resolution * resolution];
            var compositionMaps = new byte[previewMaps.Length][];
            var compositionBlur = Mathf.Max(finalBlurPixels, 1f);
            for (var i = 0; i < previewMaps.Length; i++)
            {
                compositionMaps[i] = BlurSingleChannel(previewMaps[i], lightMapIslandMask, compositionBlur);
            }

            for (var angleIndex = 0; angleIndex < previewMaps.Length; angleIndex++)
            {
                for (var offset = -1; offset <= 1; offset++)
                {
                    var sampleAngleIndex = angleIndex + offset;
                    if (sampleAngleIndex < 0 || sampleAngleIndex >= previewMaps.Length)
                    {
                        continue;
                    }

                    var angle = 180f - sampleAngleIndex * 22.5f;
                    var angleValue = angle / 180f;
                    var angleContribution = Mathf.Lerp(multiAngleFrontWeight, multiAngleBackWeight, angleValue);
                    var angleKernelWeight = offset == 0 ? 0.5f : 0.25f;
                    var channel = compositionMaps[angleIndex];
                    for (var i = 0; i < channel.Length; i++)
                    {
                        if (!lightMapIslandMask[i])
                        {
                            continue;
                        }

                        var weight = channel[i] / 255f * angleKernelWeight * angleContribution;
                        compositeValues[i] += weight * angleValue;
                    }
                }
            }

            var minComposite = float.MaxValue;
            var maxComposite = float.MinValue;
            for (var i = 0; i < compositeValues.Length; i++)
            {
                if (!lightMapIslandMask[i])
                {
                    continue;
                }

                minComposite = Mathf.Min(minComposite, compositeValues[i]);
                maxComposite = Mathf.Max(maxComposite, compositeValues[i]);
            }

            var output = new byte[resolution * resolution];
            var compositeRange = maxComposite - minComposite;
            for (var i = 0; i < output.Length; i++)
            {
                if (!lightMapIslandMask[i])
                {
                    continue;
                }

                var gradient = compositeRange > 0.0001f ? (compositeValues[i] - minComposite) / compositeRange : 0.5f;
                output[i] = (byte)Mathf.RoundToInt(Mathf.Clamp01(gradient) * 255f);
            }

            return output;
        }

        private Mesh BuildUvBakeMesh(TargetUvData targetUvData, bool[] lightMapIslandMask)
        {
            var vertices = new List<Vector3>(targetUvData.TriangleUvs.Count);
            var normals = new List<Vector3>(targetUvData.TriangleUvs.Count);
            var originalPositions = new List<Vector3>(targetUvData.TriangleUvs.Count);
            var indices = new List<int>(targetUvData.TriangleUvs.Count);

            for (var i = 0; i + 2 < targetUvData.TriangleUvs.Count; i += 3)
            {
                if (!TriangleOverlapsMask(targetUvData.TriangleUvs[i], targetUvData.TriangleUvs[i + 1], targetUvData.TriangleUvs[i + 2], lightMapIslandMask))
                {
                    continue;
                }

                for (var vertex = 0; vertex < 3; vertex++)
                {
                    var sourceIndex = i + vertex;
                    var uv = targetUvData.TriangleUvs[sourceIndex];
                    vertices.Add(new Vector3(uv.x * 2f - 1f, uv.y * 2f - 1f, 0f));
                    normals.Add(sourceIndex < targetUvData.TriangleNormals.Count ? targetUvData.TriangleNormals[sourceIndex].normalized : Vector3.forward);
                    originalPositions.Add(sourceIndex < targetUvData.TrianglePositions.Count ? targetUvData.TrianglePositions[sourceIndex] : Vector3.zero);
                    indices.Add(indices.Count);
                }
            }

            var mesh = new Mesh
            {
                name = "Vail_UvBakeMesh",
                hideFlags = HideFlags.HideAndDontSave
            };

            if (vertices.Count > 65535)
            {
                mesh.indexFormat = IndexFormat.UInt32;
            }

            mesh.SetVertices(vertices);
            mesh.SetNormals(normals);
            mesh.SetUVs(0, originalPositions);
            mesh.SetIndices(indices, MeshTopology.Triangles, 0);
            mesh.UploadMeshData(false);
            return mesh;
        }

        private Mesh BuildShadowCasterMesh(TargetUvData targetUvData)
        {
            var vertices = new List<Vector3>(targetUvData.TrianglePositions.Count);
            var indices = new List<int>(targetUvData.TrianglePositions.Count);
            for (var i = 0; i < targetUvData.TrianglePositions.Count; i++)
            {
                vertices.Add(targetUvData.TrianglePositions[i]);
                indices.Add(i);
            }

            var mesh = new Mesh
            {
                name = "Vail_ShadowCasterMesh",
                hideFlags = HideFlags.HideAndDontSave
            };

            if (vertices.Count > 65535)
            {
                mesh.indexFormat = IndexFormat.UInt32;
            }

            mesh.SetVertices(vertices);
            mesh.SetIndices(indices, MeshTopology.Triangles, 0);
            mesh.UploadMeshData(false);
            return mesh;
        }

        private bool TriangleOverlapsMask(Vector2 uv0, Vector2 uv1, Vector2 uv2, bool[] mask)
        {
            var minX = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(uv0.x, Mathf.Min(uv1.x, uv2.x)) * resolution), 0, resolution - 1);
            var maxX = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(uv0.x, Mathf.Max(uv1.x, uv2.x)) * resolution), 0, resolution - 1);
            var minY = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(uv0.y, Mathf.Min(uv1.y, uv2.y)) * resolution), 0, resolution - 1);
            var maxY = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(uv0.y, Mathf.Max(uv1.y, uv2.y)) * resolution), 0, resolution - 1);

            var area = Edge(uv0, uv1, uv2);
            if (Mathf.Approximately(area, 0f))
            {
                return false;
            }

            for (var y = minY; y <= maxY; y++)
            {
                for (var x = minX; x <= maxX; x++)
                {
                    var index = x + y * resolution;
                    if (!mask[index])
                    {
                        continue;
                    }

                    var uv = new Vector2((x + 0.5f) / resolution, (y + 0.5f) / resolution);
                    var w0 = Edge(uv1, uv2, uv);
                    var w1 = Edge(uv2, uv0, uv);
                    var w2 = Edge(uv0, uv1, uv);
                    var inside = area > 0f
                        ? w0 >= 0f && w1 >= 0f && w2 >= 0f
                        : w0 <= 0f && w1 <= 0f && w2 <= 0f;
                    if (inside)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private byte[] RenderGpuLightBakeChannel(Mesh uvBakeMesh, Mesh shadowMesh, Material material, Material shadowMaterial, Vector3 lightDirection, float centerOffset, bool[] lightMapIslandMask)
        {
            var previousActive = RenderTexture.active;
            var renderTexture = RenderTexture.GetTemporary(resolution, resolution, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.Linear);
            renderTexture.filterMode = FilterMode.Point;
            renderTexture.wrapMode = TextureWrapMode.Clamp;
            var shadowTexture = RenderTexture.GetTemporary(resolution, resolution, 24, RenderTextureFormat.ARGBFloat, RenderTextureReadWrite.Linear);
            shadowTexture.filterMode = FilterMode.Bilinear;
            shadowTexture.wrapMode = TextureWrapMode.Clamp;
            var lightFrame = BuildLightFrame(shadowMesh.bounds, lightDirection);

            try
            {
                RenderShadowDepth(shadowMesh, shadowMaterial, shadowTexture, lightFrame);

                RenderTexture.active = renderTexture;
                GL.Clear(true, true, Color.black);

                ApplyLightFrame(material, lightFrame);
                material.SetVector("_LightDirection", lightDirection);
                material.SetVector("_LightPosition", lightFrame.LightPosition);
                material.SetFloat("_LightRadius", lightFrame.LightRadius);
                material.SetFloat("_ChannelCenterOffset", centerOffset);
                material.SetTexture("_ShadowTex", shadowTexture);
                material.SetPass(0);
                Graphics.DrawMeshNow(uvBakeMesh, Matrix4x4.identity);

                var texture = new Texture2D(resolution, resolution, TextureFormat.RGBA32, false, true)
                {
                    hideFlags = HideFlags.HideAndDontSave
                };
                texture.ReadPixels(new Rect(0f, 0f, resolution, resolution), 0, 0);
                texture.Apply(false, false);

                var pixels = texture.GetPixels32();
                DestroyImmediate(texture);

                var channel = new byte[resolution * resolution];
                for (var y = 0; y < resolution; y++)
                {
                    var sourceY = resolution - 1 - y;
                    for (var x = 0; x < resolution; x++)
                    {
                        var destinationIndex = x + y * resolution;
                        if (lightMapIslandMask[destinationIndex])
                        {
                            channel[destinationIndex] = pixels[x + sourceY * resolution].r;
                        }
                    }
                }

                return channel;
            }
            finally
            {
                RenderTexture.active = previousActive;
                RenderTexture.ReleaseTemporary(shadowTexture);
                RenderTexture.ReleaseTemporary(renderTexture);
            }
        }

        private void RenderShadowDepth(Mesh shadowMesh, Material shadowMaterial, RenderTexture shadowTexture, LightFrame lightFrame)
        {
            var previousActive = RenderTexture.active;
            try
            {
                RenderTexture.active = shadowTexture;
                GL.Clear(true, true, Color.white);
                ApplyLightFrame(shadowMaterial, lightFrame);
                shadowMaterial.SetPass(0);
                Graphics.DrawMeshNow(shadowMesh, Matrix4x4.identity);
            }
            finally
            {
                RenderTexture.active = previousActive;
            }
        }

        private LightFrame BuildLightFrame(Bounds bounds, Vector3 surfaceToLightDirection)
        {
            var forward = -surfaceToLightDirection.normalized;
            var right = Vector3.Cross(Vector3.up, forward);
            if (right.sqrMagnitude < 0.0001f)
            {
                right = Vector3.Cross(Vector3.forward, forward);
            }

            right.Normalize();
            var up = Vector3.Cross(forward, right).normalized;
            var center = bounds.center;
            var boundsRadius = Mathf.Max(bounds.extents.magnitude, 0.0001f);
            var pointLightPosition = center + surfaceToLightDirection.normalized * boundsRadius * lightDistance;
            var actualLightRadius = boundsRadius * lightRadius;

            var min = new Vector3(float.MaxValue, float.MaxValue, float.MaxValue);
            var max = new Vector3(float.MinValue, float.MinValue, float.MinValue);
            for (var x = -1; x <= 1; x += 2)
            {
                for (var y = -1; y <= 1; y += 2)
                {
                    for (var z = -1; z <= 1; z += 2)
                    {
                        var corner = bounds.center + Vector3.Scale(bounds.extents, new Vector3(x, y, z));
                        var offset = corner - center;
                        var lightSpacePosition = new Vector3(
                            Vector3.Dot(offset, right),
                            Vector3.Dot(offset, up),
                            Vector3.Dot(offset, forward));
                        min = Vector3.Min(min, lightSpacePosition);
                        max = Vector3.Max(max, lightSpacePosition);
                    }
                }
            }

            var halfExtent = new Vector2(
                Mathf.Max(Mathf.Max(Mathf.Abs(min.x), Mathf.Abs(max.x)) * lightProjectionScale, 0.0001f),
                Mathf.Max(Mathf.Max(Mathf.Abs(min.y), Mathf.Abs(max.y)) * lightProjectionScale, 0.0001f));
            var zPadding = Mathf.Max((max.z - min.z) * 0.05f, 0.001f);
            return new LightFrame(center, right, up, forward, halfExtent, min.z - zPadding, max.z + zPadding, pointLightPosition, actualLightRadius);
        }

        private static void ApplyLightFrame(Material material, LightFrame lightFrame)
        {
            material.SetVector("_LightCenter", lightFrame.Center);
            material.SetVector("_LightRight", lightFrame.Right);
            material.SetVector("_LightUp", lightFrame.Up);
            material.SetVector("_LightForward", lightFrame.Forward);
            material.SetVector("_LightHalfExtent", new Vector4(lightFrame.HalfExtent.x, lightFrame.HalfExtent.y, 0f, 0f));
            material.SetVector("_LightDepthRange", new Vector4(lightFrame.NearDepth, lightFrame.FarDepth, 0f, 0f));
        }

        private void GenerateMeshNormalLightMaps(TargetUvData targetUvData, bool[] uvCoverageMask, bool[] lightMapIslandMask, out byte[] leftLightMap, out byte[] rightLightMap)
        {
            leftLightMap = new byte[resolution * resolution];
            rightLightMap = new byte[resolution * resolution];
            var rightLightDirection = new Vector3(1f, lightUpOffset, lightForwardOffset).normalized;
            var leftLightDirection = new Vector3(-1f, lightUpOffset, lightForwardOffset).normalized;

            for (var i = 0; i + 2 < targetUvData.TriangleUvs.Count && i + 2 < targetUvData.TriangleNormals.Count; i += 3)
            {
                RasterizeNormalLitTriangle(
                    leftLightMap,
                    rightLightMap,
                    uvCoverageMask,
                    lightMapIslandMask,
                    targetUvData.TriangleUvs[i],
                    targetUvData.TriangleUvs[i + 1],
                    targetUvData.TriangleUvs[i + 2],
                    targetUvData.TriangleNormals[i],
                    targetUvData.TriangleNormals[i + 1],
                    targetUvData.TriangleNormals[i + 2],
                    leftLightDirection,
                    rightLightDirection);
            }
        }

        private void RasterizeNormalLitTriangle(byte[] leftLightMap, byte[] rightLightMap, bool[] uvCoverageMask, bool[] lightMapIslandMask, Vector2 uv0, Vector2 uv1, Vector2 uv2, Vector3 normal0, Vector3 normal1, Vector3 normal2, Vector3 leftLightDirection, Vector3 rightLightDirection)
        {
            var minX = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(uv0.x, Mathf.Min(uv1.x, uv2.x)) * resolution), 0, resolution - 1);
            var maxX = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(uv0.x, Mathf.Max(uv1.x, uv2.x)) * resolution), 0, resolution - 1);
            var minY = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(uv0.y, Mathf.Min(uv1.y, uv2.y)) * resolution), 0, resolution - 1);
            var maxY = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(uv0.y, Mathf.Max(uv1.y, uv2.y)) * resolution), 0, resolution - 1);

            var area = Edge(uv0, uv1, uv2);
            if (Mathf.Approximately(area, 0f))
            {
                return;
            }

            for (var y = minY; y <= maxY; y++)
            {
                for (var x = minX; x <= maxX; x++)
                {
                    var index = x + y * resolution;
                    if (!uvCoverageMask[index] || !lightMapIslandMask[index])
                    {
                        continue;
                    }

                    var uv = new Vector2((x + 0.5f) / resolution, (y + 0.5f) / resolution);
                    var w0 = Edge(uv1, uv2, uv) / area;
                    var w1 = Edge(uv2, uv0, uv) / area;
                    var w2 = Edge(uv0, uv1, uv) / area;
                    var inside = w0 >= 0f && w1 >= 0f && w2 >= 0f;
                    if (!inside)
                    {
                        continue;
                    }

                    var normal = (normal0 * w0 + normal1 * w1 + normal2 * w2).normalized;
                    var rightValue = EvaluateNormalLightValue(Vector3.Dot(normal, rightLightDirection), lightCenterOffset);
                    var leftValue = EvaluateNormalLightValue(Vector3.Dot(normal, leftLightDirection), -lightCenterOffset);
                    rightLightMap[index] = (byte)Mathf.Max(rightLightMap[index], Mathf.RoundToInt(rightValue * 255f));
                    leftLightMap[index] = (byte)Mathf.Max(leftLightMap[index], Mathf.RoundToInt(leftValue * 255f));
                }
            }
        }

        private void ApplyShapeShadowEnhancement(TargetUvData targetUvData, bool[] lightMapIslandMask, byte[] leftLightMap, byte[] rightLightMap)
        {
            if (shapeShadowStrength <= 0f)
            {
                return;
            }

            var normalBuffer = new Vector3[resolution * resolution];
            var normalMask = new bool[resolution * resolution];
            for (var i = 0; i + 2 < targetUvData.TriangleUvs.Count && i + 2 < targetUvData.TriangleNormals.Count; i += 3)
            {
                RasterizeNormalBuffer(
                    normalBuffer,
                    normalMask,
                    lightMapIslandMask,
                    targetUvData.TriangleUvs[i],
                    targetUvData.TriangleUvs[i + 1],
                    targetUvData.TriangleUvs[i + 2],
                    targetUvData.TriangleNormals[i],
                    targetUvData.TriangleNormals[i + 1],
                    targetUvData.TriangleNormals[i + 2]);
            }

            var sourceLeft = (byte[])leftLightMap.Clone();
            var sourceRight = (byte[])rightLightMap.Clone();
            var radius = Mathf.Clamp(shapeShadowRadius, 1, 8);
            var strength = Mathf.Max(shapeShadowStrength, 0f);

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    var index = x + y * resolution;
                    if (!lightMapIslandMask[index] || !normalMask[index])
                    {
                        continue;
                    }

                    var normal = normalBuffer[index];
                    var curvature = 0f;
                    var sampleCount = 0;
                    for (var offsetY = -radius; offsetY <= radius; offsetY++)
                    {
                        var sampleY = y + offsetY;
                        if (sampleY < 0 || sampleY >= resolution)
                        {
                            continue;
                        }

                        for (var offsetX = -radius; offsetX <= radius; offsetX++)
                        {
                            if (offsetX == 0 && offsetY == 0)
                            {
                                continue;
                            }

                            var sampleX = x + offsetX;
                            if (sampleX < 0 || sampleX >= resolution)
                            {
                                continue;
                            }

                            var sampleIndex = sampleX + sampleY * resolution;
                            if (!lightMapIslandMask[sampleIndex] || !normalMask[sampleIndex])
                            {
                                continue;
                            }

                            curvature += Mathf.Clamp01(1f - Vector3.Dot(normal, normalBuffer[sampleIndex]));
                            sampleCount++;
                        }
                    }

                    if (sampleCount == 0)
                    {
                        continue;
                    }

                    var shadow = Mathf.Clamp01(curvature / sampleCount * strength * 8f);
                    var multiplier = Mathf.Clamp01(1f - shadow);
                    leftLightMap[index] = (byte)Mathf.RoundToInt(sourceLeft[index] * multiplier);
                    rightLightMap[index] = (byte)Mathf.RoundToInt(sourceRight[index] * multiplier);
                }
            }
        }

        private void RasterizeNormalBuffer(Vector3[] normalBuffer, bool[] normalMask, bool[] lightMapIslandMask, Vector2 uv0, Vector2 uv1, Vector2 uv2, Vector3 normal0, Vector3 normal1, Vector3 normal2)
        {
            var minX = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(uv0.x, Mathf.Min(uv1.x, uv2.x)) * resolution), 0, resolution - 1);
            var maxX = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(uv0.x, Mathf.Max(uv1.x, uv2.x)) * resolution), 0, resolution - 1);
            var minY = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(uv0.y, Mathf.Min(uv1.y, uv2.y)) * resolution), 0, resolution - 1);
            var maxY = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(uv0.y, Mathf.Max(uv1.y, uv2.y)) * resolution), 0, resolution - 1);

            var area = Edge(uv0, uv1, uv2);
            if (Mathf.Approximately(area, 0f))
            {
                return;
            }

            for (var y = minY; y <= maxY; y++)
            {
                for (var x = minX; x <= maxX; x++)
                {
                    var index = x + y * resolution;
                    if (!lightMapIslandMask[index])
                    {
                        continue;
                    }

                    var uv = new Vector2((x + 0.5f) / resolution, (y + 0.5f) / resolution);
                    var w0 = Edge(uv1, uv2, uv) / area;
                    var w1 = Edge(uv2, uv0, uv) / area;
                    var w2 = Edge(uv0, uv1, uv) / area;
                    if (w0 < 0f || w1 < 0f || w2 < 0f)
                    {
                        continue;
                    }

                    normalBuffer[index] = (normal0 * w0 + normal1 * w1 + normal2 * w2).normalized;
                    normalMask[index] = true;
                }
            }
        }

        private float EvaluateNormalLightValue(float ndotl, float centerBias)
        {
            var wrapped = Mathf.Clamp01((ndotl - centerBias + normalLightWrap) / (1f + normalLightWrap));
            var value = Mathf.Clamp01(0.5f + (wrapped - 0.5f) / Mathf.Max(lightSoftness, 0.0001f));
            if (!Mathf.Approximately(lightContrast, 1f))
            {
                value = Mathf.Pow(value, 1f / lightContrast);
            }

            return value;
        }

        private float EvaluateDirectionalLightValue(float signedSide)
        {
            var value = Mathf.Clamp01(0.5f + signedSide / Mathf.Max(lightSoftness, 0.0001f));
            if (!Mathf.Approximately(lightContrast, 1f))
            {
                value = Mathf.Pow(value, 1f / lightContrast);
            }

            return value;
        }

        private byte[] BlurSingleChannel(byte[] source, bool[] applyMask, float radiusPixels)
        {
            if (radiusPixels <= 0f)
            {
                return (byte[])source.Clone();
            }

            var radius = Mathf.CeilToInt(radiusPixels);
            var sigma = Mathf.Max(radiusPixels / 3f, 0.0001f);
            var kernel = BuildGaussianKernel(radius, sigma);
            var temp = new float[source.Length];
            var tempWeight = new float[source.Length];
            var output = new byte[source.Length];

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    var index = x + y * resolution;
                    if (!applyMask[index])
                    {
                        continue;
                    }

                    var sum = 0f;
                    var weightSum = 0f;
                    for (var offsetX = -radius; offsetX <= radius; offsetX++)
                    {
                        var sampleX = x + offsetX;
                        if (sampleX < 0 || sampleX >= resolution)
                        {
                            continue;
                        }

                        var sampleIndex = sampleX + y * resolution;
                        if (!applyMask[sampleIndex])
                        {
                            continue;
                        }

                        var weight = kernel[offsetX + radius];
                        sum += source[sampleIndex] * weight;
                        weightSum += weight;
                    }

                    if (weightSum > 0f)
                    {
                        temp[index] = sum / weightSum;
                        tempWeight[index] = 1f;
                    }
                }
            }

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    var index = x + y * resolution;
                    if (!applyMask[index])
                    {
                        continue;
                    }

                    var sum = 0f;
                    var weightSum = 0f;
                    for (var offsetY = -radius; offsetY <= radius; offsetY++)
                    {
                        var sampleY = y + offsetY;
                        if (sampleY < 0 || sampleY >= resolution)
                        {
                            continue;
                        }

                        var sampleIndex = x + sampleY * resolution;
                        if (tempWeight[sampleIndex] <= 0f)
                        {
                            continue;
                        }

                        var weight = kernel[offsetY + radius];
                        sum += temp[sampleIndex] * weight;
                        weightSum += weight;
                    }

                    if (weightSum > 0f)
                    {
                        output[index] = (byte)Mathf.RoundToInt(sum / weightSum);
                    }
                }
            }

            return output;
        }

        private Texture2D GenerateDebugPreviewTexture(byte[] leftLightMap, byte[] rightLightMap, byte[] neckBlendMap, bool[] uvCoverageMask, bool[] lightMapIslandMask, bool[] noseHighlightPreviewMask, bool isMultiAngleGradient)
        {
            var texture = new Texture2D(resolution, resolution, TextureFormat.RGBA32, false, true)
            {
                name = Path.GetFileNameWithoutExtension(savePath) + "_Preview",
                filterMode = FilterMode.Bilinear,
                wrapMode = TextureWrapMode.Clamp
            };

            var pixels = new Color32[resolution * resolution];
            for (var i = 0; i < pixels.Length; i++)
            {
                if (!uvCoverageMask[i])
                {
                    pixels[i] = new Color32(0, 0, 0, 255);
                    continue;
                }

                var outputRed = isMultiAngleGradient ? rightLightMap[i] : (swapRG ? leftLightMap[i] : rightLightMap[i]);
                var outputGreen = isMultiAngleGradient ? leftLightMap[i] : (swapRG ? rightLightMap[i] : leftLightMap[i]);
                var outputBlue = neckBlendEnabled && lightMapIslandMask[i] ? neckBlendMap[i] : (byte)0;
                if (noseHighlightPreviewMask != null && noseHighlightPreviewMask[i])
                {
                    pixels[i] = new Color32(
                        (byte)Mathf.RoundToInt(outputRed * 0.35f),
                        255,
                        255,
                        255);
                }
                else if (!lightMapIslandMask[i])
                {
                    pixels[i] = new Color32(255, 255, 0, 255);
                    continue;
                }
                else
                {
                    pixels[i] = new Color32(outputRed, outputGreen, outputBlue, 255);
                }
            }

            texture.SetPixels32(pixels);
            texture.Apply(false, false);
            return texture;
        }

        private Texture2D GenerateChannelPreviewTexture(Color32[] packedPixels, int channel)
        {
            var pixels = new Color32[packedPixels.Length];
            for (var i = 0; i < pixels.Length; i++)
            {
                var value = channel == 0 ? packedPixels[i].r : channel == 1 ? packedPixels[i].g : packedPixels[i].b;
                pixels[i] = new Color32(value, value, value, 255);
            }

            return CreatePreviewTexture(channel == 0 ? "_R" : channel == 1 ? "_G" : "_B", pixels, FilterMode.Bilinear);
        }

        private Texture2D CreatePreviewTexture(string suffix, Color32[] pixels, FilterMode filterMode)
        {
            var texture = new Texture2D(resolution, resolution, TextureFormat.RGBA32, false, true)
            {
                name = Path.GetFileNameWithoutExtension(savePath) + suffix,
                filterMode = filterMode,
                wrapMode = TextureWrapMode.Clamp
            };

            texture.SetPixels32(pixels);
            texture.Apply(false, false);
            return texture;
        }

        private Texture2D GenerateMultiAngleGridPreviewTexture(byte[][] previewMaps)
        {
            if (previewMaps == null || previewMaps.Length != 9)
            {
                return null;
            }

            var texture = new Texture2D(resolution, resolution, TextureFormat.RGBA32, false, true)
            {
                name = Path.GetFileNameWithoutExtension(savePath) + "_MultiAngleGrid",
                filterMode = FilterMode.Point,
                wrapMode = TextureWrapMode.Clamp
            };

            var pixels = new Color32[resolution * resolution];
            for (var y = 0; y < resolution; y++)
            {
                var gridY = Mathf.Min(y * 3 / resolution, 2);
                var localY = y - gridY * resolution / 3;
                var cellHeight = Mathf.Max(((gridY + 1) * resolution / 3) - (gridY * resolution / 3), 1);
                var sampleY = Mathf.Clamp(localY * resolution / cellHeight, 0, resolution - 1);
                for (var x = 0; x < resolution; x++)
                {
                    var gridX = Mathf.Min(x * 3 / resolution, 2);
                    var mapIndex = gridX + (2 - gridY) * 3;
                    var localX = x - gridX * resolution / 3;
                    var cellWidth = Mathf.Max(((gridX + 1) * resolution / 3) - (gridX * resolution / 3), 1);
                    var sampleX = Mathf.Clamp(localX * resolution / cellWidth, 0, resolution - 1);
                    var value = previewMaps[mapIndex][sampleX + sampleY * resolution];
                    if (x == gridX * resolution / 3 || y == gridY * resolution / 3)
                    {
                        value = 255;
                    }

                    pixels[x + y * resolution] = new Color32(value, value, value, 255);
                }
            }

            texture.SetPixels32(pixels);
            texture.Apply(false, false);
            return texture;
        }

        private bool[] ExpandUvPadding(bool[] uvCoverageMask, bool[] lightMapIslandMask, byte[] leftLightMap, byte[] rightLightMap, byte[] neckBlendMap)
        {
            var outputCoverageMask = (bool[])uvCoverageMask.Clone();
            var padding = Mathf.Clamp(uvPaddingPixels, 0, 24);
            if (padding <= 0)
            {
                return outputCoverageMask;
            }

            var nearestSource = new int[uvCoverageMask.Length];
            var distances = new int[uvCoverageMask.Length];
            for (var i = 0; i < nearestSource.Length; i++)
            {
                nearestSource[i] = -1;
                distances[i] = int.MaxValue;
            }

            var queue = new Queue<int>();
            for (var i = 0; i < uvCoverageMask.Length; i++)
            {
                if (!uvCoverageMask[i])
                {
                    continue;
                }

                nearestSource[i] = i;
                distances[i] = 0;
                queue.Enqueue(i);
            }

            while (queue.Count > 0)
            {
                var index = queue.Dequeue();
                var distance = distances[index];
                if (distance >= padding)
                {
                    continue;
                }

                var x = index % resolution;
                var y = index / resolution;
                TryExpandUvPaddingPixel(outputCoverageMask, lightMapIslandMask, leftLightMap, rightLightMap, neckBlendMap, nearestSource, distances, queue, padding, x - 1, y, index);
                TryExpandUvPaddingPixel(outputCoverageMask, lightMapIslandMask, leftLightMap, rightLightMap, neckBlendMap, nearestSource, distances, queue, padding, x + 1, y, index);
                TryExpandUvPaddingPixel(outputCoverageMask, lightMapIslandMask, leftLightMap, rightLightMap, neckBlendMap, nearestSource, distances, queue, padding, x, y - 1, index);
                TryExpandUvPaddingPixel(outputCoverageMask, lightMapIslandMask, leftLightMap, rightLightMap, neckBlendMap, nearestSource, distances, queue, padding, x, y + 1, index);
                TryExpandUvPaddingPixel(outputCoverageMask, lightMapIslandMask, leftLightMap, rightLightMap, neckBlendMap, nearestSource, distances, queue, padding, x - 1, y - 1, index);
                TryExpandUvPaddingPixel(outputCoverageMask, lightMapIslandMask, leftLightMap, rightLightMap, neckBlendMap, nearestSource, distances, queue, padding, x + 1, y - 1, index);
                TryExpandUvPaddingPixel(outputCoverageMask, lightMapIslandMask, leftLightMap, rightLightMap, neckBlendMap, nearestSource, distances, queue, padding, x - 1, y + 1, index);
                TryExpandUvPaddingPixel(outputCoverageMask, lightMapIslandMask, leftLightMap, rightLightMap, neckBlendMap, nearestSource, distances, queue, padding, x + 1, y + 1, index);
            }

            return outputCoverageMask;
        }

        private void TryExpandUvPaddingPixel(bool[] outputCoverageMask, bool[] lightMapIslandMask, byte[] leftLightMap, byte[] rightLightMap, byte[] neckBlendMap, int[] nearestSource, int[] distances, Queue<int> queue, int padding, int x, int y, int fromIndex)
        {
            if (x < 0 || x >= resolution || y < 0 || y >= resolution)
            {
                return;
            }

            var index = x + y * resolution;
            var candidateDistance = distances[fromIndex] + 1;
            if (candidateDistance >= distances[index] || candidateDistance > padding)
            {
                return;
            }

            var sourceIndex = nearestSource[fromIndex];
            if (sourceIndex < 0)
            {
                return;
            }

            nearestSource[index] = sourceIndex;
            distances[index] = candidateDistance;
            outputCoverageMask[index] = true;
            lightMapIslandMask[index] = lightMapIslandMask[sourceIndex];
            leftLightMap[index] = leftLightMap[sourceIndex];
            rightLightMap[index] = rightLightMap[sourceIndex];
            neckBlendMap[index] = neckBlendMap[sourceIndex];
            queue.Enqueue(index);
        }

        private byte[] GenerateNeckBlendMap(TargetUvData targetUvData, bool[] lightMapIslandMask)
        {
            var output = new byte[resolution * resolution];
            if (!neckBlendEnabled || activeNeckBlendSource == VailNeckBlendSource.Disabled)
            {
                return output;
            }

            if (targetUvData.TriangleNeckBlendValues == null || targetUvData.TriangleNeckBlendValues.Count != targetUvData.TriangleUvs.Count)
            {
                activeNeckBlendSource = VailNeckBlendSource.Disabled;
                neckBlendDiagnostic = L("Bマスク用の頂点データがUV三角形と一致しません。", "B-mask vertex data does not match the UV triangles.");
                return output;
            }

            for (var i = 0; i + 2 < targetUvData.TriangleUvs.Count; i += 3)
            {
                RasterizeNeckBlendTriangle(
                    output,
                    lightMapIslandMask,
                    targetUvData.TriangleUvs[i],
                    targetUvData.TriangleUvs[i + 1],
                    targetUvData.TriangleUvs[i + 2],
                    targetUvData.TriangleNeckBlendValues[i],
                    targetUvData.TriangleNeckBlendValues[i + 1],
                    targetUvData.TriangleNeckBlendValues[i + 2]);
            }

            return output;
        }

        private void RasterizeNeckBlendTriangle(byte[] output, bool[] applyMask, Vector2 uv0, Vector2 uv1, Vector2 uv2, float value0, float value1, float value2)
        {
            var minX = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(uv0.x, Mathf.Min(uv1.x, uv2.x)) * resolution), 0, resolution - 1);
            var maxX = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(uv0.x, Mathf.Max(uv1.x, uv2.x)) * resolution), 0, resolution - 1);
            var minY = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(uv0.y, Mathf.Min(uv1.y, uv2.y)) * resolution), 0, resolution - 1);
            var maxY = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(uv0.y, Mathf.Max(uv1.y, uv2.y)) * resolution), 0, resolution - 1);
            var area = Edge(uv0, uv1, uv2);
            if (Mathf.Approximately(area, 0f))
            {
                return;
            }

            for (var y = minY; y <= maxY; y++)
            {
                for (var x = minX; x <= maxX; x++)
                {
                    var index = x + y * resolution;
                    if (!applyMask[index])
                    {
                        continue;
                    }

                    var uv = new Vector2((x + 0.5f) / resolution, (y + 0.5f) / resolution);
                    var w0 = Edge(uv1, uv2, uv) / area;
                    var w1 = Edge(uv2, uv0, uv) / area;
                    var w2 = Edge(uv0, uv1, uv) / area;
                    if (w0 < 0f || w1 < 0f || w2 < 0f)
                    {
                        continue;
                    }

                    var value = Mathf.Clamp01(value0 * w0 + value1 * w1 + value2 * w2);
                    output[index] = (byte)Mathf.Max(output[index], Mathf.RoundToInt(value * 255f));
                }
            }
        }

        private bool[] GenerateLightMapIslandMask(TargetUvData targetUvData, bool[] uvCoverageMask)
        {
            var mask = new bool[resolution * resolution];
            if (lightMapIslandSeeds.Count == 0)
            {
                return mask;
            }

            for (var i = 0; i < lightMapIslandSeeds.Count; i++)
            {
                var islandMask = new bool[resolution * resolution];
                FloodFillUvIsland(uvCoverageMask, islandMask, lightMapIslandSeeds[i]);

                if (!excludeOppositeFacingUv ||
                    !TryBuildFacingRestrictedIslandMask(targetUvData, islandMask, lightMapIslandSeeds[i], out var facingMask))
                {
                    UnionMask(mask, islandMask);
                    continue;
                }

                UnionMask(mask, facingMask);
            }

            return mask;
        }

        private bool[] GenerateUnrestrictedLightMapIslandMask(bool[] uvCoverageMask)
        {
            var mask = new bool[resolution * resolution];
            for (var i = 0; i < lightMapIslandSeeds.Count; i++)
            {
                FloodFillUvIsland(uvCoverageMask, mask, lightMapIslandSeeds[i]);
            }

            return mask;
        }

        private bool TryBuildFacingRestrictedIslandMask(TargetUvData targetUvData, bool[] islandMask, Vector2 seedUv, out bool[] facingMask)
        {
            facingMask = new bool[resolution * resolution];
            if (!TryResolveSeedFacingDirection(targetUvData, seedUv, out var facingDirection))
            {
                return false;
            }

            var sawFrontFacingTriangle = false;
            var sawOppositeFacingTriangle = false;
            for (var i = 0; i + 2 < targetUvData.TriangleUvs.Count; i += 3)
            {
                var uv0 = targetUvData.TriangleUvs[i];
                var uv1 = targetUvData.TriangleUvs[i + 1];
                var uv2 = targetUvData.TriangleUvs[i + 2];
                if (!TriangleOverlapsMask(uv0, uv1, uv2, islandMask))
                {
                    continue;
                }

                var triangleNormal = ResolveTriangleNormal(targetUvData, i);
                if (triangleNormal.sqrMagnitude < 0.0001f)
                {
                    return false;
                }

                var facingDot = Vector3.Dot(triangleNormal, facingDirection);
                sawFrontFacingTriangle |= facingDot >= 0.35f;
                sawOppositeFacingTriangle |= facingDot <= -0.35f;
                if (IsFacingNormalIncluded(triangleNormal, facingDirection))
                {
                    RasterizeUvTriangle(facingMask, uv0, uv1, uv2);
                }
            }

            if (!sawFrontFacingTriangle || !sawOppositeFacingTriangle)
            {
                return false;
            }

            var islandPixelCount = 0;
            var facingPixelCount = 0;
            for (var i = 0; i < islandMask.Length; i++)
            {
                if (!islandMask[i])
                {
                    facingMask[i] = false;
                    continue;
                }

                islandPixelCount++;
                if (facingMask[i])
                {
                    facingPixelCount++;
                }
            }

            var seedX = Mathf.Clamp(Mathf.FloorToInt(seedUv.x * resolution), 0, resolution - 1);
            var seedY = Mathf.Clamp(Mathf.FloorToInt(seedUv.y * resolution), 0, resolution - 1);
            var seedIndex = seedX + seedY * resolution;
            return islandPixelCount > 0 &&
                   facingMask[seedIndex] &&
                   facingPixelCount >= islandPixelCount * MinimumFacingMaskCoverage;
        }

        private static bool TryResolveSeedFacingDirection(TargetUvData targetUvData, Vector2 seedUv, out Vector3 facingDirection)
        {
            facingDirection = Vector3.zero;
            var bestInteriorScore = float.MinValue;
            var bestNormal = Vector3.zero;
            for (var i = 0; i + 2 < targetUvData.TriangleUvs.Count; i += 3)
            {
                if (!TryCalculateUvBarycentric(
                        targetUvData.TriangleUvs[i],
                        targetUvData.TriangleUvs[i + 1],
                        targetUvData.TriangleUvs[i + 2],
                        seedUv,
                        out var barycentric))
                {
                    continue;
                }

                var interiorScore = Mathf.Min(barycentric.x, Mathf.Min(barycentric.y, barycentric.z));
                if (interiorScore <= bestInteriorScore)
                {
                    continue;
                }

                var normal = ResolveTriangleNormal(targetUvData, i, barycentric);
                if (normal.sqrMagnitude < 0.0001f)
                {
                    continue;
                }

                bestInteriorScore = interiorScore;
                bestNormal = normal;
            }

            if (bestNormal.sqrMagnitude < 0.0001f)
            {
                return false;
            }

            return TryResolveFacingDirection(bestNormal, out facingDirection);
        }

        internal static bool TryResolveFacingDirection(Vector3 seedNormal, out Vector3 facingDirection)
        {
            facingDirection = Vector3.zero;
            if (seedNormal.sqrMagnitude < 0.0001f)
            {
                return false;
            }

            seedNormal.Normalize();

            // Vail's light rig uses mesh-local X as left/right, Y as up, and Z as face depth.
            // Snap to the depth axis when possible so clicking either cheek keeps both sides symmetric.
            if (Mathf.Abs(seedNormal.z) >= 0.25f)
            {
                facingDirection = seedNormal.z >= 0f ? Vector3.forward : Vector3.back;
                return true;
            }

            var horizontalNormal = new Vector3(seedNormal.x, 0f, seedNormal.z);
            if (horizontalNormal.sqrMagnitude < 0.0625f)
            {
                return false;
            }

            facingDirection = horizontalNormal.normalized;
            return true;
        }

        internal static bool IsFacingNormalIncluded(Vector3 normal, Vector3 facingDirection)
        {
            if (normal.sqrMagnitude < 0.0001f || facingDirection.sqrMagnitude < 0.0001f)
            {
                return false;
            }

            return Vector3.Dot(normal.normalized, facingDirection.normalized) >= OppositeFacingDotThreshold;
        }

        private static Vector3 ResolveTriangleNormal(TargetUvData targetUvData, int triangleStart)
        {
            return ResolveTriangleNormal(targetUvData, triangleStart, new Vector3(1f / 3f, 1f / 3f, 1f / 3f));
        }

        private static Vector3 ResolveTriangleNormal(TargetUvData targetUvData, int triangleStart, Vector3 barycentric)
        {
            if (triangleStart + 2 < targetUvData.TriangleNormals.Count)
            {
                var normal = targetUvData.TriangleNormals[triangleStart] * barycentric.x +
                             targetUvData.TriangleNormals[triangleStart + 1] * barycentric.y +
                             targetUvData.TriangleNormals[triangleStart + 2] * barycentric.z;
                if (normal.sqrMagnitude >= 0.0001f)
                {
                    return normal.normalized;
                }
            }

            if (triangleStart + 2 >= targetUvData.TrianglePositions.Count)
            {
                return Vector3.zero;
            }

            var edge1 = targetUvData.TrianglePositions[triangleStart + 1] - targetUvData.TrianglePositions[triangleStart];
            var edge2 = targetUvData.TrianglePositions[triangleStart + 2] - targetUvData.TrianglePositions[triangleStart];
            return Vector3.Cross(edge1, edge2).normalized;
        }

        private static bool TryCalculateUvBarycentric(Vector2 uv0, Vector2 uv1, Vector2 uv2, Vector2 point, out Vector3 barycentric)
        {
            barycentric = Vector3.zero;
            var area = Edge(uv0, uv1, uv2);
            if (Mathf.Abs(area) < 0.0000001f)
            {
                return false;
            }

            barycentric.x = Edge(uv1, uv2, point) / area;
            barycentric.y = Edge(uv2, uv0, point) / area;
            barycentric.z = Edge(uv0, uv1, point) / area;
            const float tolerance = -0.0001f;
            return barycentric.x >= tolerance && barycentric.y >= tolerance && barycentric.z >= tolerance;
        }

        private static void UnionMask(bool[] destination, bool[] source)
        {
            for (var i = 0; i < destination.Length; i++)
            {
                destination[i] |= source[i];
            }
        }

        private bool[] GenerateInnerBorderHoleMask(bool[] lightMapIslandMask)
        {
            var mask = new bool[resolution * resolution];
            if (innerBorderMaxSeeds.Count == 0)
            {
                return mask;
            }

            var exteriorOutsideMask = BuildExteriorOutsideMask(lightMapIslandMask);
            for (var i = 0; i < innerBorderMaxSeeds.Count; i++)
            {
                FloodFillInteriorHole(lightMapIslandMask, exteriorOutsideMask, mask, innerBorderMaxSeeds[i]);
            }

            return mask;
        }

        private void ApplyFinalBlur(byte[] leftLightMap, byte[] rightLightMap, bool[] lightMapIslandMask)
        {
            if (finalBlurPixels <= 0f)
            {
                return;
            }

            var sourceLeft = (byte[])leftLightMap.Clone();
            var sourceRight = (byte[])rightLightMap.Clone();
            var radius = Mathf.CeilToInt(finalBlurPixels);
            var sigma = Mathf.Max(finalBlurPixels / 3f, 0.0001f);
            var kernel = BuildGaussianKernel(radius, sigma);
            var tempLeft = new float[leftLightMap.Length];
            var tempRight = new float[rightLightMap.Length];
            var tempWeight = new float[leftLightMap.Length];

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    var index = x + y * resolution;
                    if (!lightMapIslandMask[index])
                    {
                        continue;
                    }

                    var leftSum = 0f;
                    var rightSum = 0f;
                    var weightSum = 0f;
                    for (var offsetX = -radius; offsetX <= radius; offsetX++)
                    {
                        var sampleX = x + offsetX;
                        if (sampleX < 0 || sampleX >= resolution)
                        {
                            continue;
                        }

                        var sampleIndex = sampleX + y * resolution;
                        if (!lightMapIslandMask[sampleIndex])
                        {
                            continue;
                        }

                        var weight = kernel[offsetX + radius];
                        leftSum += sourceLeft[sampleIndex] * weight;
                        rightSum += sourceRight[sampleIndex] * weight;
                        weightSum += weight;
                    }

                    if (weightSum > 0f)
                    {
                        tempLeft[index] = leftSum / weightSum;
                        tempRight[index] = rightSum / weightSum;
                        tempWeight[index] = 1f;
                    }
                }
            }

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    var index = x + y * resolution;
                    if (!lightMapIslandMask[index])
                    {
                        continue;
                    }

                    var leftSum = 0f;
                    var rightSum = 0f;
                    var weightSum = 0f;
                    for (var offsetY = -radius; offsetY <= radius; offsetY++)
                    {
                        var sampleY = y + offsetY;
                        if (sampleY < 0 || sampleY >= resolution)
                        {
                            continue;
                        }

                        var sampleIndex = x + sampleY * resolution;
                        if (tempWeight[sampleIndex] <= 0f)
                        {
                            continue;
                        }

                        var weight = kernel[offsetY + radius];
                        leftSum += tempLeft[sampleIndex] * weight;
                        rightSum += tempRight[sampleIndex] * weight;
                        weightSum += weight;
                    }

                    if (weightSum > 0f)
                    {
                        leftLightMap[index] = (byte)Mathf.RoundToInt(leftSum / weightSum);
                        rightLightMap[index] = (byte)Mathf.RoundToInt(rightSum / weightSum);
                    }
                }
            }
        }

        private static float[] BuildGaussianKernel(int radius, float sigma)
        {
            var kernel = new float[radius * 2 + 1];
            for (var i = -radius; i <= radius; i++)
            {
                var normalized = i / sigma;
                kernel[i + radius] = Mathf.Exp(-0.5f * normalized * normalized);
            }

            return kernel;
        }

        private Rect CalculateMaskUvBounds(bool[] mask)
        {
            if (!TryGetMaskPixelBounds(mask, out var minX, out var minY, out var maxX, out var maxY))
            {
                return new Rect(0f, 0f, 1f, 1f);
            }

            var min = new Vector2(minX / (float)resolution, minY / (float)resolution);
            var max = new Vector2((maxX + 1f) / resolution, (maxY + 1f) / resolution);
            return Rect.MinMaxRect(min.x, min.y, max.x, max.y);
        }

        private void GetPlacementFrame(Rect uvBounds, out Vector2 center, out Vector2 halfBounds)
        {
            center = new Vector2(uvBounds.center.x * resolution, uvBounds.center.y * resolution);
            halfBounds = new Vector2(
                Mathf.Max(uvBounds.width * resolution * 0.5f, 1f),
                Mathf.Max(uvBounds.height * resolution * 0.5f, 1f));
        }

        private void ApplyCheekMax(byte[] leftLightMap, byte[] rightLightMap, bool[] lightMapIslandMask, Rect lightMapUvBounds)
        {
            if (!cheekMaxEnabled)
            {
                return;
            }

            GetPlacementFrame(lightMapUvBounds, out var center, out var halfBounds);
            var halfShape = new Vector2(
                Mathf.Max(halfBounds.x * 2f * Mathf.Max(cheekScaleX, 0.001f), 1f),
                Mathf.Max(halfBounds.y * 2f * Mathf.Max(cheekScaleY, 0.001f), 1f));
            var blur = Mathf.Max(cheekBlurPixels, 0f);
            var leftCenter = center + new Vector2(-halfBounds.x * cheekOffsetX, halfBounds.y * cheekOffsetY);
            var rightCenter = center + new Vector2(halfBounds.x * cheekOffsetX, halfBounds.y * cheekOffsetY);

            var maxSourceMask = new bool[leftLightMap.Length];
            MarkCheekShape(maxSourceMask, lightMapIslandMask, leftCenter, halfShape);
            MarkCheekShape(maxSourceMask, lightMapIslandMask, rightCenter, halfShape);
            ApplyGaussianMaxSourceBlur(leftLightMap, rightLightMap, lightMapIslandMask, maxSourceMask, blur);
        }

        private bool TryGetMaskPixelBounds(bool[] mask, out int minX, out int minY, out int maxX, out int maxY)
        {
            minX = resolution;
            minY = resolution;
            maxX = -1;
            maxY = -1;

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    if (!mask[x + y * resolution])
                    {
                        continue;
                    }

                    minX = Mathf.Min(minX, x);
                    minY = Mathf.Min(minY, y);
                    maxX = Mathf.Max(maxX, x);
                    maxY = Mathf.Max(maxY, y);
                }
            }

            return maxX >= minX && maxY >= minY;
        }

        private void MarkCheekShape(bool[] maxSourceMask, bool[] lightMapIslandMask, Vector2 center, Vector2 halfShape)
        {
            var reach = Mathf.CeilToInt(Mathf.Max(halfShape.x, halfShape.y));
            var startX = Mathf.Clamp(Mathf.FloorToInt(center.x - reach), 0, resolution - 1);
            var endX = Mathf.Clamp(Mathf.CeilToInt(center.x + reach), 0, resolution - 1);
            var startY = Mathf.Clamp(Mathf.FloorToInt(center.y - reach), 0, resolution - 1);
            var endY = Mathf.Clamp(Mathf.CeilToInt(center.y + reach), 0, resolution - 1);

            for (var y = startY; y <= endY; y++)
            {
                for (var x = startX; x <= endX; x++)
                {
                    var index = x + y * resolution;
                    if (!lightMapIslandMask[index])
                    {
                        continue;
                    }

                    var point = new Vector2(x + 0.5f, y + 0.5f);
                    if (!IsInsideCheekShape(point, center, halfShape))
                    {
                        continue;
                    }

                    maxSourceMask[index] = true;
                }
            }
        }

        private bool IsInsideCheekShape(Vector2 point, Vector2 center, Vector2 halfShape)
        {
            if (cheekShape == CheekShape.Round)
            {
                var local = point - center;
                var normalizedDistance = Mathf.Sqrt(
                    Mathf.Pow(local.x / Mathf.Max(halfShape.x, 0.0001f), 2f) +
                    Mathf.Pow(local.y / Mathf.Max(halfShape.y, 0.0001f), 2f));
                return normalizedDistance <= 1f;
            }

            var top = center + new Vector2(0f, halfShape.y);
            var bottom = center + new Vector2(0f, -halfShape.y);
            var leftTop = center + new Vector2(-halfShape.x, halfShape.y);
            var rightTop = center + new Vector2(halfShape.x, halfShape.y);
            var leftBottom = center + new Vector2(-halfShape.x, -halfShape.y);
            var rightBottom = center + new Vector2(halfShape.x, -halfShape.y);

            var a = cheekShape == CheekShape.TriangleUp ? top : bottom;
            var b = cheekShape == CheekShape.TriangleUp ? leftBottom : leftTop;
            var c = cheekShape == CheekShape.TriangleUp ? rightBottom : rightTop;
            return IsPointInsideTriangle(point, a, b, c);
        }

        private static bool IsPointInsideTriangle(Vector2 point, Vector2 a, Vector2 b, Vector2 c)
        {
            var area = Edge(a, b, c);
            var w0 = Edge(b, c, point);
            var w1 = Edge(c, a, point);
            var w2 = Edge(a, b, point);
            return area >= 0f
                ? w0 >= 0f && w1 >= 0f && w2 >= 0f
                : w0 <= 0f && w1 <= 0f && w2 <= 0f;
        }

        private void ApplyNoseHighlightChannelSwap(byte[] leftLightMap, byte[] rightLightMap, bool[] lightMapIslandMask, Rect lightMapUvBounds)
        {
            if (!noseHighlightEnabled)
            {
                return;
            }

            GetPlacementFrame(lightMapUvBounds, out var center, out var halfBounds);
            var halfShape = new Vector2(
                Mathf.Max(halfBounds.x * 2f * Mathf.Max(noseScaleX, 0.001f), 1f),
                Mathf.Max(halfBounds.y * 2f * Mathf.Max(noseScaleY, 0.001f), 1f));
            var noseCenter = center + new Vector2(halfBounds.x * noseOffsetX, halfBounds.y * noseOffsetY);
            var maxSourceMask = new bool[leftLightMap.Length];
            MarkNoseHighlightShape(maxSourceMask, lightMapIslandMask, noseCenter, halfShape);
            ApplyGaussianChannelSwap(leftLightMap, rightLightMap, lightMapIslandMask, maxSourceMask, Mathf.Max(noseBlurPixels, 0f));
        }

        private bool[] GenerateNoseHighlightPreviewMask(bool[] lightMapIslandMask, Rect lightMapUvBounds)
        {
            var previewMask = new bool[resolution * resolution];
            if (!noseHighlightEnabled)
            {
                return previewMask;
            }

            GetPlacementFrame(lightMapUvBounds, out var center, out var halfBounds);
            var halfShape = new Vector2(
                Mathf.Max(halfBounds.x * 2f * Mathf.Max(noseScaleX, 0.001f), 1f),
                Mathf.Max(halfBounds.y * 2f * Mathf.Max(noseScaleY, 0.001f), 1f));
            var noseCenter = center + new Vector2(halfBounds.x * noseOffsetX, halfBounds.y * noseOffsetY);
            MarkNoseHighlightShape(previewMask, lightMapIslandMask, noseCenter, halfShape);
            return previewMask;
        }

        private void MarkNoseHighlightShape(bool[] maxSourceMask, bool[] lightMapIslandMask, Vector2 center, Vector2 halfShape)
        {
            var reach = Mathf.CeilToInt(Mathf.Max(halfShape.x, halfShape.y));
            var startX = Mathf.Clamp(Mathf.FloorToInt(center.x - reach), 0, resolution - 1);
            var endX = Mathf.Clamp(Mathf.CeilToInt(center.x + reach), 0, resolution - 1);
            var startY = Mathf.Clamp(Mathf.FloorToInt(center.y - reach), 0, resolution - 1);
            var endY = Mathf.Clamp(Mathf.CeilToInt(center.y + reach), 0, resolution - 1);

            for (var y = startY; y <= endY; y++)
            {
                for (var x = startX; x <= endX; x++)
                {
                    var index = x + y * resolution;
                    if (!lightMapIslandMask[index])
                    {
                        continue;
                    }

                    var point = new Vector2(x + 0.5f, y + 0.5f);
                    if (IsInsideNoseHighlightShape(point, center, halfShape))
                    {
                        maxSourceMask[index] = true;
                    }
                }
            }
        }

        private bool IsInsideNoseHighlightShape(Vector2 point, Vector2 center, Vector2 halfShape)
        {
            var local = point - center;
            if (noseHighlightShape == NoseHighlightShape.Round)
            {
                var normalizedDistance = Mathf.Sqrt(
                    Mathf.Pow(local.x / Mathf.Max(halfShape.x, 0.0001f), 2f) +
                    Mathf.Pow(local.y / Mathf.Max(halfShape.y, 0.0001f), 2f));
                return normalizedDistance <= 1f;
            }

            var normalizedDiamondDistance =
                Mathf.Abs(local.x) / Mathf.Max(halfShape.x, 0.0001f) +
                Mathf.Abs(local.y) / Mathf.Max(halfShape.y, 0.0001f);
            return normalizedDiamondDistance <= 1f;
        }

        private void ApplyGaussianChannelSwap(byte[] leftLightMap, byte[] rightLightMap, bool[] applyMask, bool[] swapSourceMask, float radiusPixels)
        {
            if (!ContainsAnyPixel(swapSourceMask))
            {
                return;
            }

            var radius = Mathf.CeilToInt(radiusPixels);
            if (radius <= 0)
            {
                ApplySolidChannelSwap(leftLightMap, rightLightMap, applyMask, swapSourceMask);
                return;
            }

            var sourceLeft = (byte[])leftLightMap.Clone();
            var sourceRight = (byte[])rightLightMap.Clone();
            var sigma = Mathf.Max(radiusPixels / 3f, 0.0001f);
            var kernel = BuildGaussianKernel(radius, sigma);
            var tempAlpha = new float[leftLightMap.Length];
            var tempWeight = new float[leftLightMap.Length];

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    var index = x + y * resolution;
                    if (!applyMask[index] && !swapSourceMask[index])
                    {
                        continue;
                    }

                    var alphaSum = 0f;
                    var weightSum = 0f;
                    for (var offsetX = -radius; offsetX <= radius; offsetX++)
                    {
                        var sampleX = x + offsetX;
                        if (sampleX < 0 || sampleX >= resolution)
                        {
                            continue;
                        }

                        var sampleIndex = sampleX + y * resolution;
                        var weight = kernel[offsetX + radius];
                        alphaSum += (swapSourceMask[sampleIndex] ? 1f : 0f) * weight;
                        weightSum += weight;
                    }

                    if (weightSum > 0f)
                    {
                        tempAlpha[index] = alphaSum / weightSum;
                        tempWeight[index] = 1f;
                    }
                }
            }

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    var index = x + y * resolution;
                    if (!applyMask[index])
                    {
                        continue;
                    }

                    var alphaSum = 0f;
                    var weightSum = 0f;
                    for (var offsetY = -radius; offsetY <= radius; offsetY++)
                    {
                        var sampleY = y + offsetY;
                        if (sampleY < 0 || sampleY >= resolution)
                        {
                            continue;
                        }

                        var sampleIndex = x + sampleY * resolution;
                        if (tempWeight[sampleIndex] <= 0f)
                        {
                            continue;
                        }

                        var weight = kernel[offsetY + radius];
                        alphaSum += tempAlpha[sampleIndex] * weight;
                        weightSum += weight;
                    }

                    if (weightSum > 0f)
                    {
                        var alpha = Mathf.Clamp01(alphaSum / weightSum);
                        leftLightMap[index] = (byte)Mathf.RoundToInt(Mathf.Lerp(sourceLeft[index], sourceRight[index], alpha));
                        rightLightMap[index] = (byte)Mathf.RoundToInt(Mathf.Lerp(sourceRight[index], sourceLeft[index], alpha));
                    }
                }
            }
        }

        private static void ApplySolidChannelSwap(byte[] leftLightMap, byte[] rightLightMap, bool[] applyMask, bool[] swapSourceMask)
        {
            for (var i = 0; i < applyMask.Length; i++)
            {
                if (!applyMask[i] || !swapSourceMask[i])
                {
                    continue;
                }

                var left = leftLightMap[i];
                leftLightMap[i] = rightLightMap[i];
                rightLightMap[i] = left;
            }
        }

        private void ApplyUvBorderMax(byte[] leftLightMap, byte[] rightLightMap, bool[] lightMapIslandMask)
        {
            if (uvBorderFadePixels <= 0f && uvBorderPaddingPixels <= 0)
            {
                return;
            }

            var exteriorOutsideMask = BuildExteriorOutsideMask(lightMapIslandMask);
            var maxSourceMask = ExpandMaxSourceIntoApplyMask(exteriorOutsideMask, lightMapIslandMask, uvBorderPaddingPixels);
            ApplyGaussianMaxSourceBlur(leftLightMap, rightLightMap, lightMapIslandMask, maxSourceMask, uvBorderFadePixels);
        }

        private void ApplyInnerHoleBorderMax(byte[] leftLightMap, byte[] rightLightMap, bool[] lightMapIslandMask, bool[] innerBorderHoleMask)
        {
            if (innerBorderFadePixels <= 0f && innerBorderPaddingPixels <= 0)
            {
                return;
            }

            var maxSourceMask = ExpandMaxSourceIntoApplyMask(innerBorderHoleMask, lightMapIslandMask, innerBorderPaddingPixels);
            if (!ContainsAnyPixel(maxSourceMask))
            {
                return;
            }

            ApplyGaussianMaxSourceBlur(leftLightMap, rightLightMap, lightMapIslandMask, maxSourceMask, innerBorderFadePixels);
        }

        private bool[] ExpandMaxSourceIntoApplyMask(bool[] maxSourceMask, bool[] applyMask, int paddingPixels)
        {
            var expanded = (bool[])maxSourceMask.Clone();
            var padding = Mathf.Clamp(paddingPixels, 0, 24);
            if (padding <= 0)
            {
                return expanded;
            }

            var distances = new int[maxSourceMask.Length];
            for (var i = 0; i < distances.Length; i++)
            {
                distances[i] = int.MaxValue;
            }

            var queue = new Queue<int>();
            for (var i = 0; i < maxSourceMask.Length; i++)
            {
                if (!maxSourceMask[i])
                {
                    continue;
                }

                distances[i] = 0;
                queue.Enqueue(i);
            }

            while (queue.Count > 0)
            {
                var index = queue.Dequeue();
                if (distances[index] >= padding)
                {
                    continue;
                }

                var x = index % resolution;
                var y = index / resolution;
                TryExpandMaxSourcePixel(expanded, applyMask, distances, queue, padding, x - 1, y, index);
                TryExpandMaxSourcePixel(expanded, applyMask, distances, queue, padding, x + 1, y, index);
                TryExpandMaxSourcePixel(expanded, applyMask, distances, queue, padding, x, y - 1, index);
                TryExpandMaxSourcePixel(expanded, applyMask, distances, queue, padding, x, y + 1, index);
                TryExpandMaxSourcePixel(expanded, applyMask, distances, queue, padding, x - 1, y - 1, index);
                TryExpandMaxSourcePixel(expanded, applyMask, distances, queue, padding, x + 1, y - 1, index);
                TryExpandMaxSourcePixel(expanded, applyMask, distances, queue, padding, x - 1, y + 1, index);
                TryExpandMaxSourcePixel(expanded, applyMask, distances, queue, padding, x + 1, y + 1, index);
            }

            return expanded;
        }

        private void TryExpandMaxSourcePixel(bool[] expanded, bool[] applyMask, int[] distances, Queue<int> queue, int padding, int x, int y, int fromIndex)
        {
            if (x < 0 || x >= resolution || y < 0 || y >= resolution)
            {
                return;
            }

            var index = x + y * resolution;
            if (!applyMask[index])
            {
                return;
            }

            var candidateDistance = distances[fromIndex] + 1;
            if (candidateDistance >= distances[index] || candidateDistance > padding)
            {
                return;
            }

            distances[index] = candidateDistance;
            expanded[index] = true;
            queue.Enqueue(index);
        }

        private void ApplyGaussianMaxSourceBlur(byte[] leftLightMap, byte[] rightLightMap, bool[] applyMask, bool[] maxSourceMask, float radiusPixels)
        {
            if (!ContainsAnyPixel(maxSourceMask))
            {
                return;
            }

            var radius = Mathf.CeilToInt(radiusPixels);
            if (radius <= 0)
            {
                ApplySolidMaxSource(leftLightMap, rightLightMap, applyMask, maxSourceMask);
                return;
            }

            var sourceLeft = (byte[])leftLightMap.Clone();
            var sourceRight = (byte[])rightLightMap.Clone();
            var sigma = Mathf.Max(radiusPixels / 3f, 0.0001f);
            var kernel = BuildGaussianKernel(radius, sigma);
            var tempAlpha = new float[leftLightMap.Length];
            var tempWeight = new float[leftLightMap.Length];

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    var index = x + y * resolution;
                    if (!applyMask[index] && !maxSourceMask[index])
                    {
                        continue;
                    }

                    var alphaSum = 0f;
                    var weightSum = 0f;
                    for (var offsetX = -radius; offsetX <= radius; offsetX++)
                    {
                        var sampleX = x + offsetX;
                        if (sampleX < 0 || sampleX >= resolution)
                        {
                            continue;
                        }

                        var sampleIndex = sampleX + y * resolution;
                        var weight = kernel[offsetX + radius];
                        alphaSum += (maxSourceMask[sampleIndex] ? 1f : 0f) * weight;
                        weightSum += weight;
                    }

                    if (weightSum > 0f)
                    {
                        tempAlpha[index] = alphaSum / weightSum;
                        tempWeight[index] = 1f;
                    }
                }
            }

            for (var y = 0; y < resolution; y++)
            {
                for (var x = 0; x < resolution; x++)
                {
                    var index = x + y * resolution;
                    if (!applyMask[index])
                    {
                        continue;
                    }

                    var alphaSum = 0f;
                    var weightSum = 0f;
                    for (var offsetY = -radius; offsetY <= radius; offsetY++)
                    {
                        var sampleY = y + offsetY;
                        if (sampleY < 0 || sampleY >= resolution)
                        {
                            continue;
                        }

                        var sampleIndex = x + sampleY * resolution;
                        if (tempWeight[sampleIndex] <= 0f)
                        {
                            continue;
                        }

                        var weight = kernel[offsetY + radius];
                        alphaSum += tempAlpha[sampleIndex] * weight;
                        weightSum += weight;
                    }

                    if (weightSum > 0f)
                    {
                        var alpha = Mathf.Clamp01(alphaSum / weightSum);
                        leftLightMap[index] = (byte)Mathf.RoundToInt(Mathf.Lerp(sourceLeft[index], 255f, alpha));
                        rightLightMap[index] = (byte)Mathf.RoundToInt(Mathf.Lerp(sourceRight[index], 255f, alpha));
                    }
                }
            }
        }

        private static void ApplySolidMaxSource(byte[] leftLightMap, byte[] rightLightMap, bool[] applyMask, bool[] maxSourceMask)
        {
            for (var i = 0; i < applyMask.Length; i++)
            {
                if (!applyMask[i] || !maxSourceMask[i])
                {
                    continue;
                }

                leftLightMap[i] = 255;
                rightLightMap[i] = 255;
            }
        }

        private static bool ContainsAnyPixel(bool[] mask)
        {
            for (var i = 0; i < mask.Length; i++)
            {
                if (mask[i])
                {
                    return true;
                }
            }

            return false;
        }

        private bool[] BuildExteriorOutsideMask(bool[] insideMask)
        {
            var exteriorOutsideMask = new bool[insideMask.Length];
            var queue = new Queue<int>();

            for (var x = 0; x < resolution; x++)
            {
                TryEnqueueExteriorOutside(insideMask, exteriorOutsideMask, queue, x, 0);
                TryEnqueueExteriorOutside(insideMask, exteriorOutsideMask, queue, x, resolution - 1);
            }

            for (var y = 1; y < resolution - 1; y++)
            {
                TryEnqueueExteriorOutside(insideMask, exteriorOutsideMask, queue, 0, y);
                TryEnqueueExteriorOutside(insideMask, exteriorOutsideMask, queue, resolution - 1, y);
            }

            while (queue.Count > 0)
            {
                var index = queue.Dequeue();
                var x = index % resolution;
                var y = index / resolution;

                TryEnqueueExteriorOutside(insideMask, exteriorOutsideMask, queue, x - 1, y);
                TryEnqueueExteriorOutside(insideMask, exteriorOutsideMask, queue, x + 1, y);
                TryEnqueueExteriorOutside(insideMask, exteriorOutsideMask, queue, x, y - 1);
                TryEnqueueExteriorOutside(insideMask, exteriorOutsideMask, queue, x, y + 1);
            }

            return exteriorOutsideMask;
        }

        private void TryEnqueueExteriorOutside(bool[] insideMask, bool[] exteriorOutsideMask, Queue<int> queue, int x, int y)
        {
            if (x < 0 || x >= resolution || y < 0 || y >= resolution)
            {
                return;
            }

            var index = x + y * resolution;
            if (insideMask[index] || exteriorOutsideMask[index])
            {
                return;
            }

            exteriorOutsideMask[index] = true;
            queue.Enqueue(index);
        }

        private void FloodFillInteriorHole(bool[] islandMask, bool[] exteriorOutsideMask, bool[] outputMask, Vector2 seedUv)
        {
            var seedX = Mathf.Clamp(Mathf.FloorToInt(seedUv.x * resolution), 0, resolution - 1);
            var seedY = Mathf.Clamp(Mathf.FloorToInt(seedUv.y * resolution), 0, resolution - 1);
            var seedIndex = seedX + seedY * resolution;
            if (islandMask[seedIndex] || exteriorOutsideMask[seedIndex])
            {
                return;
            }

            var queue = new Queue<int>();
            queue.Enqueue(seedIndex);
            outputMask[seedIndex] = true;

            while (queue.Count > 0)
            {
                var index = queue.Dequeue();
                var x = index % resolution;
                var y = index / resolution;

                TryEnqueueInteriorHolePixel(islandMask, exteriorOutsideMask, outputMask, queue, x - 1, y);
                TryEnqueueInteriorHolePixel(islandMask, exteriorOutsideMask, outputMask, queue, x + 1, y);
                TryEnqueueInteriorHolePixel(islandMask, exteriorOutsideMask, outputMask, queue, x, y - 1);
                TryEnqueueInteriorHolePixel(islandMask, exteriorOutsideMask, outputMask, queue, x, y + 1);
            }
        }

        private void TryEnqueueInteriorHolePixel(bool[] islandMask, bool[] exteriorOutsideMask, bool[] outputMask, Queue<int> queue, int x, int y)
        {
            if (x < 0 || x >= resolution || y < 0 || y >= resolution)
            {
                return;
            }

            var index = x + y * resolution;
            if (islandMask[index] || exteriorOutsideMask[index] || outputMask[index])
            {
                return;
            }

            outputMask[index] = true;
            queue.Enqueue(index);
        }

        private void FloodFillUvIsland(bool[] uvCoverageMask, bool[] outputMask, Vector2 seedUv)
        {
            var seedX = Mathf.Clamp(Mathf.FloorToInt(seedUv.x * resolution), 0, resolution - 1);
            var seedY = Mathf.Clamp(Mathf.FloorToInt(seedUv.y * resolution), 0, resolution - 1);
            var seedIndex = seedX + seedY * resolution;
            if (!uvCoverageMask[seedIndex])
            {
                return;
            }

            var queue = new Queue<int>();
            queue.Enqueue(seedIndex);
            outputMask[seedIndex] = true;

            while (queue.Count > 0)
            {
                var index = queue.Dequeue();
                var x = index % resolution;
                var y = index / resolution;

                TryEnqueueFillPixel(uvCoverageMask, outputMask, queue, x - 1, y);
                TryEnqueueFillPixel(uvCoverageMask, outputMask, queue, x + 1, y);
                TryEnqueueFillPixel(uvCoverageMask, outputMask, queue, x, y - 1);
                TryEnqueueFillPixel(uvCoverageMask, outputMask, queue, x, y + 1);
            }
        }

        private void TryEnqueueFillPixel(bool[] uvCoverageMask, bool[] outputMask, Queue<int> queue, int x, int y)
        {
            if (x < 0 || x >= resolution || y < 0 || y >= resolution)
            {
                return;
            }

            var index = x + y * resolution;
            if (!uvCoverageMask[index] || outputMask[index])
            {
                return;
            }

            outputMask[index] = true;
            queue.Enqueue(index);
        }

        private bool[] GenerateUvCoverageMask(IReadOnlyList<Vector2> triangleUvs)
        {
            var mask = new bool[resolution * resolution];
            if (triangleUvs.Count < 3)
            {
                return mask;
            }

            for (var i = 0; i + 2 < triangleUvs.Count; i += 3)
            {
                RasterizeUvTriangle(mask, triangleUvs[i], triangleUvs[i + 1], triangleUvs[i + 2]);
            }

            return mask;
        }

        private void RasterizeUvTriangle(bool[] mask, Vector2 uv0, Vector2 uv1, Vector2 uv2)
        {
            var minX = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(uv0.x, Mathf.Min(uv1.x, uv2.x)) * resolution), 0, resolution - 1);
            var maxX = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(uv0.x, Mathf.Max(uv1.x, uv2.x)) * resolution), 0, resolution - 1);
            var minY = Mathf.Clamp(Mathf.FloorToInt(Mathf.Min(uv0.y, Mathf.Min(uv1.y, uv2.y)) * resolution), 0, resolution - 1);
            var maxY = Mathf.Clamp(Mathf.CeilToInt(Mathf.Max(uv0.y, Mathf.Max(uv1.y, uv2.y)) * resolution), 0, resolution - 1);

            var area = Edge(uv0, uv1, uv2);
            if (Mathf.Approximately(area, 0f))
            {
                return;
            }

            for (var y = minY; y <= maxY; y++)
            {
                for (var x = minX; x <= maxX; x++)
                {
                    var uv = new Vector2((x + 0.5f) / resolution, (y + 0.5f) / resolution);
                    var w0 = Edge(uv1, uv2, uv);
                    var w1 = Edge(uv2, uv0, uv);
                    var w2 = Edge(uv0, uv1, uv);
                    var inside = area > 0f
                        ? w0 >= 0f && w1 >= 0f && w2 >= 0f
                        : w0 <= 0f && w1 <= 0f && w2 <= 0f;

                    if (inside)
                    {
                        mask[x + y * resolution] = true;
                    }
                }
            }
        }

        private static float Edge(Vector2 a, Vector2 b, Vector2 c)
        {
            return (c.x - a.x) * (b.y - a.y) - (c.y - a.y) * (b.x - a.x);
        }

        private void SavePng(Texture2D texture, string assetPath, bool useDataImporterSettings)
        {
            if (string.IsNullOrWhiteSpace(assetPath))
            {
                throw new ArgumentException(L("保存先が空です。", "Save path is empty."));
            }

            assetPath = assetPath.Replace('\\', '/');
            if (!assetPath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException(L("保存先はAssetsフォルダ内にしてください。", "Save path must be inside the Assets folder."));
            }

            if (!string.Equals(Path.GetExtension(assetPath), ".png", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException(L("保存先の拡張子は.pngにしてください。", "The save path must use the .png extension."));
            }

            var projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            var assetsRootPath = Path.GetFullPath(Application.dataPath).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            var assetsRoot = assetsRootPath + Path.DirectorySeparatorChar;
            var fullPath = Path.GetFullPath(Path.Combine(projectRoot, assetPath));
            if (!fullPath.StartsWith(assetsRoot, StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException(L("保存先はAssetsフォルダの外へ移動できません。", "The save path cannot escape the Assets folder."));
            }

            var relativeAssetPath = fullPath.Substring(assetsRoot.Length).Replace('\\', '/');
            assetPath = "Assets/" + relativeAssetPath;

            var directory = Path.GetDirectoryName(fullPath);
            if (!string.IsNullOrEmpty(directory))
            {
                Directory.CreateDirectory(directory);
            }

            File.WriteAllBytes(fullPath, texture.EncodeToPNG());
            AssetDatabase.ImportAsset(assetPath, ImportAssetOptions.ForceUpdate);

            if (applyImportSettings && useDataImporterSettings)
            {
                ApplyImporterSettings(assetPath);
            }
        }

        private void ApplyImporterSettings(string assetPath)
        {
            if (!(AssetImporter.GetAtPath(assetPath) is TextureImporter importer))
            {
                return;
            }

            importer.textureType = TextureImporterType.Default;
            importer.maxTextureSize = outputResolution;
            importer.sRGBTexture = false;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.mipmapEnabled = generateMipMaps;
            importer.alphaIsTransparency = false;
            importer.wrapMode = TextureWrapMode.Clamp;
            importer.filterMode = FilterMode.Bilinear;
            importer.SaveAndReimport();
        }

        private void SetStatus(string message, MessageType messageType)
        {
            statusMessage = message;
            statusType = messageType;
            Repaint();
        }

        private void DrawStatusMessage()
        {
            EditorGUILayout.HelpBox(statusMessage, statusType);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                if (GUILayout.Button(L("閉じる", "Dismiss"), EditorStyles.miniButton, GUILayout.Width(64f)))
                {
                    statusMessage = string.Empty;
                    GUI.FocusControl(null);
                }
            }
        }

        private void LogUnexpectedExceptionOnce(Exception exception)
        {
            if (exception == null)
            {
                return;
            }

            if (loggedExceptionSignatures == null)
            {
                loggedExceptionSignatures = new HashSet<string>();
            }

            var signature = exception.GetType().FullName + "\n" + exception.Message + "\n" + exception.StackTrace;
            if (loggedExceptionSignatures.Add(signature))
            {
                Debug.LogException(exception, this);
            }
        }

        private static void Swap<T>(ref T left, ref T right)
        {
            var temp = left;
            left = right;
            right = temp;
        }

        private readonly struct TargetUvData
        {
            public TargetUvData(List<Vector2> boundsUvs, List<Vector2> triangleUvs, List<Vector3> triangleNormals, List<Vector3> trianglePositions, List<float> triangleNeckBlendValues)
            {
                BoundsUvs = boundsUvs;
                TriangleUvs = triangleUvs;
                TriangleNormals = triangleNormals;
                TrianglePositions = trianglePositions;
                TriangleNeckBlendValues = triangleNeckBlendValues;
            }

            public List<Vector2> BoundsUvs { get; }
            public List<Vector2> TriangleUvs { get; }
            public List<Vector3> TriangleNormals { get; }
            public List<Vector3> TrianglePositions { get; }
            public List<float> TriangleNeckBlendValues { get; }
        }

        private readonly struct LightFrame
        {
            public LightFrame(Vector3 center, Vector3 right, Vector3 up, Vector3 forward, Vector2 halfExtent, float nearDepth, float farDepth, Vector3 lightPosition, float lightRadius)
            {
                Center = center;
                Right = right;
                Up = up;
                Forward = forward;
                HalfExtent = halfExtent;
                NearDepth = nearDepth;
                FarDepth = farDepth;
                LightPosition = lightPosition;
                LightRadius = lightRadius;
            }

            public Vector3 Center { get; }
            public Vector3 Right { get; }
            public Vector3 Up { get; }
            public Vector3 Forward { get; }
            public Vector2 HalfExtent { get; }
            public float NearDepth { get; }
            public float FarDepth { get; }
            public Vector3 LightPosition { get; }
            public float LightRadius { get; }
        }

        private readonly struct BaseBakeData
        {
            public BaseBakeData(bool[] uvCoverageMask, bool[] lightMapIslandMask, Rect lightMapUvBounds, byte[][] multiAnglePreviewMaps, bool isMultiAngleGradient, byte[] leftLightMap, byte[] rightLightMap, byte[] neckBlendMap)
            {
                UvCoverageMask = uvCoverageMask;
                LightMapIslandMask = lightMapIslandMask;
                LightMapUvBounds = lightMapUvBounds;
                MultiAnglePreviewMaps = multiAnglePreviewMaps;
                IsMultiAngleGradient = isMultiAngleGradient;
                LeftLightMap = leftLightMap;
                RightLightMap = rightLightMap;
                NeckBlendMap = neckBlendMap;
            }

            public bool IsValid => UvCoverageMask != null && LightMapIslandMask != null && LeftLightMap != null && RightLightMap != null && NeckBlendMap != null;
            public bool[] UvCoverageMask { get; }
            public bool[] LightMapIslandMask { get; }
            public Rect LightMapUvBounds { get; }
            public byte[][] MultiAnglePreviewMaps { get; }
            public bool IsMultiAngleGradient { get; }
            public byte[] LeftLightMap { get; }
            public byte[] RightLightMap { get; }
            public byte[] NeckBlendMap { get; }
        }

        private readonly struct BakeResult
        {
            public BakeResult(Texture2D lightTexture, Texture2D debugPreviewTexture, Texture2D redChannelPreviewTexture, Texture2D greenChannelPreviewTexture, Texture2D blueChannelPreviewTexture, Texture2D multiAngleGridPreviewTexture)
            {
                LightTexture = lightTexture;
                DebugPreviewTexture = debugPreviewTexture;
                RedChannelPreviewTexture = redChannelPreviewTexture;
                GreenChannelPreviewTexture = greenChannelPreviewTexture;
                BlueChannelPreviewTexture = blueChannelPreviewTexture;
                MultiAngleGridPreviewTexture = multiAngleGridPreviewTexture;
            }

            public Texture2D LightTexture { get; }
            public Texture2D DebugPreviewTexture { get; }
            public Texture2D RedChannelPreviewTexture { get; }
            public Texture2D GreenChannelPreviewTexture { get; }
            public Texture2D BlueChannelPreviewTexture { get; }
            public Texture2D MultiAngleGridPreviewTexture { get; }
        }
    }
}
