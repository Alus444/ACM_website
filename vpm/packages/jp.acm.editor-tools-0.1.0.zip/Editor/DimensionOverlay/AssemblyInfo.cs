using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ACM.DimensionOverlay.Editor.Tests")]
