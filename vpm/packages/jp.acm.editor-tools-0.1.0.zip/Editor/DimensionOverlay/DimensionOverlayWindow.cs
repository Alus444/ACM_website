using UnityEditor;
using UnityEngine;

namespace ACM.DimensionOverlay
{
    public sealed class DimensionOverlayWindow : EditorWindow
    {
        private const string WindowTitle = "Dimension Overlay";

        [SerializeField] private bool jp = true;
        [SerializeField] private bool measurementFoldout = true;
        [SerializeField] private bool displayFoldout = true;
        [SerializeField] private bool selectionFoldout = true;

        [MenuItem("Tools/ACM/Dimension Overlay")]
        public static DimensionOverlayWindow OpenWindow()
        {
            var window = GetWindow<DimensionOverlayWindow>();
            window.titleContent = new GUIContent(WindowTitle);
            window.minSize = new Vector2(390f, 430f);
            window.Show();
            return window;
        }

        private void OnEnable()
        {
            titleContent = new GUIContent(WindowTitle);
            Selection.selectionChanged -= OnSelectionChanged;
            Selection.selectionChanged += OnSelectionChanged;
            EditorApplication.update -= RepaintWhileVisible;
            EditorApplication.update += RepaintWhileVisible;
        }

        private void OnDisable()
        {
            Selection.selectionChanged -= OnSelectionChanged;
            EditorApplication.update -= RepaintWhileVisible;
        }

        private void OnGUI()
        {
            DrawLanguageToolbar();
            DrawHeader();
            EditorGUILayout.Space(8);

            EditorGUI.BeginChangeCheck();
            DrawGlobalSection();
            DrawMeasurementSection();
            DrawDisplaySection();
            if (EditorGUI.EndChangeCheck())
                DimensionOverlayDrawer.RepaintAllViews();

            DrawSelectionSection();
            EditorGUILayout.Space(8);
            DrawResetButton();
        }

        private void DrawLanguageToolbar()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                jp = GUILayout.Toolbar(jp ? 0 : 1, new[] { "JP", "EN" }, GUILayout.Width(74)) == 0;
            }
        }

        private void DrawHeader()
        {
            EditorGUILayout.LabelField(T("寸法オーバーレイ", "Dimension Overlay"), EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                T("Hierarchyで選択したオブジェクトのX・Y・Z寸法をSceneビューへ表示します。",
                  "Displays the X, Y, and Z dimensions of the selected Hierarchy object in the Scene view."),
                MessageType.None);
        }

        private void DrawGlobalSection()
        {
            EditorGUILayout.LabelField(T("表示", "Visibility"), EditorStyles.boldLabel);
            using (new EditorGUILayout.VerticalScope(GUI.skin.box))
            {
                DimensionOverlayPreferences.Enabled = EditorGUILayout.ToggleLeft(
                    C("オーバーレイを表示", "Show Overlay",
                      "選択オブジェクトの寸法表示を有効にします。",
                      "Enables dimensions for the selected object."),
                    DimensionOverlayPreferences.Enabled);

                using (new EditorGUI.DisabledScope(!DimensionOverlayPreferences.Enabled))
                {
                    DimensionOverlayPreferences.ShowInGameView = EditorGUILayout.ToggleLeft(
                        C("Gameビューにも表示", "Show in Game View",
                          "GameビューのGizmosが有効な場合だけ表示します。ビルドには含まれません。",
                          "Displays when Game view Gizmos are enabled. It is never included in builds."),
                        DimensionOverlayPreferences.ShowInGameView);
                }

                if (DimensionOverlayPreferences.ShowInGameView)
                {
                    EditorGUILayout.Space(4);
                    EditorGUILayout.HelpBox(
                        T("Gameビュー上部のGizmosをONにしてください。Editor専用表示のため、実機・ビルドには入りません。",
                          "Enable Gizmos in the Game view toolbar. This is Editor-only and is never included in a player build."),
                        MessageType.Info);
                }
            }
        }

        private void DrawMeasurementSection()
        {
            EditorGUILayout.Space(6);
            measurementFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(
                measurementFoldout,
                T("計測", "Measurement"));
            if (measurementFoldout)
            {
                using (new EditorGUILayout.VerticalScope(GUI.skin.box))
                using (new EditorGUI.DisabledScope(!DimensionOverlayPreferences.Enabled))
                {
                    DimensionOverlayPreferences.BoundsSource = (DimensionBoundsSource)EditorGUILayout.Popup(
                        C("計測対象", "Bounds Source",
                          "見た目、Collider、または選択オブジェクト自身のMeshから寸法を計算します。",
                          "Measures visual bounds, colliders, or only the Mesh on the selected object."),
                        (int)DimensionOverlayPreferences.BoundsSource,
                        BoundsSourceLabels());

                    DimensionOverlayPreferences.Space = (DimensionSpace)EditorGUILayout.Popup(
                        C("寸法基準", "Dimension Space",
                          "ローカルは選択物の軸、ワールドはSceneの軸に沿った占有寸法です。",
                          "Local follows the selected object's axes; World measures its axis-aligned footprint in the Scene."),
                        (int)DimensionOverlayPreferences.Space,
                        SpaceLabels());

                    DimensionOverlayPreferences.IncludeInactive = EditorGUILayout.ToggleLeft(
                        C("非アクティブな子を含む", "Include Inactive Children",
                          "非アクティブな子オブジェクトも集計へ含めます。",
                          "Includes inactive child objects in the measurement."),
                        DimensionOverlayPreferences.IncludeInactive);
                }
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        private void DrawDisplaySection()
        {
            EditorGUILayout.Space(6);
            displayFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(
                displayFoldout,
                T("表記", "Display"));
            if (displayFoldout)
            {
                using (new EditorGUILayout.VerticalScope(GUI.skin.box))
                using (new EditorGUI.DisabledScope(!DimensionOverlayPreferences.Enabled))
                {
                    DimensionOverlayPreferences.Unit = (DimensionUnit)EditorGUILayout.Popup(
                        C("単位", "Unit",
                          "自動では対象サイズに合わせ、m・cm・mmを統一して選びます。",
                          "Auto chooses one shared unit from m, cm, or mm based on the measured size."),
                        (int)DimensionOverlayPreferences.Unit,
                        UnitLabels());

                    DimensionOverlayPreferences.ShowBounds = EditorGUILayout.ToggleLeft(
                        C("Bounds枠を表示", "Show Bounds Box",
                          "寸法の基準になったBoundsを黄色い枠で表示します。",
                          "Shows the measured bounds as a yellow wire box."),
                        DimensionOverlayPreferences.ShowBounds);
                }
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        private void DrawSelectionSection()
        {
            EditorGUILayout.Space(6);
            selectionFoldout = EditorGUILayout.BeginFoldoutHeaderGroup(
                selectionFoldout,
                T("現在の選択", "Current Selection"));
            if (selectionFoldout)
            {
                using (new EditorGUILayout.VerticalScope(GUI.skin.box))
                {
                    GameObject target = Selection.activeGameObject;
                    if (target == null)
                    {
                        EditorGUILayout.HelpBox(
                            T("HierarchyでGameObjectを選択してください。", "Select a GameObject in the Hierarchy."),
                            MessageType.Info);
                    }
                    else if (DimensionOverlayBoundsUtility.TryMeasure(
                        target,
                        DimensionOverlayPreferences.BoundsSource,
                        DimensionOverlayPreferences.Space,
                        DimensionOverlayPreferences.IncludeInactive,
                        out DimensionMeasurement measurement))
                    {
                        DimensionUnit unit = DimensionOverlayFormatter.ResolveUnit(
                            measurement.WorldSize,
                            DimensionOverlayPreferences.Unit);
                        EditorGUILayout.LabelField(target.name, EditorStyles.boldLabel);
                        DrawDimensionValue("X", measurement.WorldSize.x, unit);
                        DrawDimensionValue("Y", measurement.WorldSize.y, unit);
                        DrawDimensionValue("Z", measurement.WorldSize.z, unit);
                    }
                    else
                    {
                        EditorGUILayout.HelpBox(
                            T("選択した計測対象が見つからないか、TransformのScaleに0が含まれています。",
                              "No supported measurement source was found, or a Transform scale contains zero."),
                            MessageType.Warning);
                    }
                }
            }
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        private void DrawResetButton()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                if (GUILayout.Button(T("初期設定に戻す", "Reset to Defaults"), GUILayout.Width(130)))
                {
                    DimensionOverlayPreferences.ResetToDefaults();
                    DimensionOverlayDrawer.RepaintAllViews();
                }
            }
        }

        private void DrawDimensionValue(string axis, float value, DimensionUnit unit)
        {
            EditorGUILayout.LabelField(axis, DimensionOverlayFormatter.FormatLength(value, unit));
        }

        private string[] BoundsSourceLabels()
        {
            return jp
                ? new[] { "Renderer（子を含む）", "Collider（子を含む）", "選択物のMeshのみ" }
                : new[] { "Renderers (Including Children)", "Colliders (Including Children)", "Selected Mesh Only" };
        }

        private string[] SpaceLabels()
        {
            return jp
                ? new[] { "ローカル寸法", "ワールド占有寸法" }
                : new[] { "Local Dimensions", "World Footprint" };
        }

        private string[] UnitLabels()
        {
            return jp
                ? new[] { "自動", "メートル (m)", "センチメートル (cm)", "ミリメートル (mm)" }
                : new[] { "Auto", "Meters (m)", "Centimeters (cm)", "Millimeters (mm)" };
        }

        private void OnSelectionChanged()
        {
            Repaint();
        }

        private void RepaintWhileVisible()
        {
            if (focusedWindow == this)
                Repaint();
        }

        private string T(string ja, string en)
        {
            return jp ? ja : en;
        }

        private GUIContent C(string ja, string en, string tipJa, string tipEn)
        {
            return new GUIContent(T(ja, en), T(tipJa, tipEn));
        }

    }
}
