using UnityEditor;
using UnityEngine;

namespace ACM.DimensionOverlay
{
    [InitializeOnLoad]
    internal static class DimensionOverlayDrawer
    {
        private static readonly Color BoxColor = new Color(1f, 0.84f, 0.24f, 0.9f);
        private static readonly Color[] AxisColors =
        {
            new Color(1f, 0.34f, 0.34f, 1f),
            new Color(0.35f, 0.85f, 0.42f, 1f),
            new Color(0.32f, 0.62f, 1f, 1f)
        };

        private static readonly string[] AxisNames = { "X", "Y", "Z" };
        private static readonly int[,] BoxEdges =
        {
            { 0, 1 }, { 0, 2 }, { 0, 4 },
            { 1, 3 }, { 1, 5 }, { 2, 3 },
            { 2, 6 }, { 3, 7 }, { 4, 5 },
            { 4, 6 }, { 5, 7 }, { 6, 7 }
        };

        private static GUIStyle[] labelStyles;

        static DimensionOverlayDrawer()
        {
            SceneView.duringSceneGui -= DrawSceneView;
            SceneView.duringSceneGui += DrawSceneView;
            Selection.selectionChanged -= RepaintAllViews;
            Selection.selectionChanged += RepaintAllViews;
            EditorApplication.hierarchyChanged -= RepaintAllViews;
            EditorApplication.hierarchyChanged += RepaintAllViews;
        }

        internal static void RepaintAllViews()
        {
            SceneView.RepaintAll();
            foreach (EditorWindow window in Resources.FindObjectsOfTypeAll<EditorWindow>())
            {
                if (window != null && window.GetType().Name == "GameView")
                    window.Repaint();
            }
        }

        private static void DrawSceneView(SceneView sceneView)
        {
            if (!DimensionOverlayPreferences.Enabled || Event.current.type != EventType.Repaint)
                return;

            GameObject target = Selection.activeGameObject;
            if (!CanDrawTarget(target))
                return;

            if (!TryGetCurrentMeasurement(target, out DimensionMeasurement measurement))
                return;

            DrawMeasurement(measurement, sceneView.camera, false);
        }

        [DrawGizmo(GizmoType.Selected | GizmoType.Active)]
        private static void DrawGameViewGizmo(GameObject target, GizmoType gizmoType)
        {
            if (!DimensionOverlayPreferences.Enabled || !DimensionOverlayPreferences.ShowInGameView)
                return;
            if (target != Selection.activeGameObject || !CanDrawTarget(target))
                return;

            Camera currentCamera = Camera.current;
            if (currentCamera == null || currentCamera.cameraType != CameraType.Game)
                return;

            if (!TryGetCurrentMeasurement(target, out DimensionMeasurement measurement))
                return;

            DrawMeasurement(measurement, currentCamera, true);
        }

        private static bool CanDrawTarget(GameObject target)
        {
            return target != null && !EditorUtility.IsPersistent(target) && target.scene.IsValid();
        }

        private static bool TryGetCurrentMeasurement(GameObject target, out DimensionMeasurement measurement)
        {
            return DimensionOverlayBoundsUtility.TryMeasure(
                target,
                DimensionOverlayPreferences.BoundsSource,
                DimensionOverlayPreferences.Space,
                DimensionOverlayPreferences.IncludeInactive,
                out measurement);
        }

        private static void DrawMeasurement(DimensionMeasurement measurement, Camera camera, bool useGizmos)
        {
            EnsureLabelStyles();

            Vector3[] corners = GetWorldCorners(measurement);
            if (DimensionOverlayPreferences.ShowBounds)
                DrawWireBounds(corners, useGizmos);

            Matrix4x4 matrix = measurement.LocalToWorld;
            Vector3 center = measurement.Bounds.center;
            Vector3 extents = measurement.Bounds.extents;
            Vector3 cameraLocal = matrix.inverse.MultiplyPoint3x4(camera.transform.position);
            int signX = cameraLocal.x >= center.x ? 1 : -1;
            int signY = cameraLocal.y >= center.y ? 1 : -1;
            int signZ = cameraLocal.z >= center.z ? 1 : -1;

            DimensionUnit unit = DimensionOverlayFormatter.ResolveUnit(
                measurement.WorldSize,
                DimensionOverlayPreferences.Unit);

            DrawAxisDimension(0, signX, signY, signZ, measurement, unit, useGizmos);
            DrawAxisDimension(1, signX, signY, signZ, measurement, unit, useGizmos);
            DrawAxisDimension(2, signX, signY, signZ, measurement, unit, useGizmos);
        }

        private static void DrawAxisDimension(
            int axis,
            int signX,
            int signY,
            int signZ,
            DimensionMeasurement measurement,
            DimensionUnit unit,
            bool useGizmos)
        {
            Vector3 center = measurement.Bounds.center;
            Vector3 extents = measurement.Bounds.extents;
            Vector3 signs = new Vector3(signX, signY, signZ);
            Vector3 baseStartLocal = center + Vector3.Scale(extents, signs);
            Vector3 baseEndLocal = baseStartLocal;
            baseStartLocal[axis] = center[axis] - extents[axis];
            baseEndLocal[axis] = center[axis] + extents[axis];

            Matrix4x4 matrix = measurement.LocalToWorld;
            Vector3 baseStart = matrix.MultiplyPoint3x4(baseStartLocal);
            Vector3 baseEnd = matrix.MultiplyPoint3x4(baseEndLocal);
            Vector3 worldCenter = measurement.WorldCenter;

            Vector3 firstOffsetAxis = GetWorldAxis(matrix, (axis + 1) % 3) * signs[(axis + 1) % 3];
            Vector3 secondOffsetAxis = GetWorldAxis(matrix, (axis + 2) % 3) * signs[(axis + 2) % 3];
            Vector3 outward = (firstOffsetAxis + secondOffsetAxis).normalized;
            if (outward.sqrMagnitude < 0.001f)
                outward = Vector3.up;

            float handleSize = HandleUtility.GetHandleSize(worldCenter);
            float offsetDistance = handleSize * 0.11f;
            float tickLength = handleSize * 0.035f;
            Vector3 offset = outward * offsetDistance;
            Vector3 lineStart = baseStart + offset;
            Vector3 lineEnd = baseEnd + offset;

            Color color = AxisColors[axis];
            DrawLine(baseStart, lineStart + outward * tickLength, color, 1.2f, useGizmos);
            DrawLine(baseEnd, lineEnd + outward * tickLength, color, 1.2f, useGizmos);
            DrawLine(lineStart, lineEnd, color, 3f, useGizmos);
            DrawLine(lineStart - outward * tickLength, lineStart + outward * tickLength, color, 2f, useGizmos);
            DrawLine(lineEnd - outward * tickLength, lineEnd + outward * tickLength, color, 2f, useGizmos);

            string text = AxisNames[axis] + "  " + DimensionOverlayFormatter.FormatLength(measurement.WorldSize[axis], unit);
            Handles.Label((lineStart + lineEnd) * 0.5f + outward * tickLength * 1.5f, text, labelStyles[axis]);
        }

        private static void DrawWireBounds(Vector3[] corners, bool useGizmos)
        {
            for (int i = 0; i < BoxEdges.GetLength(0); i++)
                DrawLine(corners[BoxEdges[i, 0]], corners[BoxEdges[i, 1]], BoxColor, 1.5f, useGizmos);
        }

        private static void DrawLine(Vector3 start, Vector3 end, Color color, float width, bool useGizmos)
        {
            if (useGizmos)
            {
                Gizmos.color = color;
                Gizmos.DrawLine(start, end);
                return;
            }

            Color previousColor = Handles.color;
            Handles.color = color;
            Handles.DrawAAPolyLine(width, start, end);
            Handles.color = previousColor;
        }

        private static Vector3[] GetWorldCorners(DimensionMeasurement measurement)
        {
            Vector3 center = measurement.Bounds.center;
            Vector3 extents = measurement.Bounds.extents;
            var corners = new Vector3[8];
            int index = 0;
            for (int x = -1; x <= 1; x += 2)
            {
                for (int y = -1; y <= 1; y += 2)
                {
                    for (int z = -1; z <= 1; z += 2)
                    {
                        Vector3 local = center + Vector3.Scale(extents, new Vector3(x, y, z));
                        corners[index++] = measurement.LocalToWorld.MultiplyPoint3x4(local);
                    }
                }
            }
            return corners;
        }

        private static Vector3 GetWorldAxis(Matrix4x4 matrix, int axis)
        {
            Vector3 direction = matrix.MultiplyVector(axis == 0 ? Vector3.right : axis == 1 ? Vector3.up : Vector3.forward);
            return direction.sqrMagnitude > 0.000001f ? direction.normalized : Vector3.zero;
        }

        private static void EnsureLabelStyles()
        {
            if (labelStyles != null)
                return;

            labelStyles = new GUIStyle[3];
            for (int i = 0; i < labelStyles.Length; i++)
            {
                labelStyles[i] = new GUIStyle(EditorStyles.helpBox)
                {
                    alignment = TextAnchor.MiddleCenter,
                    fontStyle = FontStyle.Bold,
                    fontSize = 11,
                    padding = new RectOffset(5, 5, 2, 2)
                };
                labelStyles[i].normal.textColor = AxisColors[i];
            }
        }
    }
}
