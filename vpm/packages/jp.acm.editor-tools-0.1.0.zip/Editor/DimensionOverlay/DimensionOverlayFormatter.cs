using System.Globalization;
using UnityEngine;

namespace ACM.DimensionOverlay
{
    internal static class DimensionOverlayFormatter
    {
        internal static DimensionUnit ResolveUnit(Vector3 worldSize, DimensionUnit requestedUnit)
        {
            if (requestedUnit != DimensionUnit.Auto)
                return requestedUnit;

            float largest = Mathf.Max(Mathf.Abs(worldSize.x), Mathf.Abs(worldSize.y), Mathf.Abs(worldSize.z));
            if (largest >= 1f)
                return DimensionUnit.Meters;
            if (largest >= 0.01f)
                return DimensionUnit.Centimeters;
            return DimensionUnit.Millimeters;
        }

        internal static string FormatLength(float meters, DimensionUnit unit)
        {
            switch (unit)
            {
                case DimensionUnit.Centimeters:
                    return (meters * 100f).ToString("0.##", CultureInfo.InvariantCulture) + " cm";
                case DimensionUnit.Millimeters:
                    return (meters * 1000f).ToString("0.#", CultureInfo.InvariantCulture) + " mm";
                default:
                    return meters.ToString("0.###", CultureInfo.InvariantCulture) + " m";
            }
        }
    }
}
