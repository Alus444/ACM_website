using UnityEngine;

namespace ACM.DimensionOverlay
{
    internal readonly struct DimensionMeasurement
    {
        internal readonly Matrix4x4 LocalToWorld;
        internal readonly Bounds Bounds;
        internal readonly Vector3 WorldSize;

        internal DimensionMeasurement(Matrix4x4 localToWorld, Bounds bounds)
        {
            LocalToWorld = localToWorld;
            Bounds = bounds;
            WorldSize = new Vector3(
                localToWorld.MultiplyVector(Vector3.right * bounds.size.x).magnitude,
                localToWorld.MultiplyVector(Vector3.up * bounds.size.y).magnitude,
                localToWorld.MultiplyVector(Vector3.forward * bounds.size.z).magnitude);
        }

        internal Vector3 WorldCenter => LocalToWorld.MultiplyPoint3x4(Bounds.center);
    }

    internal static class DimensionOverlayBoundsUtility
    {
        private const float SingularMatrixThreshold = 0.0000001f;

        internal static bool TryMeasure(
            GameObject target,
            DimensionBoundsSource source,
            DimensionSpace space,
            bool includeInactive,
            out DimensionMeasurement measurement)
        {
            measurement = default;
            if (target == null)
                return false;

            Matrix4x4 localToWorld = space == DimensionSpace.Local
                ? target.transform.localToWorldMatrix
                : Matrix4x4.identity;

            if (space == DimensionSpace.Local && Mathf.Abs(localToWorld.determinant) < SingularMatrixThreshold)
                return false;

            Matrix4x4 worldToMeasurement = localToWorld.inverse;
            var accumulator = new BoundsAccumulator();

            switch (source)
            {
                case DimensionBoundsSource.Renderers:
                    AddRenderers(target, includeInactive, worldToMeasurement, space, ref accumulator);
                    break;
                case DimensionBoundsSource.Colliders:
                    AddColliders(target, includeInactive, worldToMeasurement, space, ref accumulator);
                    break;
                case DimensionBoundsSource.Mesh:
                    AddSelectedMesh(target, worldToMeasurement, space, ref accumulator);
                    break;
            }

            if (!accumulator.HasBounds)
                return false;

            measurement = new DimensionMeasurement(localToWorld, accumulator.Value);
            return IsFinite(measurement.WorldSize);
        }

        private static void AddRenderers(
            GameObject target,
            bool includeInactive,
            Matrix4x4 worldToMeasurement,
            DimensionSpace space,
            ref BoundsAccumulator accumulator)
        {
            Renderer[] renderers = target.GetComponentsInChildren<Renderer>(includeInactive);
            foreach (Renderer renderer in renderers)
            {
                if (renderer == null)
                    continue;

                if (space == DimensionSpace.World)
                {
                    accumulator.AddBounds(renderer.bounds);
                    continue;
                }

                if (renderer is SkinnedMeshRenderer skinnedMeshRenderer)
                {
                    AddTransformedBounds(
                        skinnedMeshRenderer.localBounds,
                        worldToMeasurement * skinnedMeshRenderer.localToWorldMatrix,
                        ref accumulator);
                    continue;
                }

                if (renderer is MeshRenderer)
                {
                    MeshFilter meshFilter = renderer.GetComponent<MeshFilter>();
                    if (meshFilter != null && meshFilter.sharedMesh != null)
                    {
                        AddTransformedBounds(
                            meshFilter.sharedMesh.bounds,
                            worldToMeasurement * meshFilter.transform.localToWorldMatrix,
                            ref accumulator);
                        continue;
                    }
                }

                AddWorldBounds(renderer.bounds, worldToMeasurement, ref accumulator);
            }
        }

        private static void AddColliders(
            GameObject target,
            bool includeInactive,
            Matrix4x4 worldToMeasurement,
            DimensionSpace space,
            ref BoundsAccumulator accumulator)
        {
            Collider[] colliders = target.GetComponentsInChildren<Collider>(includeInactive);
            foreach (Collider collider in colliders)
            {
                if (collider == null)
                    continue;

                if (space == DimensionSpace.World)
                {
                    accumulator.AddBounds(collider.bounds);
                    continue;
                }

                Matrix4x4 colliderToMeasurement = worldToMeasurement * collider.transform.localToWorldMatrix;
                if (TryGetColliderLocalBounds(collider, out Bounds localBounds))
                    AddTransformedBounds(localBounds, colliderToMeasurement, ref accumulator);
                else
                    AddWorldBounds(collider.bounds, worldToMeasurement, ref accumulator);
            }

            Collider2D[] colliders2D = target.GetComponentsInChildren<Collider2D>(includeInactive);
            foreach (Collider2D collider in colliders2D)
            {
                if (collider == null)
                    continue;

                if (space == DimensionSpace.World)
                    accumulator.AddBounds(collider.bounds);
                else
                    AddWorldBounds(collider.bounds, worldToMeasurement, ref accumulator);
            }
        }

        private static void AddSelectedMesh(
            GameObject target,
            Matrix4x4 worldToMeasurement,
            DimensionSpace space,
            ref BoundsAccumulator accumulator)
        {
            MeshFilter meshFilter = target.GetComponent<MeshFilter>();
            if (meshFilter != null && meshFilter.sharedMesh != null)
            {
                Matrix4x4 meshToMeasurement = worldToMeasurement * meshFilter.transform.localToWorldMatrix;
                AddTransformedBounds(meshFilter.sharedMesh.bounds, meshToMeasurement, ref accumulator);
            }

            SkinnedMeshRenderer skinnedMeshRenderer = target.GetComponent<SkinnedMeshRenderer>();
            if (skinnedMeshRenderer != null)
            {
                Matrix4x4 meshToMeasurement = worldToMeasurement * skinnedMeshRenderer.localToWorldMatrix;
                AddTransformedBounds(skinnedMeshRenderer.localBounds, meshToMeasurement, ref accumulator);
            }

            if (space == DimensionSpace.World && accumulator.HasBounds)
                return;
        }

        private static bool TryGetColliderLocalBounds(Collider collider, out Bounds bounds)
        {
            if (collider is BoxCollider boxCollider)
            {
                bounds = new Bounds(boxCollider.center, boxCollider.size);
                return true;
            }

            if (collider is SphereCollider sphereCollider)
            {
                float diameter = sphereCollider.radius * 2f;
                bounds = new Bounds(sphereCollider.center, Vector3.one * diameter);
                return true;
            }

            if (collider is CapsuleCollider capsuleCollider)
            {
                float diameter = capsuleCollider.radius * 2f;
                Vector3 size = Vector3.one * diameter;
                size[capsuleCollider.direction] = Mathf.Max(capsuleCollider.height, diameter);
                bounds = new Bounds(capsuleCollider.center, size);
                return true;
            }

            if (collider is MeshCollider meshCollider && meshCollider.sharedMesh != null)
            {
                bounds = meshCollider.sharedMesh.bounds;
                return true;
            }

            bounds = default;
            return false;
        }

        private static void AddWorldBounds(
            Bounds worldBounds,
            Matrix4x4 worldToMeasurement,
            ref BoundsAccumulator accumulator)
        {
            AddTransformedBounds(worldBounds, worldToMeasurement, ref accumulator);
        }

        private static void AddTransformedBounds(
            Bounds sourceBounds,
            Matrix4x4 sourceToMeasurement,
            ref BoundsAccumulator accumulator)
        {
            Vector3 center = sourceBounds.center;
            Vector3 extents = sourceBounds.extents;

            for (int x = -1; x <= 1; x += 2)
            {
                for (int y = -1; y <= 1; y += 2)
                {
                    for (int z = -1; z <= 1; z += 2)
                    {
                        Vector3 point = center + Vector3.Scale(extents, new Vector3(x, y, z));
                        accumulator.AddPoint(sourceToMeasurement.MultiplyPoint3x4(point));
                    }
                }
            }
        }

        private static bool IsFinite(Vector3 value)
        {
            return IsFinite(value.x) && IsFinite(value.y) && IsFinite(value.z);
        }

        private static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        private struct BoundsAccumulator
        {
            private Bounds bounds;

            internal bool HasBounds { get; private set; }
            internal Bounds Value => bounds;

            internal void AddBounds(Bounds value)
            {
                if (!HasBounds)
                {
                    bounds = value;
                    HasBounds = true;
                    return;
                }

                bounds.Encapsulate(value);
            }

            internal void AddPoint(Vector3 point)
            {
                if (!HasBounds)
                {
                    bounds = new Bounds(point, Vector3.zero);
                    HasBounds = true;
                    return;
                }

                bounds.Encapsulate(point);
            }
        }
    }
}
