using UnityEditor;

namespace ACM.DimensionOverlay
{
    internal enum DimensionBoundsSource
    {
        Renderers,
        Colliders,
        Mesh
    }

    internal enum DimensionSpace
    {
        Local,
        World
    }

    internal enum DimensionUnit
    {
        Auto,
        Meters,
        Centimeters,
        Millimeters
    }

    internal static class DimensionOverlayPreferences
    {
        private const string KeyPrefix = "ACM.DimensionOverlay.";

        internal static bool Enabled
        {
            get => EditorPrefs.GetBool(KeyPrefix + "Enabled", true);
            set => EditorPrefs.SetBool(KeyPrefix + "Enabled", value);
        }

        internal static bool ShowInGameView
        {
            get => EditorPrefs.GetBool(KeyPrefix + "ShowInGameView", false);
            set => EditorPrefs.SetBool(KeyPrefix + "ShowInGameView", value);
        }

        internal static DimensionBoundsSource BoundsSource
        {
            get => (DimensionBoundsSource)EditorPrefs.GetInt(KeyPrefix + "BoundsSource", (int)DimensionBoundsSource.Renderers);
            set => EditorPrefs.SetInt(KeyPrefix + "BoundsSource", (int)value);
        }

        internal static DimensionSpace Space
        {
            get => (DimensionSpace)EditorPrefs.GetInt(KeyPrefix + "Space", (int)DimensionSpace.Local);
            set => EditorPrefs.SetInt(KeyPrefix + "Space", (int)value);
        }

        internal static DimensionUnit Unit
        {
            get => (DimensionUnit)EditorPrefs.GetInt(KeyPrefix + "Unit", (int)DimensionUnit.Auto);
            set => EditorPrefs.SetInt(KeyPrefix + "Unit", (int)value);
        }

        internal static bool IncludeInactive
        {
            get => EditorPrefs.GetBool(KeyPrefix + "IncludeInactive", true);
            set => EditorPrefs.SetBool(KeyPrefix + "IncludeInactive", value);
        }

        internal static bool ShowBounds
        {
            get => EditorPrefs.GetBool(KeyPrefix + "ShowBounds", true);
            set => EditorPrefs.SetBool(KeyPrefix + "ShowBounds", value);
        }

        internal static void ResetToDefaults()
        {
            Enabled = true;
            ShowInGameView = false;
            BoundsSource = DimensionBoundsSource.Renderers;
            Space = DimensionSpace.Local;
            Unit = DimensionUnit.Auto;
            IncludeInactive = true;
            ShowBounds = true;
        }
    }
}
