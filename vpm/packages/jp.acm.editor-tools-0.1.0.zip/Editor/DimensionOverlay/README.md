# ACM Dimension Overlay

Hierarchyで選択したGameObjectの寸法を、Sceneビュー内の補助線と数値ラベルで確認するEditor専用ツールです。

## 開き方

`Tools > ACM > Dimension Overlay`

## 計測対象

- `Renderer（子を含む）`: 選択物以下のMeshRenderer、SkinnedMeshRenderer、その他Rendererを集計します。
- `Collider（子を含む）`: 選択物以下の3D/2D Colliderを集計します。
- `選択物のMeshのみ`: 選択したGameObject自身のMeshFilterまたはSkinnedMeshRendererだけを計測します。

## 寸法基準

- `ローカル寸法`: 選択物のローカルX/Y/Z軸に沿って計測します。回転しても物体本来の向きを維持します。
- `ワールド占有寸法`: ワールドX/Y/Z軸に沿ったBoundsを計測します。回転後にScene内で占有する幅を確認できます。

## Gameビュー

`Gameビューにも表示`を有効にしたうえで、Gameビュー上部の`Gizmos`をONにしてください。この表示はEditor専用コードだけで構成され、Playerビルドには含まれません。

## Notes

- 単位の`自動`は、三軸で共通の`m`、`cm`、`mm`を対象サイズから選択します。
- SkinnedMeshRendererは`localBounds`を使用するため、アニメーション中の見た目と完全には一致しない場合があります。
- Particle、TrailなどMesh以外のRendererはUnityのワールドBoundsをローカルへ戻して集計するため、回転時に余白を含む場合があります。
- 選択物または親階層のScaleに0が含まれる場合、ローカル寸法は表示されません。
