using UnityEditor;
using UnityEngine;
using System;
using System.Collections.Generic;
using System.Linq;

public sealed class CleanupHiddenObjectsWindow : EditorWindow
{
    [Serializable]
    private sealed class SuspectItem
    {
        public UnityEngine.Object obj;
        public GameObject go;

        public bool checkedForDelete;

        public string sceneName;
        public string hierarchyPath;

        public HideFlags hideFlags;

        public bool keyword;
        public bool hiddenByHideFlags;
        public bool notEditable;
        public bool pickingDisabled;
        public bool hiddenBySceneVisibility;

        public string kind;
        public string reason;
    }

    [SerializeField] private List<string> keywords = new List<string> { "Proxy", "Preview", "Reference" };

    [SerializeField] private bool onlySceneObjects = true;
    [SerializeField] private bool includeComponents = true;

    [SerializeField] private bool onlyHidden = false;
    [SerializeField] private bool onlyKeyword = false;
    [SerializeField] private bool includeDontSave = true;

    [SerializeField] private string nameFilter = "";

    [SerializeField] private bool groupByScene = true;
    [SerializeField] private bool showHierarchyPath = true;

    [SerializeField] private Vector2 scroll;

    private readonly List<SuspectItem> suspects = new List<SuspectItem>();
    private Dictionary<string, List<SuspectItem>> grouped = new Dictionary<string, List<SuspectItem>>(StringComparer.Ordinal);

    private GUIStyle objNameStyle;
    private GUIStyle objPathStyle;

    private float RowHeight
    {
        get
        {
            float lh = EditorGUIUtility.singleLineHeight;
            float vpad = 8f;
            return showHierarchyPath ? (lh * 2f + vpad) : (lh + vpad);
        }
    }

    private sealed class ColumnLayout
    {
        public Rect cb;
        public Rect obj;
        public Rect scene;
        public Rect hideFlags;
        public Rect reason;
        public Rect actions;

        public Rect ping;
        public Rect select;
        public Rect del;
    }

    private const float PadX = 6f;
    private const float PadY = 2f;
    private const float Gap = 4f;

    private const float CbW = 18f;

    private const float SceneW = 140f;
    private const float HideFlagsW = 170f;

    private const float MinObjW = 160f;
    private const float MinReasonW = 160f;

    private const float PingW = 50f;
    private const float SelectW = 50f;
    private const float DeleteW = 52f;

    private float ActionsTotal => PingW + Gap + SelectW + Gap + DeleteW;

    [MenuItem("Tools/ACM/Cleanup/HiddenObjectsCleaner")]
    public static void Open()
    {
        var w = GetWindow<CleanupHiddenObjectsWindow>("Hidden Objects Cleaner");
        w.minSize = new Vector2(820, 420);
        w.RefreshList();
        w.Show();
    }

    private void OnEnable()
    {
        if (keywords == null || keywords.Count == 0)
            keywords = new List<string> { "Proxy", "Preview", "Reference" };

        EnsureStyles();

        if (suspects.Count == 0)
            RefreshList();
    }

    private void EnsureStyles()
    {
        if (objNameStyle != null && objPathStyle != null) return;

        objNameStyle = new GUIStyle(EditorStyles.label)
        {
            wordWrap = false,
            clipping = TextClipping.Clip
        };

        int baseSize = EditorStyles.label.fontSize <= 0 ? 12 : EditorStyles.label.fontSize;
        objPathStyle = new GUIStyle(EditorStyles.label)
        {
            wordWrap = false,
            clipping = TextClipping.Clip,
            fontSize = Mathf.Max(9, baseSize - 2)
        };
    }

    private void OnGUI()
    {
        EnsureStyles();

        DrawToolbar();
        EditorGUILayout.Space(6);
        DrawKeywordEditor();
        EditorGUILayout.Space(6);
        DrawFilters();
        EditorGUILayout.Space(8);
        DrawListHeader();
        DrawList();
        EditorGUILayout.Space(8);
        DrawFooter();
    }

    private void DrawToolbar()
    {
        using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
        {
            if (GUILayout.Button("Refresh", EditorStyles.toolbarButton, GUILayout.Width(70)))
                RefreshList();

            if (GUILayout.Button("Clear Checks", EditorStyles.toolbarButton, GUILayout.Width(90)))
                SetAllChecks(false);

            GUILayout.Space(8);

            if (GUILayout.Button("Check All (Shown)", EditorStyles.toolbarButton, GUILayout.Width(120)))
                SetAllChecks(true);

            GUILayout.FlexibleSpace();

            using (new EditorGUI.DisabledScope(!HasAnyChecked()))
            {
                if (GUILayout.Button("Delete Checked", EditorStyles.toolbarButton, GUILayout.Width(110)))
                    DeleteCheckedWithConfirm();
            }
        }
    }

    private void DrawKeywordEditor()
    {
        using (new EditorGUILayout.VerticalScope("box"))
        {
            EditorGUILayout.LabelField("Keywords", EditorStyles.boldLabel);

            int removeAt = -1;
            for (int i = 0; i < keywords.Count; i++)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    keywords[i] = EditorGUILayout.TextField(keywords[i]);
                    if (GUILayout.Button("×", GUILayout.Width(24)))
                        removeAt = i;
                }
            }
            if (removeAt >= 0 && removeAt < keywords.Count)
                keywords.RemoveAt(removeAt);

            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button("Add Keyword", GUILayout.Width(120)))
                    keywords.Add("");

                if (GUILayout.Button("Trim Empty", GUILayout.Width(120)))
                    keywords = keywords.Where(k => !string.IsNullOrWhiteSpace(k))
                                       .Select(k => k.Trim())
                                       .Distinct(StringComparer.OrdinalIgnoreCase)
                                       .ToList();

                GUILayout.FlexibleSpace();
                EditorGUILayout.LabelField($"Active: {keywords.Count}", GUILayout.Width(90));
            }
        }
    }

    private void DrawFilters()
    {
        using (new EditorGUILayout.VerticalScope("box"))
        {
            EditorGUILayout.LabelField("Filters", EditorStyles.boldLabel);

            using (new EditorGUILayout.HorizontalScope())
            {
                onlySceneObjects = EditorGUILayout.ToggleLeft("Scene objects only", onlySceneObjects, GUILayout.Width(160));
                includeComponents = EditorGUILayout.ToggleLeft("Include Components", includeComponents, GUILayout.Width(160));
                onlyHidden = EditorGUILayout.ToggleLeft("Hide/NotEditable/PickOff", onlyHidden, GUILayout.Width(190));
                onlyKeyword = EditorGUILayout.ToggleLeft("Keyword only", onlyKeyword, GUILayout.Width(130));
                includeDontSave = EditorGUILayout.ToggleLeft("Include DontSave", includeDontSave, GUILayout.Width(150));
                groupByScene = EditorGUILayout.ToggleLeft("Group by scene", groupByScene, GUILayout.Width(150));
                showHierarchyPath = EditorGUILayout.ToggleLeft("Show path", showHierarchyPath, GUILayout.Width(110));
                GUILayout.FlexibleSpace();
            }

            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField("Name contains", GUILayout.Width(100));
                nameFilter = EditorGUILayout.TextField(nameFilter);
                if (GUILayout.Button("Apply", GUILayout.Width(70)))
                    ApplyGrouping();
            }

            EditorGUILayout.LabelField($"Shown: {GetShownCount()} / Cached: {suspects.Count}");
        }
    }

    private static string EllipsizeLeft(string s, GUIStyle style, float maxWidth)
    {
        if (string.IsNullOrEmpty(s)) return "";
        if (maxWidth <= 0f) return "";

        var full = new GUIContent(s);
        if (style.CalcSize(full).x <= maxWidth) return s;

        const string ell = "…";

        int lo = 0;
        int hi = s.Length - 1;
        int best = s.Length - 1;

        while (lo <= hi)
        {
            int mid = (lo + hi) >> 1;
            string cand = ell + s.Substring(mid);
            if (style.CalcSize(new GUIContent(cand)).x <= maxWidth)
            {
                best = mid;
                hi = mid - 1;
            }
            else
            {
                lo = mid + 1;
            }
        }

        return ell + s.Substring(best);
    }

    private ColumnLayout CalcColumns(Rect inner)
    {
        var lay = new ColumnLayout();

        float x = inner.x;

        float minTotal =
            CbW + Gap +
            MinObjW +
            SceneW +
            HideFlagsW +
            MinReasonW +
            ActionsTotal;

        float available = inner.width;

        float objW = MinObjW;
        float reasonW = MinReasonW;

        if (available > minTotal)
        {
            float extra = available - minTotal;

            float objRatio = showHierarchyPath ? 0.80f : 0.65f;

            float objExtra = extra * objRatio;
            float reasonExtra = extra - objExtra;
            objW += objExtra;
            reasonW += reasonExtra;
        }
        else if (available < minTotal)
        {
            float lack = minTotal - available;

            float canReduceReason = Mathf.Max(0f, reasonW - 80f);
            float r = Mathf.Min(lack, canReduceReason);
            reasonW -= r;
            lack -= r;

            float canReduceObj = Mathf.Max(0f, objW - 120f);
            float o = Mathf.Min(lack, canReduceObj);
            objW -= o;
            lack -= o;
        }

        lay.cb = new Rect(x, inner.y, CbW, inner.height);
        x += CbW + Gap;

        lay.obj = new Rect(x, inner.y, objW, inner.height);
        x += objW;

        lay.scene = new Rect(x, inner.y, SceneW, inner.height);
        x += SceneW;

        lay.hideFlags = new Rect(x, inner.y, HideFlagsW, inner.height);
        x += HideFlagsW;

        lay.reason = new Rect(x, inner.y, reasonW, inner.height);
        x += reasonW;

        lay.actions = new Rect(inner.xMax - ActionsTotal, inner.y, ActionsTotal, inner.height);

        float ax = lay.actions.x;
        lay.ping = new Rect(ax, inner.y, PingW, inner.height);
        lay.select = new Rect(ax + PingW + Gap, inner.y, SelectW, inner.height);
        lay.del = new Rect(ax + PingW + Gap + SelectW + Gap, inner.y, DeleteW, inner.height);

        return lay;
    }

    private void DrawListHeader()
    {
        var r = GUILayoutUtility.GetRect(1f, EditorGUIUtility.singleLineHeight + 8f, GUILayout.ExpandWidth(true));
        GUI.Box(r, GUIContent.none, EditorStyles.helpBox);

        var inner = new Rect(r.x + PadX, r.y + PadY, r.width - PadX * 2f, r.height - PadY * 2f);
        var col = CalcColumns(inner);

        GUI.BeginGroup(inner);
        {
            float lh = EditorGUIUtility.singleLineHeight;
            float y = (inner.height - lh) * 0.5f;

            GUI.Label(new Rect(col.cb.x - inner.x, y, col.cb.width, lh), "");
            GUI.Label(new Rect(col.obj.x - inner.x, y, col.obj.width, lh), "Object");
            GUI.Label(new Rect(col.scene.x - inner.x, y, col.scene.width, lh), "Scene");
            GUI.Label(new Rect(col.hideFlags.x - inner.x, y, col.hideFlags.width, lh), "HideFlags");
            GUI.Label(new Rect(col.reason.x - inner.x, y, col.reason.width, lh), "Reason");
            GUI.Label(new Rect(col.actions.x - inner.x, y, col.actions.width, lh), "Actions");
        }
        GUI.EndGroup();
    }

    private void DrawList()
    {
        var listToDraw = groupByScene ? grouped : new Dictionary<string, List<SuspectItem>> { { "", GetFilteredList() } };

        using (var sv = new EditorGUILayout.ScrollViewScope(scroll))
        {
            scroll = sv.scrollPosition;

            foreach (var kv in listToDraw.OrderBy(k => k.Key, StringComparer.Ordinal))
            {
                var sceneKey = kv.Key;
                var items = kv.Value;

                if (groupByScene)
                {
                    using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                    {
                        EditorGUILayout.LabelField(string.IsNullOrEmpty(sceneKey) ? "<no scene>" : sceneKey, EditorStyles.boldLabel);
                        GUILayout.FlexibleSpace();
                        GUILayout.Label($"{items.Count}", GUILayout.Width(50));
                    }
                }

                foreach (var it in items)
                {
                    if (!it.obj) continue;

                    var rowRect = GUILayoutUtility.GetRect(1f, RowHeight, GUILayout.ExpandWidth(true));

                    if (Event.current.type == EventType.Repaint)
                        GUI.Box(rowRect, GUIContent.none, EditorStyles.helpBox);

                    var inner = new Rect(
                        rowRect.x + PadX,
                        rowRect.y + PadY,
                        rowRect.width - PadX * 2f,
                        rowRect.height - PadY * 2f
                    );

                    var col = CalcColumns(inner);

                    GUI.BeginGroup(inner);
                    {
                        float lh = EditorGUIUtility.singleLineHeight;
                        float yTop = 0f;
                        float yMid = (inner.height - lh) * 0.5f;

                        var cbRect = new Rect(col.cb.x - inner.x, yMid, col.cb.width, lh);
                        it.checkedForDelete = EditorGUI.Toggle(cbRect, it.checkedForDelete);

                        string displayName = it.kind == "Component"
                            ? $"{it.go.name} ({it.obj.GetType().Name})"
                            : (it.go ? it.go.name : it.obj.name);

                        var nameRect = new Rect(col.obj.x - inner.x, yTop, col.obj.width, lh);
                        GUI.Label(nameRect, displayName, objNameStyle);

                        if (showHierarchyPath)
                        {
                            var pathRect = new Rect(col.obj.x - inner.x, yTop + lh, col.obj.width, lh);

                            string fullPath = it.hierarchyPath ?? "";
                            string shownPath = EllipsizeLeft(fullPath, objPathStyle, pathRect.width);

                            GUI.Label(pathRect, new GUIContent(shownPath, fullPath), objPathStyle);
                        }

                        var sceneRect = new Rect(col.scene.x - inner.x, yMid, col.scene.width, lh);
                        GUI.Label(sceneRect, it.sceneName ?? "", EditorStyles.label);

                        var hfRect = new Rect(col.hideFlags.x - inner.x, yMid, col.hideFlags.width, lh);
                        GUI.Label(hfRect, it.hideFlags.ToString(), EditorStyles.label);

                        var reasonRect = new Rect(col.reason.x - inner.x, yMid, col.reason.width, lh);
                        GUI.Label(reasonRect, it.reason ?? "", EditorStyles.label);

                        var pingRect = new Rect(col.ping.x - inner.x, yMid, col.ping.width, lh);
                        var selectRect = new Rect(col.select.x - inner.x, yMid, col.select.width, lh);
                        var delRect = new Rect(col.del.x - inner.x, yMid, col.del.width, lh);

                        if (GUI.Button(pingRect, "Ping"))
                            EditorGUIUtility.PingObject(it.go ? (UnityEngine.Object)it.go : it.obj);

                        if (GUI.Button(selectRect, "Select"))
                            Selection.activeObject = it.go ? (UnityEngine.Object)it.go : it.obj;

                        if (GUI.Button(delRect, "Delete"))
                            DeleteSingleWithConfirm(it);
                    }
                    GUI.EndGroup();
                }
            }
        }
    }

    private void DrawFooter()
    {
        using (new EditorGUILayout.HorizontalScope())
        {
            using (new EditorGUI.DisabledScope(!HasAnyChecked()))
            {
                if (GUILayout.Button("Select Checked", GUILayout.Width(120)))
                    SelectChecked();

                if (GUILayout.Button("Delete Checked", GUILayout.Width(120)))
                    DeleteCheckedWithConfirm();
            }

            GUILayout.FlexibleSpace();

            if (GUILayout.Button("Dump Shown to Console", GUILayout.Width(160)))
                DumpShownToConsole();
        }
    }

    private void RefreshList()
    {
        suspects.Clear();

        var keys = keywords
            .Where(k => !string.IsNullOrWhiteSpace(k))
            .Select(k => k.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        bool MatchKeyword(string s)
        {
            if (string.IsNullOrEmpty(s)) return false;
            if (keys.Length == 0) return false;
            return keys.Any(k => s.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        bool PassDontSave(HideFlags hf)
        {
            if (includeDontSave) return true;
            if ((hf & HideFlags.DontSaveInEditor) != 0) return false;
            if ((hf & HideFlags.DontSaveInBuild) != 0) return false;
            if ((hf & HideFlags.DontUnloadUnusedAsset) != 0) return false;
            if ((hf & HideFlags.HideAndDontSave) != 0) return false;
            return true;
        }

        void GetSceneVisibility(GameObject go, out bool hidden, out bool pickOff)
        {
            hidden = false;
            pickOff = false;

            try
            {
                var svm = SceneVisibilityManager.instance;
                if (svm != null)
                {
                    hidden = svm.IsHidden(go);
                    pickOff = svm.IsPickingDisabled(go);
                }
            }
            catch
            {
                hidden = false;
                pickOff = false;
            }
        }

        string BuildReason(bool hfHidden, bool kw, bool notEd, bool pickOff, bool visHidden)
        {
            var parts = new List<string>(5);
            if (hfHidden) parts.Add("HideFlags");
            if (notEd) parts.Add("NotEditable");
            if (pickOff) parts.Add("PickOff");
            if (visHidden) parts.Add("SceneHidden");
            if (kw) parts.Add("Keyword");
            return string.Join("+", parts);
        }

        void AddItem(UnityEngine.Object obj, GameObject go, string kind)
        {
            if (!obj) return;
            if (!go) return;
            if (EditorUtility.IsPersistent(obj)) return;

            bool sceneValid = go.scene.IsValid();
            if (onlySceneObjects && !sceneValid) return;

            var hf = obj.hideFlags;
            if (!PassDontSave(hf)) return;

            bool kw = MatchKeyword(go.name) || MatchKeyword(obj.name) || MatchKeyword(obj.GetType().Name);
            bool hfHidden = hf != HideFlags.None;
            bool notEd = (hf & HideFlags.NotEditable) != 0;

            GetSceneVisibility(go, out bool visHidden, out bool pickOff);

            bool isSuspect = hfHidden || kw || notEd || pickOff || visHidden;

            if (onlyHidden && !(hfHidden || notEd || pickOff || visHidden)) return;
            if (onlyKeyword && !kw) return;

            if (!isSuspect) return;

            suspects.Add(new SuspectItem
            {
                obj = obj,
                go = go,
                checkedForDelete = false,
                sceneName = sceneValid ? go.scene.name : "<no scene>",
                hierarchyPath = BuildHierarchyPath(go),
                hideFlags = hf,
                keyword = kw,
                hiddenByHideFlags = hfHidden,
                notEditable = notEd,
                pickingDisabled = pickOff,
                hiddenBySceneVisibility = visHidden,
                kind = kind,
                reason = BuildReason(hfHidden, kw, notEd, pickOff, visHidden),
            });
        }

        var allGos = Resources.FindObjectsOfTypeAll<GameObject>();
        foreach (var go in allGos)
        {
            if (!go) continue;
            if (EditorUtility.IsPersistent(go)) continue;

            AddItem(go, go, "GameObject");

            if (!includeComponents) continue;

            var comps = go.GetComponents<Component>();
            foreach (var c in comps)
            {
                if (!c) continue;
                AddItem(c, go, "Component");
            }
        }

        suspects.Sort((a, b) =>
        {
            int s = string.Compare(a.sceneName, b.sceneName, StringComparison.Ordinal);
            if (s != 0) return s;
            int p = string.Compare(a.hierarchyPath, b.hierarchyPath, StringComparison.Ordinal);
            if (p != 0) return p;
            int k = string.Compare(a.kind, b.kind, StringComparison.Ordinal);
            if (k != 0) return k;
            string an = a.obj ? a.obj.name : "";
            string bn = b.obj ? b.obj.name : "";
            return string.Compare(an, bn, StringComparison.Ordinal);
        });

        ApplyGrouping();
        Repaint();
    }

    private void ApplyGrouping()
    {
        grouped = new Dictionary<string, List<SuspectItem>>(StringComparer.Ordinal);
        foreach (var it in GetFilteredList())
        {
            var key = groupByScene ? it.sceneName : "";
            if (!grouped.TryGetValue(key, out var list))
            {
                list = new List<SuspectItem>();
                grouped[key] = list;
            }
            list.Add(it);
        }
    }

    private List<SuspectItem> GetFilteredList()
    {
        IEnumerable<SuspectItem> q = suspects.Where(s => s.obj);

        if (!string.IsNullOrWhiteSpace(nameFilter))
        {
            var f = nameFilter.Trim();
            q = q.Where(s =>
                (s.go && s.go.name.IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0) ||
                (s.obj && s.obj.name.IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0) ||
                (!string.IsNullOrEmpty(s.hierarchyPath) && s.hierarchyPath.IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0) ||
                (!string.IsNullOrEmpty(s.sceneName) && s.sceneName.IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0) ||
                (!string.IsNullOrEmpty(s.reason) && s.reason.IndexOf(f, StringComparison.OrdinalIgnoreCase) >= 0)
            );
        }

        return q.ToList();
    }

    private int GetShownCount() => GetFilteredList().Count;

    private bool HasAnyChecked() => GetFilteredList().Any(s => s.obj && s.checkedForDelete);

    private void SetAllChecks(bool value)
    {
        foreach (var it in GetFilteredList())
            it.checkedForDelete = value;
        Repaint();
    }

    private void SelectChecked()
    {
        var arr = GetFilteredList()
            .Where(s => s.obj && s.checkedForDelete)
            .Select(s => (UnityEngine.Object)(s.go ? s.go : s.obj))
            .ToArray();
        Selection.objects = arr;
    }

    private void DeleteSingleWithConfirm(SuspectItem it)
    {
        if (!it.obj) return;

        string title = "Delete object";
        string msg =
            "This will delete the object immediately (Undo supported).\n\n" +
            $"Kind: {it.kind}\n" +
            $"Name: {it.obj.name}\n" +
            $"Scene: {it.sceneName}\n" +
            $"Reason: {it.reason}\n" +
            $"HideFlags: {it.hideFlags}\n" +
            $"Path: {it.hierarchyPath}\n";

        if (!EditorUtility.DisplayDialog(title, msg, "Delete", "Cancel"))
            return;

        Undo.DestroyObjectImmediate(it.obj);

        suspects.Remove(it);
        ApplyGrouping();
        Repaint();
    }

    private void DeleteCheckedWithConfirm()
    {
        var targets = GetFilteredList().Where(s => s.obj && s.checkedForDelete).ToList();
        if (targets.Count == 0) return;

        string title = "Delete checked objects";
        string msg =
            "This will delete checked objects immediately (Undo supported).\n\n" +
            $"Count: {targets.Count}\n";

        if (!EditorUtility.DisplayDialog(title, msg, "Delete", "Cancel"))
            return;

        Undo.IncrementCurrentGroup();
        int group = Undo.GetCurrentGroup();
        Undo.SetCurrentGroupName("Cleanup Hidden Objects");

        foreach (var t in targets)
        {
            if (!t.obj) continue;
            Undo.DestroyObjectImmediate(t.obj);
        }

        Undo.CollapseUndoOperations(group);

        var set = new HashSet<UnityEngine.Object>(targets.Select(t => t.obj));
        suspects.RemoveAll(s => !s.obj || set.Contains(s.obj));

        ApplyGrouping();
        Repaint();
    }

    private void DumpShownToConsole()
    {
        var list = GetFilteredList().Where(s => s.obj).ToList();
        if (list.Count == 0)
        {
            Debug.Log("[Cleanup] Shown list is empty.");
            return;
        }

        string text = string.Join("\n", list.Select(s =>
            $"[{s.kind}] name='{s.obj.name}' go='{s.go?.name}' scene='{s.sceneName}' hideFlags={s.hideFlags} reason={s.reason} path='{s.hierarchyPath}'"
        ));

        Debug.Log($"[Cleanup] Shown suspects: {list.Count}\n{text}");
    }

    private static string BuildHierarchyPath(GameObject go)
    {
        if (!go) return "<null>";
        var t = go.transform;
        if (!t) return go.name;

        var stack = new List<string>(32);
        while (t != null)
        {
            stack.Add(t.name);
            t = t.parent;
        }
        stack.Reverse();
        return string.Join("/", stack);
    }
}