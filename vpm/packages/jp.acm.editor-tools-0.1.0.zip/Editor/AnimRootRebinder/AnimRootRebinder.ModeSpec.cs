using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace ACM
{
    public partial class AnimRootRebinderWindow
    {
        sealed class ModeSpec
        {
            public string Id;
            public string Label;

            public string UndoGroupName;
            public string UndoRecordName;

            public Action DrawUI;
            public Func<(bool ok, string title, string detail)> CanRun;
            public Func<AnimationClip, Func<string, (bool changed, string to)>> BuildMapForPreview;
            public Func<IEnumerable<AnimationClip>> GetSources;

            public Action<AnimationClip, AnimationClip> Apply;

        }

        List<ModeSpec> modeSpecs;
        [SerializeField] string selectedModeId = "";

        ModeSpec CurrentSpec
        {
            get
            {
                EnsureModeSpecs();
                if (modeSpecs.Count == 0) return null;

                int idx = modeSpecs.FindIndex(m => m.Id == selectedModeId);
                if (idx < 0) idx = 0;
                selectedModeId = modeSpecs[idx].Id;
                return modeSpecs[idx];
            }
        }

        void EnsureModeSpecs()
        {
            if (modeSpecs != null && modeSpecs.Count > 0) return;

            modeSpecs = new List<ModeSpec>();

            modeSpecs.Add(CreateSpec_AnimatorRoot());
            modeSpecs.Add(CreateSpec_MoveSubtree());
            modeSpecs.Add(CreateSpec_MissingRename());
            modeSpecs.Add(CreateSpec_Manual());

            if (string.IsNullOrEmpty(selectedModeId))
                selectedModeId = modeSpecs[0].Id;
        }

        IEnumerable<AnimationClip> GetAllClips()
            => clips != null ? clips.Where(c => c != null) : Enumerable.Empty<AnimationClip>();

        IEnumerable<AnimationClip> GetInspectClipOnly()
        {
            var c = GetInspectClip();
            if (c != null) yield return c;
        }

        AnimationClip GetInspectClip()
        {
            if (clips == null || clips.Count == 0) return null;
            advancedInspectClipIndex = Mathf.Clamp(advancedInspectClipIndex, 0, clips.Count - 1);
            return clips[advancedInspectClipIndex];
        }
    }
}
