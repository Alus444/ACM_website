using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ACM
{
    public partial class AnimRootRebinderWindow
    {
        void DrawModeUI_MissingRename()
        {
            animatorRoot = (GameObject)EditorGUILayout.ObjectField("Animator Root", animatorRoot, typeof(GameObject), true);
            missingFixIncludeChildren = EditorGUILayout.ToggleLeft("Include children (prefix replace)", missingFixIncludeChildren);

            EditorGUILayout.Space(6);

            using (new EditorGUILayout.HorizontalScope())
            {
                using (new EditorGUI.DisabledScope(animatorRoot == null || clips == null || !clips.Any(c => c != null)))
                {
                    if (GUILayout.Button("Scan Missing", GUILayout.Height(22)))
                        ScanMissing();
                }

                using (new EditorGUI.DisabledScope(!missingScanned))
                {
                    if (GUILayout.Button("Clear Scan", GUILayout.Height(22), GUILayout.Width(100)))
                    {
                        missingScanned = false;
                        missingGroups.Clear();
                        selectedMissingEntryIndex = -1;
                        selectedFromPath = "";
                        selectedFromDepth = 0;
                        lastRunSummary = "";
                    }
                }
            }

            if (missingScanned)
                DrawMissingSummary();

            EditorGUILayout.Space(6);

            var prevSub = missingSubMode;
            missingSubMode = (MissingSubMode)EditorGUILayout.EnumPopup("Rename Mode", missingSubMode);
            if (prevSub != missingSubMode)
            {
                selectedMissingEntryIndex = -1;
                selectedFromPath = "";
                selectedFromDepth = 0;
            }

            if (missingScanned)
            {
                if (missingSubMode == MissingSubMode.AutoResolver)
                {
                    if (HasAnyDuplicateSiblingNames())
                        EditorGUILayout.HelpBox("同一階層に同名のオブジェクトがあります。リネームで一意にしてからScanしてください。", MessageType.Warning);
                }
                else
                {
                    DrawMissingSingleUI();
                }
            }
        }

        bool CanRun_MissingRename(out string title, out string detail)
        {
            title = "";
            detail = "";

            if (animatorRoot == null)
            {
                detail = "Animator Root を設定してください";
                return false;
            }

            if (!missingScanned)
            {
                title = "Missing Rename";
                detail = "Scan Missing ->";
                return true;
            }

            if (missingSubMode == MissingSubMode.AutoResolver)
            {
                if (HasAnyDuplicateSiblingNames())
                {
                    title = "Missing Rename (AutoResolver)";
                    detail = "同一階層に同名のオブジェクトがあります。リネームで一意にしてからScanしてください。";
                    return false;
                }

                title = "Missing Rename (AutoResolver)";
                detail = $"Groups: {missingGroups.Count}";
                return true;
            }

            EnsureSingleApplyArray();

            if (string.IsNullOrEmpty(selectedFromPath))
            {
                title = "Missing Rename (Single)";
                detail = "From Missing Path を選択してください";
                return false;
            }

            if (correctObject == null)
            {
                title = "Missing Rename (Single)";
                detail = "Correct Object (Hierarchy) を選択してください";
                return false;
            }

            if (!IsDescendantOrSame(correctObject, animatorRoot.transform))
            {
                title = "Missing Rename (Single)";
                detail = "Correct Object が Animator Root の配下にありません";
                return false;
            }

            string toPath = CalcPath(correctObject, animatorRoot.transform);
            int toDepth = GetDepth(toPath);
            if (toDepth != selectedFromDepth)
            {
                title = "Missing Rename (Single)";
                detail = $"Depth mismatch: from={selectedFromDepth}, to={toDepth}";
                return false;
            }

            if (!singleApplyToClips.Any(x => x))
            {
                title = "Missing Rename (Single)";
                detail = "Apply To Clips を選んでください";
                return false;
            }

            title = "Missing Rename (Single)";
            detail = $"From: {TruncatePath(selectedFromPath, 56)}";
            return true;
        }

        void Apply_MissingRename(AnimationClip sourceClip, AnimationClip targetClip)
        {
            if (!missingScanned) return;
            if (sourceClip == null || targetClip == null) return;

            if (missingSubMode == MissingSubMode.AutoResolver)
                ApplyMissingFixesAuto(sourceClip, targetClip);
            else
                ApplyMissingFixesSingle(targetClip);
        }

        void DrawMissingSummary()
        {
            int clipCount = missingGroups.Count;
            int itemCount = missingGroups.Sum(g => g.items.Count);
            int pathCount = missingGroups.Sum(g => g.totalPathsMissing);
            int bindingCount = missingGroups.Sum(g => g.totalBindingsMissing);
            int dupParents = missingGroups.Sum(g => g.items.Count(i => i.hasDuplicateSiblingNames));
            int singleRecommended = missingGroups.Sum(g => g.items.Count(i => i.parentMissing));

            using (new EditorGUILayout.VerticalScope("box"))
            {
                EditorGUILayout.LabelField("Missing Scan", EditorStyles.boldLabel);
                EditorGUILayout.LabelField($"Clips: {clipCount}  Items: {itemCount}  Paths: {pathCount}  Bindings: {bindingCount}");
                if (dupParents > 0)
                    EditorGUILayout.HelpBox($"Duplicate sibling names detected ({dupParents}). AutoResolver is blocked until resolved.", MessageType.Warning);
                if (singleRecommended > 0)
                    EditorGUILayout.HelpBox($"AutoResolverで親階層が見つからないMissingがあります（{singleRecommended}）。Singleモードに変更し、手動で修正することを推奨します。", MessageType.Warning);
            }
        }

        bool HasAnyDuplicateSiblingNames()
        {
            for (int gi = 0; gi < missingGroups.Count; gi++)
            {
                var g = missingGroups[gi];
                if (g == null) continue;
                for (int ii = 0; ii < g.items.Count; ii++)
                {
                    if (g.items[ii].hasDuplicateSiblingNames)
                        return true;
                }
            }
            return false;
        }

        void DrawMissingPickerUI()
        {
            using (new EditorGUILayout.VerticalScope("box"))
            {
                EditorGUILayout.LabelField("Missing Resolver", EditorStyles.boldLabel);

                foreach (var g in missingGroups)
                {
                    if (g.clip == null) continue;

                    EditorGUILayout.Space(4);
                    EditorGUILayout.LabelField(g.clip.name, EditorStyles.miniBoldLabel);

                    if (g.items.Count == 0)
                    {
                        EditorGUILayout.LabelField("No missing in this clip.");
                        continue;
                    }

                    foreach (var it in g.items)
                    {
                        Rect row = EditorGUILayout.GetControlRect(false, EditorGUIUtility.singleLineHeight);
                        row.width -= 1f;

                        float pad = 6f;
                        float labelW = Mathf.Clamp(row.width * 0.55f, 180f, 360f);
                        float popupW = Mathf.Max(0f, row.width - labelW - pad);

                        Rect labelRect = new Rect(row.x, row.y, labelW, row.height);
                        Rect popupRect = new Rect(labelRect.xMax + pad, row.y, popupW, row.height);

                        string shown = it.bindingPath ?? "";
                        int cut = shown.LastIndexOf('/');
                        if (cut >= 0 && cut + 1 < shown.Length) shown = shown.Substring(cut + 1);

                        var gc = new GUIContent(shown, it.bindingPath);
                        EditorGUI.LabelField(labelRect, gc);

                        if (it.parentMissing)
                        {
                            EditorGUI.LabelField(popupRect, new GUIContent("PARENT MISSING", it.parentMissingPath));
                            continue;
                        }

                        if (it.hasDuplicateSiblingNames)
                        {
                            EditorGUI.LabelField(popupRect, new GUIContent("DUPLICATE", it.duplicateNamesCsv));
                            continue;
                        }

                        if (it.candidates == null || it.candidates.Count == 0)
                        {
                            EditorGUI.LabelField(popupRect, "No siblings");
                            continue;
                        }

                        it.selectedIndex = Mathf.Clamp(it.selectedIndex, 0, it.candidates.Count - 1);
                        it.selectedIndex = EditorGUI.Popup(popupRect, it.selectedIndex, it.candidates.ToArray());
                    }
                }
            }
        }

        List<MissingPathEntry> BuildMissingPathEntries()
        {
            var list = new List<MissingPathEntry>();
            for (int i = 0; i < missingGroups.Count; i++)
            {
                var g = missingGroups[i];
                if (g == null || g.clip == null) continue;
                for (int j = 0; j < g.missingPaths.Count; j++)
                {
                    var p = g.missingPaths[j];
                    if (string.IsNullOrEmpty(p)) continue;
                    list.Add(new MissingPathEntry { clip = g.clip, path = p });
                }
            }
            return list;
        }

        string[] BuildMissingPathLabels(List<MissingPathEntry> entries)
        {
            var labels = new string[entries.Count];
            for (int i = 0; i < entries.Count; i++)
            {
                string clipName = entries[i].clip != null ? entries[i].clip.name : "(null)";
                string p = entries[i].path ?? "";
                labels[i] = $"{clipName}: {TruncatePath(p, 64)}";
            }
            return labels;
        }

        void DrawMissingSingleUI()
        {
            using (new EditorGUILayout.VerticalScope("box"))
            {
                EditorGUILayout.LabelField("Single Fix", EditorStyles.boldLabel);

                var entries = BuildMissingPathEntries();
                if (entries.Count == 0)
                {
                    EditorGUILayout.LabelField("No missing paths.");
                    return;
                }

                EnsureSingleApplyArray();

                var labels = BuildMissingPathLabels(entries);

                int prevIdx = selectedMissingEntryIndex;
                selectedMissingEntryIndex = Mathf.Clamp(selectedMissingEntryIndex, 0, labels.Length - 1);
                selectedMissingEntryIndex = EditorGUILayout.Popup("From Missing Path", selectedMissingEntryIndex, labels);

                if (selectedMissingEntryIndex != prevIdx || string.IsNullOrEmpty(selectedFromPath))
                {
                    var e = entries[selectedMissingEntryIndex];
                    selectedFromPath = e.path ?? "";
                    selectedFromDepth = GetDepth(selectedFromPath);

                    for (int i = 0; i < singleApplyToClips.Length; i++)
                        singleApplyToClips[i] = false;

                    int idx = clips.IndexOf(e.clip);
                    if (idx >= 0 && idx < singleApplyToClips.Length)
                        singleApplyToClips[idx] = true;
                }

                correctObject = (Transform)EditorGUILayout.ObjectField("Correct Object (Hierarchy)", correctObject, typeof(Transform), true);

                string toPath = "";
                int toDepth = 0;
                bool underRoot = false;
                bool hasPath = false;
                bool leaf = false;

                if (animatorRoot != null && correctObject != null)
                {
                    var rootT = animatorRoot.transform;
                    underRoot = IsDescendantOrSame(correctObject, rootT);
                    if (underRoot)
                    {
                        toPath = CalcPath(correctObject, rootT);
                        hasPath = true;
                        toDepth = GetDepth(toPath);
                        leaf = correctObject.childCount == 0;
                    }
                }

                using (new EditorGUILayout.VerticalScope("box"))
                {
                    var wrap = new GUIStyle(EditorStyles.textArea) { wordWrap = true };

                    EditorGUILayout.LabelField("From");
                    EditorGUILayout.TextArea(selectedFromPath ?? "", wrap);
                    EditorGUILayout.LabelField($"Depth: {selectedFromDepth}");

                    if (!hasPath)
                    {
                        if (correctObject == null)
                            EditorGUILayout.LabelField("To: (select Correct Object)");
                        else if (animatorRoot == null)
                            EditorGUILayout.LabelField("To: (set Animator Root)");
                        else if (!underRoot)
                            EditorGUILayout.LabelField("To: (Correct Object is not under Animator Root)");
                        else
                            EditorGUILayout.LabelField("To: (path calc failed)");
                    }
                    else
                    {
                        EditorGUILayout.LabelField("To");
                        EditorGUILayout.TextArea(toPath ?? "", wrap);
                        EditorGUILayout.LabelField($"Depth: {toDepth}   Leaf: {(leaf ? "yes" : "no")}");
                    }

                    if (hasPath && selectedFromDepth != toDepth)
                        EditorGUILayout.HelpBox("Depth mismatch. This Single Fix is blocked.", MessageType.Warning);
                }

                using (new EditorGUILayout.VerticalScope("box"))
                {
                    EditorGUILayout.LabelField("Apply To Clips", EditorStyles.miniBoldLabel);

                    for (int i = 0; i < clips.Count; i++)
                    {
                        if (clips[i] == null) continue;
                        singleApplyToClips[i] = EditorGUILayout.ToggleLeft(clips[i].name, singleApplyToClips[i]);
                    }
                }
            }
        }

        void ScanMissing()
        {
            missingGroups.Clear();
            missingScanned = false;

            if (animatorRoot == null) return;
            var root = animatorRoot.transform;

            foreach (var clip in clips.Where(c => c != null))
            {
                var g = new MissingGroup { clip = clip };

                var all = new List<EditorCurveBinding>();
                all.AddRange(AnimationUtility.GetCurveBindings(clip));
                all.AddRange(AnimationUtility.GetObjectReferenceCurveBindings(clip));

                int missingBindingCount = 0;
                var missingPathsSet = new HashSet<string>();

                foreach (var b in all)
                {
                    string p = b.path ?? "";
                    if (string.IsNullOrEmpty(p)) continue;
                    if (root.Find(p) != null) continue;

                    missingBindingCount++;
                    missingPathsSet.Add(p);
                }

                var missingPaths = missingPathsSet.OrderBy(x => x).ToList();
                g.missingPaths = missingPaths;
                g.totalBindingsMissing = missingBindingCount;
                g.totalPathsMissing = missingPaths.Count;

                var grouped = new Dictionary<string, MissingItem>();

                foreach (var p in missingPaths)
                {
                    SplitParentAndName(p, out var parentPath, out var oldName);
                    if (string.IsNullOrEmpty(oldName)) continue;

                    string key = parentPath + "|" + oldName;
                    if (!grouped.TryGetValue(key, out var it))
                    {
                        it = new MissingItem
                        {
                            bindingPath = p,
                            parentPath = parentPath,
                            oldName = oldName,
                            selectedIndex = 0
                        };
                        grouped.Add(key, it);
                    }
                }

                foreach (var it in grouped.Values.OrderBy(x => x.parentPath).ThenBy(x => x.oldName))
                {
                    var parent = FindTransformByPath(root, it.parentPath);
                    if (parent != null)
                    {
                        it.candidates = GetChildrenNames(parent, out var hasDup, out var dupCsv);
                        it.hasDuplicateSiblingNames = hasDup;
                        it.duplicateNamesCsv = dupCsv;
                        it.parentMissing = false;
                        it.parentMissingPath = "";
                        it.selectedIndex = Mathf.Clamp(it.selectedIndex, 0, Mathf.Max(0, it.candidates.Count - 1));
                    }
                    else
                    {
                        it.candidates.Clear();
                        it.hasDuplicateSiblingNames = false;
                        it.duplicateNamesCsv = "";
                        it.parentMissing = true;
                        it.parentMissingPath = it.parentPath;
                        it.selectedIndex = 0;
                    }
                    g.items.Add(it);
                }

                if (g.totalPathsMissing > 0 || g.totalBindingsMissing > 0)
                    missingGroups.Add(g);
            }

            missingScanned = true;
            selectedMissingEntryIndex = 0;
            selectedFromPath = "";
            selectedFromDepth = 0;
        }

        Func<string, (bool changed, string to)> BuildMap_MissingAuto(AnimationClip src)
        {
            var g = missingGroups.FirstOrDefault(x => x.clip == src);
            if (g == null) return null;

            var reps = new List<(string oldPrefix, string newPrefix)>();

            foreach (var it in g.items)
            {
                if (it.hasDuplicateSiblingNames) return null;
                if (it.parentMissing) continue;
                if (it.candidates == null || it.candidates.Count == 0) continue;

                it.selectedIndex = Mathf.Clamp(it.selectedIndex, 0, it.candidates.Count - 1);
                string newName = it.candidates[it.selectedIndex];
                if (string.IsNullOrEmpty(newName)) continue;

                string oldFull = ComposeChildPath(it.parentPath, it.oldName);
                string newFull = ComposeChildPath(it.parentPath, newName);
                if (oldFull == newFull) continue;

                reps.Add((oldFull, newFull));
            }

            if (reps.Count == 0)
                return (p) => (false, p ?? "");

            return (string p) =>
            {
                if (TryReplaceAny(p ?? "", reps, missingFixIncludeChildren, out var replaced))
                    return (true, replaced);
                return (false, p ?? "");
            };
        }

        Func<string, (bool changed, string to)> BuildMap_MissingSingle()
        {
            string fromPath = selectedFromPath ?? "";
            if (string.IsNullOrEmpty(fromPath)) return null;

            if (animatorRoot == null || correctObject == null) return null;

            var rootT = animatorRoot.transform;
            if (!IsDescendantOrSame(correctObject, rootT)) return null;

            string toPath = CalcPath(correctObject, rootT);
            if (GetDepth(fromPath) != GetDepth(toPath)) return null;

            var reps = new List<(string oldPrefix, string newPrefix)> { (fromPath, toPath) };

            return (string p) =>
            {
                if (TryReplaceAny(p ?? "", reps, missingFixIncludeChildren, out var replaced))
                    return (true, replaced);
                return (false, p ?? "");
            };
        }

        void ApplyMissingFixesAuto(AnimationClip sourceClip, AnimationClip targetClip)
        {
            var g = missingGroups.FirstOrDefault(x => x.clip == sourceClip);
            if (g == null || g.items.Count == 0) return;

            var reps = new List<(string oldPrefix, string newPrefix)>();

            foreach (var it in g.items)
            {
                if (it.hasDuplicateSiblingNames) return;
                if (it.parentMissing) continue;
                if (it.candidates == null || it.candidates.Count == 0) continue;

                it.selectedIndex = Mathf.Clamp(it.selectedIndex, 0, it.candidates.Count - 1);
                string newName = it.candidates[it.selectedIndex];
                if (string.IsNullOrEmpty(newName)) continue;

                string oldFull = ComposeChildPath(it.parentPath, it.oldName);
                string newFull = ComposeChildPath(it.parentPath, newName);
                if (oldFull == newFull) continue;

                reps.Add((oldFull, newFull));
            }

            if (reps.Count == 0) return;

            ApplyPathReplacements(targetClip, reps, missingFixIncludeChildren, copyAnimationEvents, null);
        }

        void ApplyMissingFixesSingle(AnimationClip targetClip)
        {
            string fromPath = selectedFromPath ?? "";
            if (string.IsNullOrEmpty(fromPath)) return;

            if (animatorRoot == null || correctObject == null) return;

            var rootT = animatorRoot.transform;
            if (!IsDescendantOrSame(correctObject, rootT)) return;

            string toPath = CalcPath(correctObject, rootT);
            if (GetDepth(fromPath) != GetDepth(toPath)) return;

            var reps = new List<(string oldPrefix, string newPrefix)> { (fromPath, toPath) };
            ApplyPathReplacements(targetClip, reps, missingFixIncludeChildren, copyAnimationEvents, null);
        }

        static Transform FindTransformByPath(Transform root, string parentPath)
        {
            if (root == null) return null;
            if (string.IsNullOrEmpty(parentPath)) return root;
            return root.Find(parentPath);
        }

        static List<string> GetChildrenNames(Transform parent, out bool hasDup, out string dupCsv)
        {
            hasDup = false;
            dupCsv = "";

            var r = new List<string>();
            if (parent == null) return r;

            var count = new Dictionary<string, int>(StringComparer.Ordinal);
            int n = parent.childCount;
            for (int i = 0; i < n; i++)
            {
                var c = parent.GetChild(i);
                if (c == null) continue;

                r.Add(c.name);

                if (!count.TryGetValue(c.name, out var v)) v = 0;
                count[c.name] = v + 1;
            }

            var dups = new List<string>();
            foreach (var kv in count)
                if (kv.Value > 1) dups.Add(kv.Key);

            if (dups.Count > 0)
            {
                hasDup = true;
                dupCsv = string.Join(", ", dups);
            }

            return r;
        }

        static void SplitParentAndName(string path, out string parentPath, out string name)
        {
            parentPath = "";
            name = "";

            if (string.IsNullOrEmpty(path)) return;

            int idx = path.LastIndexOf('/');
            if (idx < 0)
            {
                parentPath = "";
                name = path;
                return;
            }

            parentPath = idx == 0 ? "" : path.Substring(0, idx);
            name = (idx + 1) < path.Length ? path.Substring(idx + 1) : "";
        }
        ModeSpec CreateSpec_MissingRename()
        {
            return new ModeSpec
            {
                Id = "MissingRename",
                Label = "MissingRename",
                UndoGroupName = "Fix Clip Paths (Missing Rename)",
                UndoRecordName = "Fix Clip Paths (Missing Rename)",
                DrawUI = DrawModeUI_MissingRename,
                CanRun = () => { var ok = CanRun_MissingRename(out var t, out var d); return (ok, t, d); },
                GetSources = GetAllClips,
                BuildMapForPreview = (clip) => BuildMap_MissingRename_ForPreview(clip),
                Apply = (src, target) => Apply_MissingRename(src, target),
            };
        }

    }


}
