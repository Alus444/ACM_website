using System;
using UnityEditor;
using UnityEngine;

namespace ACM
{
    public partial class AnimRootRebinderWindow
    {
        void DrawModeUI_MoveSubtree()
        {
            Rect row = EditorGUILayout.GetControlRect(false, EditorGUIUtility.singleLineHeight);
            row.width -= 1f;
            animatorRoot = (GameObject)EditorGUI.ObjectField(row, "Animator Root", animatorRoot, typeof(GameObject), true);

            row = EditorGUILayout.GetControlRect(false, EditorGUIUtility.singleLineHeight);
            row.width -= 1f;
            movedTransform = (Transform)EditorGUI.ObjectField(row, "Moved Object", movedTransform, typeof(Transform), true);

            row = EditorGUILayout.GetControlRect(false, EditorGUIUtility.singleLineHeight);
            row.width -= 1f;
            oldParent = (Transform)EditorGUI.ObjectField(row, "Old Parent", oldParent, typeof(Transform), true);

            row = EditorGUILayout.GetControlRect(false, EditorGUIUtility.singleLineHeight);
            row.width -= 1f;
            newParent = (Transform)EditorGUI.ObjectField(row, "New Parent", newParent, typeof(Transform), true);
        }



        bool CanRun_MoveSubtree(out string title, out string detail)
        {
            title = "";
            detail = "";

            if (animatorRoot == null || movedTransform == null || oldParent == null || newParent == null)
            {
                detail = "Animator Root / Moved / Old Parent / New Parent �̂����ꂩ�����w��ł�";
                return false;
            }

            var rootT = animatorRoot.transform;

            if (!IsDescendantOrSame(oldParent, rootT) || !IsDescendantOrSame(newParent, rootT))
            {
                detail = "Old Parent / New Parent �� Animator Root �̔z���ɂ���܂���";
                return false;
            }

            if (!IsDescendantOrSame(movedTransform, rootT))
            {
                detail = "Moved Transform �� Animator Root �̔z���ɂ���܂���";
                return false;
            }

            string oldPrefix = ComposeChildPath(CalcPath(oldParent, rootT), movedTransform.name);
            string newPrefix = ComposeChildPath(CalcPath(newParent, rootT), movedTransform.name);

            if (oldPrefix == newPrefix)
            {
                detail = "�u���O��̃p�X�������ł�";
                return false;
            }

            title = "Move Subtree (Repath)";
            detail = $"Replace \"{oldPrefix}\" -> \"{newPrefix}\"";
            return true;
        }

        Func<string, (bool changed, string to)> BuildMap_MoveSubtree()
        {
            if (animatorRoot == null || movedTransform == null || oldParent == null || newParent == null) return null;

            var rootT = animatorRoot.transform;
            string oldPrefix = ComposeChildPath(CalcPath(oldParent, rootT), movedTransform.name);
            string newPrefix = ComposeChildPath(CalcPath(newParent, rootT), movedTransform.name);

            return (string p) =>
            {
                if (TryReplacePrefix(p ?? "", oldPrefix, newPrefix, out var replaced))
                    return (true, replaced);
                return (false, p ?? "");
            };
        }

        void Apply_MoveSubtree(AnimationClip clip)
        {
            if (clip == null) return;

            var rootT = animatorRoot.transform;
            string oldPrefix = ComposeChildPath(CalcPath(oldParent, rootT), movedTransform.name);
            string newPrefix = ComposeChildPath(CalcPath(newParent, rootT), movedTransform.name);

            ApplyMoveSubtree(clip, oldPrefix, newPrefix, copyAnimationEvents);
        }

        static void ApplyMoveSubtree(AnimationClip clip, string oldPrefix, string newPrefix, bool copyEvents)
        {
            if (clip == null) return;

            var curveBindings = AnimationUtility.GetCurveBindings(clip);
            var objectBindings = AnimationUtility.GetObjectReferenceCurveBindings(clip);

            var curveMoves = new System.Collections.Generic.List<(EditorCurveBinding oldB, EditorCurveBinding newB, AnimationCurve curve)>();
            foreach (var b in curveBindings)
            {
                var c = AnimationUtility.GetEditorCurve(clip, b);
                if (c == null) continue;

                if (!TryReplacePrefix(b.path, oldPrefix, newPrefix, out var replaced))
                    continue;

                var nb = b;
                nb.path = replaced;
                curveMoves.Add((b, nb, c));
            }

            var objMoves = new System.Collections.Generic.List<(EditorCurveBinding oldB, EditorCurveBinding newB, ObjectReferenceKeyframe[] keys)>();
            foreach (var b in objectBindings)
            {
                var k = AnimationUtility.GetObjectReferenceCurve(clip, b);
                if (k == null) continue;

                if (!TryReplacePrefix(b.path, oldPrefix, newPrefix, out var replaced))
                    continue;

                var nb = b;
                nb.path = replaced;
                objMoves.Add((b, nb, k));
            }

            foreach (var m in curveMoves)
            {
                AnimationUtility.SetEditorCurve(clip, m.oldB, null);
                AnimationUtility.SetEditorCurve(clip, m.newB, m.curve);
            }

            foreach (var m in objMoves)
            {
                AnimationUtility.SetObjectReferenceCurve(clip, m.oldB, null);
                AnimationUtility.SetObjectReferenceCurve(clip, m.newB, m.keys);
            }

            if (copyEvents)
            {
                var ev = AnimationUtility.GetAnimationEvents(clip);
                AnimationUtility.SetAnimationEvents(clip, ev);
            }
        }

        ModeSpec CreateSpec_MoveSubtree()
        {
            return new ModeSpec
            {
                Id = "MoveSubtree",
                Label = "MoveSubtree",
                UndoGroupName = "Fix Clip Paths (Move Subtree)",
                UndoRecordName = "Fix Clip Paths (Move Subtree)",
                DrawUI = DrawModeUI_MoveSubtree,
                CanRun = () => { var ok = CanRun_MoveSubtree(out var t, out var d); return (ok, t, d); },
                GetSources = GetAllClips,
                BuildMapForPreview = (clip) => BuildMap_MoveSubtree(),
                Apply = (src, target) => Apply_MoveSubtree(target),
            };
        }
    }

}
