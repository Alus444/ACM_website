using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ACM
{
    public partial class AnimRootRebinderWindow
    {
        class MissingItem
        {
            public string bindingPath;
            public string parentPath;
            public string oldName;
            public int selectedIndex;
            public List<string> candidates = new List<string>();

            public bool hasDuplicateSiblingNames;
            public string duplicateNamesCsv;

            public bool parentMissing;
            public string parentMissingPath;
        }

        class MissingGroup
        {
            public AnimationClip clip;
            public List<string> missingPaths = new List<string>();
            public List<MissingItem> items = new List<MissingItem>();
            public int totalPathsMissing;
            public int totalBindingsMissing;
        }

        struct MissingPathEntry
        {
            public AnimationClip clip;
            public string path;
        }

        struct PreviewStat
        {
            public int affectedBindings;
            public int affectedUniquePaths;
            public List<(string from, string to)> examples;
        }

        class BindingEntry
        {
            public AnimationClip clip;
            public EditorCurveBinding binding;
            public bool missing;
            public string label;
            public string tooltip;
        }

        class BindingComparer : IEqualityComparer<EditorCurveBinding>
        {
            public bool Equals(EditorCurveBinding a, EditorCurveBinding b)
            {
                return a.path == b.path
                    && a.propertyName == b.propertyName
                    && a.type == b.type
                    && a.isPPtrCurve == b.isPPtrCurve;
            }

            public int GetHashCode(EditorCurveBinding b)
            {
                unchecked
                {
                    int h = 17;
                    h = h * 31 + (b.path?.GetHashCode() ?? 0);
                    h = h * 31 + (b.propertyName?.GetHashCode() ?? 0);
                    h = h * 31 + (b.type?.GetHashCode() ?? 0);
                    h = h * 31 + b.isPPtrCurve.GetHashCode();
                    return h;
                }
            }
        }

        static int GetDepth(string path)
        {
            if (string.IsNullOrEmpty(path)) return 0;
            int count = 1;
            for (int i = 0; i < path.Length; i++)
                if (path[i] == '/') count++;
            return count;
        }

        static bool IsDescendantOrSame(Transform child, Transform potentialParent)
        {
            if (child == null || potentialParent == null) return false;

            Transform t = child;
            while (t != null)
            {
                if (t == potentialParent) return true;
                t = t.parent;
            }
            return false;
        }

        static string GetPrefixPath(Transform a, Transform b)
        {
            if (a == b) return string.Empty;
            return AnimationUtility.CalculateTransformPath(a, b);
        }

        static string ComposeNewPath(string prefix, string oldPath)
        {
            oldPath ??= string.Empty;

            if (string.IsNullOrEmpty(prefix))
                return oldPath;

            if (string.IsNullOrEmpty(oldPath))
                return prefix;

            if (oldPath == prefix)
                return oldPath;

            if (oldPath.StartsWith(prefix + "/", StringComparison.Ordinal))
                return oldPath;

            return prefix + "/" + oldPath;
        }

        static string CalcPath(Transform target, Transform root)
        {
            if (target == root) return string.Empty;
            return AnimationUtility.CalculateTransformPath(target, root);
        }

        static string ComposeChildPath(string parentPath, string childName)
        {
            if (string.IsNullOrEmpty(parentPath)) return childName;
            return parentPath + "/" + childName;
        }

        static bool TryReplacePrefix(string path, string oldPrefix, string newPrefix, out string replaced)
        {
            replaced = path ?? "";

            if (replaced == (oldPrefix ?? ""))
            {
                replaced = newPrefix ?? "";
                return true;
            }

            if (!string.IsNullOrEmpty(oldPrefix) && replaced.StartsWith(oldPrefix + "/", StringComparison.Ordinal))
            {
                replaced = (newPrefix ?? "") + replaced.Substring(oldPrefix.Length);
                return true;
            }

            return false;
        }

        static bool TryReplaceAny(string path, List<(string oldPrefix, string newPrefix)> reps, bool includeChildren, out string replaced)
        {
            replaced = path ?? "";

            if (replaced.Length == 0)
            {
                for (int i = 0; i < reps.Count; i++)
                {
                    if ((reps[i].oldPrefix ?? "") == "")
                    {
                        replaced = reps[i].newPrefix ?? "";
                        return true;
                    }
                }
                return false;
            }

            for (int i = 0; i < reps.Count; i++)
            {
                var r = reps[i];
                string oldP = r.oldPrefix ?? "";
                string newP = r.newPrefix ?? "";

                if (includeChildren)
                {
                    if (replaced == oldP)
                    {
                        replaced = newP;
                        return true;
                    }

                    string head = oldP + "/";
                    if (!string.IsNullOrEmpty(oldP) && replaced.StartsWith(head, StringComparison.Ordinal))
                    {
                        replaced = newP + replaced.Substring(oldP.Length);
                        return true;
                    }
                }
                else
                {
                    if (replaced == oldP)
                    {
                        replaced = newP;
                        return true;
                    }
                }
            }

            return false;
        }

        static string TruncatePath(string s, int max)
        {
            s ??= "";
            if (s.Length <= max) return s;
            int keepTail = Mathf.Max(12, max - 12);
            return "�c" + s.Substring(s.Length - keepTail);
        }

        static void DrawSelectableMultiline(string text)
        {
            text ??= "";

            var style = new GUIStyle(EditorStyles.label) { wordWrap = true };
            float w = EditorGUIUtility.currentViewWidth - 60f;
            if (w < 100f) w = 100f;

            float h = style.CalcHeight(new GUIContent(text), w);
            Rect r = EditorGUILayout.GetControlRect(false, Mathf.Max(18f, h));

            EditorGUI.SelectableLabel(r, text, style);
        }

        void DrawClipsListFixedHeight(float height)
        {
            height = Mathf.Max(60f, height);

            clipsScroll = EditorGUILayout.BeginScrollView(clipsScroll, GUILayout.Height(height));

            int removeIndex = -1;

            for (int i = 0; i < clips.Count; i++)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    clips[i] = (AnimationClip)EditorGUILayout.ObjectField(clips[i], typeof(AnimationClip), false);

                    if (GUILayout.Button("�~", GUILayout.Width(24f)))
                        removeIndex = i;
                }
            }

            EditorGUILayout.EndScrollView();

            if (removeIndex >= 0 && removeIndex < clips.Count)
            {
                clips.RemoveAt(removeIndex);

                missingScanned = false;
                missingGroups.Clear();
                selectedMissingEntryIndex = -1;
                selectedFromPath = "";
                selectedFromDepth = 0;
                singleApplyToClips = null;

                advancedBindingsBuilt = false;
                advancedBindings.Clear();

                lastRunSummary = "";
            }
        }


        AnimationClip DuplicateClip(AnimationClip src)
        {
            string srcPath = AssetDatabase.GetAssetPath(src);
            if (string.IsNullOrEmpty(srcPath))
            {
                UnityEngine.Debug.LogWarning($"[FixClipPaths] Clip is not an asset: {src.name}");
                return null;
            }

            string dir = Path.GetDirectoryName(srcPath);
            string file = Path.GetFileNameWithoutExtension(srcPath);
            string ext = Path.GetExtension(srcPath);

            string newName = file + suffix + ext;
            string dstPath = AssetDatabase.GenerateUniqueAssetPath(Path.Combine(dir, newName));

            if (!AssetDatabase.CopyAsset(srcPath, dstPath))
            {
                UnityEngine.Debug.LogError($"[FixClipPaths] CopyAsset failed: {srcPath} -> {dstPath}");
                return null;
            }

            return AssetDatabase.LoadAssetAtPath<AnimationClip>(dstPath);
        }

        static void ApplyPathReplacements(
            AnimationClip clip,
            List<(string oldPrefix, string newPrefix)> reps,
            bool includeChildren,
            bool copyEvents,
            Type filterType
        )
        {
            var curveBindings = AnimationUtility.GetCurveBindings(clip);
            var objectBindings = AnimationUtility.GetObjectReferenceCurveBindings(clip);

            var curveMoves = new List<(EditorCurveBinding oldB, EditorCurveBinding newB, AnimationCurve curve)>();
            foreach (var b in curveBindings)
            {
                if (filterType != null && b.type != filterType) continue;

                var c = AnimationUtility.GetEditorCurve(clip, b);
                if (c == null) continue;

                if (!TryReplaceAny(b.path, reps, includeChildren, out var replaced))
                    continue;

                var nb = b;
                nb.path = replaced;
                curveMoves.Add((b, nb, c));
            }

            var objMoves = new List<(EditorCurveBinding oldB, EditorCurveBinding newB, ObjectReferenceKeyframe[] keys)>();
            foreach (var b in objectBindings)
            {
                if (filterType != null && b.type != filterType) continue;

                var k = AnimationUtility.GetObjectReferenceCurve(clip, b);
                if (k == null) continue;

                if (!TryReplaceAny(b.path, reps, includeChildren, out var replaced))
                    continue;

                var nb = b;
                nb.path = replaced;
                objMoves.Add((b, nb, k));
            }

            foreach (var m in curveMoves)
            {
                AnimationUtility.SetEditorCurve(clip, m.oldB, null);
                AnimationUtility.SetEditorCurve(clip, m.newB, m.curve);
            }

            foreach (var m in objMoves)
            {
                AnimationUtility.SetObjectReferenceCurve(clip, m.oldB, null);
                AnimationUtility.SetObjectReferenceCurve(clip, m.newB, m.keys);
            }

            if (copyEvents)
            {
                var ev = AnimationUtility.GetAnimationEvents(clip);
                AnimationUtility.SetAnimationEvents(clip, ev);
            }
        }

        void DrawPreviewBox()
        {
            if (!CanRun(out var title, out var detail))
            {
                EditorGUILayout.HelpBox(detail, MessageType.Info);
                return;
            }

            EditorGUILayout.HelpBox($"{title}\n{detail}", MessageType.None);

            if (!previewShowDetails)
            {
                if (!string.IsNullOrEmpty(lastRunSummary))
                    EditorGUILayout.HelpBox(lastRunSummary, MessageType.None);
                return;
            }

            var spec = CurrentSpec;
            if (spec == null) return;

            int clipsChanged = 0;
            int totalBindings = 0;
            int totalPaths = 0;

            var sources = spec.GetSources != null ? spec.GetSources() : clips.Where(c => c != null);

            foreach (var src in sources)
            {
                if (selectedModeId == "MissingRename" && missingScanned && missingSubMode == MissingSubMode.Single)
                {
                    EnsureSingleApplyArray();
                    int idx = clips.IndexOf(src);
                    if (idx < 0 || idx >= singleApplyToClips.Length || !singleApplyToClips[idx])
                        continue;
                }

                var map = spec.BuildMapForPreview != null ? spec.BuildMapForPreview(src) : null;
                if (map == null) continue;

                int localBindings = 0;
                int localPaths = 0;
                var uniq = new HashSet<string>(StringComparer.Ordinal);

                foreach (var b in AnimationUtility.GetCurveBindings(src))
                {
                    var p = b.path ?? "";
                    var r = map(p);
                    if (!r.changed) continue;
                    localBindings++;
                    if (uniq.Add(p)) localPaths++;
                }
                foreach (var b in AnimationUtility.GetObjectReferenceCurveBindings(src))
                {
                    var p = b.path ?? "";
                    var r = map(p);
                    if (!r.changed) continue;
                    localBindings++;
                    if (uniq.Add(p)) localPaths++;
                }

                if (localBindings > 0) clipsChanged++;
                totalBindings += localBindings;
                totalPaths += localPaths;
            }

            using (new EditorGUILayout.VerticalScope("box"))
            {
                EditorGUILayout.LabelField("Preview (diff)", EditorStyles.miniBoldLabel);
                EditorGUILayout.LabelField($"Changed Clips: {clipsChanged} / {clips.Count}");
                EditorGUILayout.LabelField($"Affected Bindings: {totalBindings}");
                EditorGUILayout.LabelField($"Affected Unique Paths: {totalPaths}");
            }

            if (!string.IsNullOrEmpty(lastRunSummary))
                EditorGUILayout.HelpBox(lastRunSummary, MessageType.None);
        }

        Func<string, (bool changed, string to)> BuildMap_MissingRename_ForPreview(AnimationClip src)
        {
            if (selectedModeId != "MissingRename") return null;
            if (!missingScanned) return null;

            if (missingSubMode == MissingSubMode.AutoResolver)
                return BuildMap_MissingAuto(src);

            return BuildMap_MissingSingle();
        }
    }
}
