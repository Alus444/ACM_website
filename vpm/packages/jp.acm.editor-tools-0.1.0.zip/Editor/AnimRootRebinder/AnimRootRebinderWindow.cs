using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ACM
{
    public partial class AnimRootRebinderWindow : EditorWindow
    {
        enum MissingSubMode
        {
            AutoResolver,
            Single
        }

        enum AdvancedInputMode
        {
            SelectFromBindings,
            FullManual
        }

        [SerializeField] List<AnimationClip> clips = new List<AnimationClip>();

        [SerializeField] bool duplicateAndSaveAsNew = true;
        [SerializeField] string suffix = "_Fixed";
        [SerializeField] bool copyAnimationEvents = true;

        [SerializeField] GameObject fromRoot;
        [SerializeField] GameObject toRoot;

        [SerializeField] GameObject animatorRoot;

        [SerializeField] Transform movedTransform;
        [SerializeField] Transform oldParent;
        [SerializeField] Transform newParent;

        [SerializeField] bool missingFixIncludeChildren = true;
        [SerializeField] MissingSubMode missingSubMode = MissingSubMode.AutoResolver;
        [SerializeField] Transform correctObject;
        [SerializeField] int selectedMissingEntryIndex = -1;
        [SerializeField] string selectedFromPath = "";
        [SerializeField] int selectedFromDepth = 0;
        [SerializeField] bool[] singleApplyToClips;
        [SerializeField] bool rescanAfterFix = true;

        [SerializeField] bool previewShowDetails = true;
        //[SerializeField] int previewExampleCount = 3;
        string lastRunSummary = "";

        [SerializeField] AdvancedInputMode advancedInputMode = AdvancedInputMode.SelectFromBindings;
        [SerializeField] bool advancedIncludeChildren = true;

        [SerializeField] int advancedInspectClipIndex = 0;
        [SerializeField] int advancedBindingIndex = 0;
        [SerializeField] string advancedToPath = "";
        [SerializeField] string advancedManualFromPath = "";
        [SerializeField] string advancedManualToPath = "";

        [SerializeField] bool manualToUseObject = true;
        [SerializeField] Transform manualToObject;

        [SerializeField] bool manualOnlySelectedType = true;
        [SerializeField] bool manualBlockIfTargetExists = true;

        [SerializeField] Vector2 mainScroll;
        Vector2 clipsScroll;
        Vector2 advancedBindingsScroll;

        readonly List<MissingGroup> missingGroups = new List<MissingGroup>();
        bool missingScanned;

        readonly List<BindingEntry> advancedBindings = new List<BindingEntry>();
        bool advancedBindingsBuilt;

        const float FixButtonHeight = 28f;
        const float FixPad = 8f;

        const float RowH = 20f;
        const float RowGap = 2f;

        const float ScrollbarW = 16f;
        const float RightPad = 4f;

        [MenuItem("Tools/ACM/Animation/Fix_Paths")]
        static void Open()
        {
            GetWindow<AnimRootRebinderWindow>("Fix_Paths");
        }

        void OnGUI()
        {
            EnsureModeSpecs();
            var spec = CurrentSpec;
            if (spec == null)
            {
                EditorGUILayout.HelpBox("ModeSpec is missing.", MessageType.Error);
                return;
            }

            using (new EditorGUILayout.VerticalScope())
            {
                using (var sv = new EditorGUILayout.ScrollViewScope(mainScroll, false, false, GUILayout.ExpandHeight(true)))
                {
                    mainScroll = sv.scrollPosition;

                    float maxW = position.width - 0f;
                    if (maxW < 0f) maxW = 0f;

                    using (new EditorGUILayout.VerticalScope(GUILayout.MaxWidth(maxW), GUILayout.ExpandWidth(true)))
                    {

                        EditorGUILayout.Space(6);
                        EditorGUILayout.LabelField("【令和最新版】AnimationClipのpath修正【絶対安全】", EditorStyles.boldLabel);
                        EditorGUILayout.Space(6);

                        using (new EditorGUILayout.VerticalScope("box"))
                        {
                            var labels = modeSpecs.Select(m => m.Label).ToArray();
                            int curIndex = modeSpecs.FindIndex(m => m.Id == selectedModeId);
                            if (curIndex < 0) curIndex = 0;

                            int newIndex = EditorGUILayout.Popup("Mode", curIndex, labels);
                            if (newIndex != curIndex)
                            {
                                selectedModeId = modeSpecs[newIndex].Id;
                                ResetPerModeState();
                                spec = CurrentSpec;
                            }

                            EditorGUILayout.Space(6);

                            spec.DrawUI?.Invoke();

                            EditorGUILayout.Space(8);

                            duplicateAndSaveAsNew = EditorGUILayout.ToggleLeft("Duplicate clips (recommended)", duplicateAndSaveAsNew);
                            using (new EditorGUI.DisabledScope(!duplicateAndSaveAsNew))
                                suffix = EditorGUILayout.TextField("New clip suffix", suffix);

                            copyAnimationEvents = EditorGUILayout.ToggleLeft("Copy Animation Events", copyAnimationEvents);

                            EditorGUILayout.Space(6);
                            DrawPreviewBox();
                        }

                        EditorGUILayout.Space(8);

                        using (new EditorGUILayout.VerticalScope("box"))
                        {
                            EditorGUILayout.LabelField("Target AnimationClips", EditorStyles.boldLabel);

                            using (new EditorGUILayout.HorizontalScope())
                            {
                                if (GUILayout.Button("Add Selected Clips", GUILayout.Height(22)))
                                    AddSelectedClips();

                                if (GUILayout.Button("Clear", GUILayout.Height(22), GUILayout.Width(80)))
                                    ClearAll();
                            }

                            EditorGUILayout.Space(6);

                            if (selectedModeId == "MissingRename" && missingScanned && missingSubMode == MissingSubMode.AutoResolver)
                            {
                                DrawMissingPickerUI();
                                EditorGUILayout.Space(8);
                            }

                            DrawClipsListFixedHeight(240f);
                        }


                    }
                }

                    GUILayout.Space(2f);

                    using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                    {
                        using (new EditorGUI.DisabledScope(!CanRun(out _, out _)))
                        {
                            if (GUILayout.Button("Fix", GUILayout.Height(FixButtonHeight), GUILayout.ExpandWidth(true)))
                                Run();
                        }
                    }

                }
           
        }


        void ResetPerModeState()
        {
            missingScanned = false;
            missingGroups.Clear();
            selectedMissingEntryIndex = -1;
            selectedFromPath = "";
            selectedFromDepth = 0;
            lastRunSummary = "";

            advancedBindingsBuilt = false;
            advancedBindings.Clear();
        }

        void ClearAll()
        {
            clips.Clear();

            missingScanned = false;
            missingGroups.Clear();
            selectedMissingEntryIndex = -1;
            selectedFromPath = "";
            selectedFromDepth = 0;
            singleApplyToClips = null;

            advancedBindingsBuilt = false;
            advancedBindings.Clear();

            lastRunSummary = "";
        }

        void AddSelectedClips()
        {
            foreach (var o in Selection.objects)
            {
                if (o is AnimationClip ac && !clips.Contains(ac))
                    clips.Add(ac);
            }

            missingScanned = false;
            missingGroups.Clear();
            selectedMissingEntryIndex = -1;
            selectedFromPath = "";
            selectedFromDepth = 0;
            singleApplyToClips = null;

            advancedBindingsBuilt = false;
            advancedBindings.Clear();

            lastRunSummary = "";
        }

        bool CanRun(out string title, out string detail)
        {
            title = "";
            detail = "";

            var spec = CurrentSpec;
            if (spec == null)
            {
                detail = "ModeSpec is missing.";
                return false;
            }

            if (clips == null || clips.Count == 0 || !clips.Any(c => c != null))
            {
                detail = "AnimationClipが選択されていません。";
                return false;
            }

            var (ok, t, d) = spec.CanRun != null ? spec.CanRun() : (false, "", "CanRun is not set.");
            title = t;
            detail = d;
            return ok;

        }

        void Run()
        {
            if (!CanRun(out _, out _))
                return;

            lastRunSummary = "";

            var spec = CurrentSpec;
            if (spec == null) return;

            var produced = new List<AnimationClip>();

            var sources = spec.GetSources != null ? spec.GetSources() : GetAllClips();

            foreach (var src in sources)
            {
                if (selectedModeId == "MissingRename" && missingScanned && missingSubMode == MissingSubMode.Single)
                {
                    EnsureSingleApplyArray();
                    int idx = clips.IndexOf(src);
                    if (idx < 0 || idx >= singleApplyToClips.Length || !singleApplyToClips[idx])
                        continue;
                }

                try
                {
                    var target = duplicateAndSaveAsNew ? DuplicateClip(src) : src;
                    if (target == null) continue;

                    if (duplicateAndSaveAsNew && target != src)
                        produced.Add(target);

                    int group = Undo.GetCurrentGroup();

                    Undo.SetCurrentGroupName(spec.UndoGroupName ?? "Fix Clip Paths");
                    Undo.RecordObject(target, spec.UndoRecordName ?? "Fix Clip Paths");

                    spec.Apply?.Invoke(src, target);

                    Undo.CollapseUndoOperations(group);
                    EditorUtility.SetDirty(target);
                }
                catch (Exception e)
                {
                    UnityEngine.Debug.LogError($"[FixClipPaths] Failed: {src?.name}\n{e}");
                }
            }

            if (produced.Count > 0)
            {
                foreach (var p in produced)
                    if (p != null && !clips.Contains(p))
                        clips.Add(p);
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            if (selectedModeId == "Manual")
            {
                advancedBindingsBuilt = false;
                advancedBindings.Clear();
                Repaint();
                EditorApplication.RepaintHierarchyWindow();
                EditorApplication.RepaintProjectWindow();
                UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
            }

            if (selectedModeId == "MissingRename" && rescanAfterFix && animatorRoot != null)
            {
                ScanMissing();

                int groups = missingGroups.Count;
                int paths = missingGroups.Sum(g => g.totalPathsMissing);
                int binds = missingGroups.Sum(g => g.totalBindingsMissing);

                lastRunSummary = $"Post-Scan: Groups={groups}  MissingPaths={paths}  MissingBindings={binds}";
                EditorUtility.DisplayDialog("Fix result", lastRunSummary, "OK");
                return;
            }

            if (selectedModeId == "MissingRename")
            {
                missingScanned = false;
                missingGroups.Clear();
                selectedMissingEntryIndex = -1;
                selectedFromPath = "";
                selectedFromDepth = 0;
            }
        }

        void EnsureSingleApplyArray()
        {
            if (singleApplyToClips == null || singleApplyToClips.Length != clips.Count)
            {
                singleApplyToClips = new bool[clips.Count];
                for (int i = 0; i < singleApplyToClips.Length; i++)
                    singleApplyToClips[i] = true;
            }
        }
    }
}
