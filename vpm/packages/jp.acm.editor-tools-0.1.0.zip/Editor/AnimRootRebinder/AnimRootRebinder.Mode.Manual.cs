using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace ACM
{
    public partial class AnimRootRebinderWindow
    {
        void DrawModeUI_Manual()
        {
            using (new EditorGUILayout.VerticalScope("box"))
            {
                var head = new GUIStyle(EditorStyles.boldLabel) { richText = true };
                EditorGUILayout.LabelField("<color=#E6C84A>[Advance]</color> Manual", head);

                animatorRoot = (GameObject)EditorGUILayout.ObjectField("Animator Root", animatorRoot, typeof(GameObject), true);
                advancedIncludeChildren = EditorGUILayout.ToggleLeft("Include children (オフにすると完全一致のみ置き換えます)", advancedIncludeChildren);
                if (advancedInputMode == AdvancedInputMode.SelectFromBindings)
                {
                    manualOnlySelectedType = EditorGUILayout.ToggleLeft("Only Selected Component Type (指定のコンポーネント単位で置き換えます)", manualOnlySelectedType);
                }
                manualBlockIfTargetExists = EditorGUILayout.ToggleLeft("Block if target binding already exists", manualBlockIfTargetExists);

                EditorGUILayout.Space(6);

                advancedInputMode = (AdvancedInputMode)EditorGUILayout.EnumPopup("Input Mode", advancedInputMode);

                var clipNames = clips.Select(c => c != null ? c.name : "(null)").ToArray();
                if (clipNames.Length == 0) clipNames = new[] { "(none)" };

                advancedInspectClipIndex = Mathf.Clamp(advancedInspectClipIndex, 0, clipNames.Length - 1);
                advancedInspectClipIndex = EditorGUILayout.Popup("Inspect Clip (bindings)", advancedInspectClipIndex, clipNames);

                AnimationClip inspectClip =
                    (advancedInspectClipIndex >= 0 && advancedInspectClipIndex < clips.Count) ? clips[advancedInspectClipIndex] : null;

                using (new EditorGUI.DisabledScope(inspectClip == null))
                {
                    if (GUILayout.Button("Reload Bindings", GUILayout.Height(22)))
                    {
                        advancedBindingsBuilt = false;
                        advancedBindings.Clear();

                        if (inspectClip != null)
                            BuildAdvancedBindingsForClip(inspectClip);

                        advancedBindingIndex = Mathf.Clamp(advancedBindingIndex, 0, Mathf.Max(0, advancedBindings.Count - 1));

                        Repaint();
                        EditorApplication.RepaintHierarchyWindow();
                        EditorApplication.RepaintProjectWindow();
                        UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
                    }
                }

                EditorGUILayout.Space(6);

                using (new EditorGUILayout.VerticalScope("box"))
                {
                    var s = new GUIStyle(EditorStyles.miniBoldLabel) { richText = true };
                    string headText =
                            (advancedInputMode == AdvancedInputMode.FullManual)
                                  ? "Bindings (reference only)  (missing: <color=#E6C84A>yellow</color>)"
                                  : "Bindings (missing: <color=#E6C84A>yellow</color>)";

                    EditorGUILayout.LabelField(headText, s);


                    if (inspectClip == null)
                    {
                        EditorGUILayout.LabelField("No clip selected.");
                    }
                    else
                    {
                        if (!advancedBindingsBuilt || advancedBindings.Count == 0 || advancedBindings[0].clip != inspectClip)
                            BuildAdvancedBindingsForClip(inspectClip);

                        if (advancedBindings.Count == 0)
                        {
                            EditorGUILayout.LabelField("No bindings.");
                        }
                        else
                        {
                            var popupLabels = new string[advancedBindings.Count];
                            for (int i = 0; i < advancedBindings.Count; i++)
                            {
                                var e = advancedBindings[i];
                                popupLabels[i] = e.missing ? $"[MISSING] {e.label}" : e.label;
                            }

                            advancedBindingIndex = Mathf.Clamp(advancedBindingIndex, 0, popupLabels.Length - 1);
                            advancedBindingIndex = EditorGUILayout.Popup(new GUIContent("From Binding"), advancedBindingIndex, popupLabels);

                            var chosen = advancedBindings[advancedBindingIndex];

                            var warn = new GUIStyle(EditorStyles.label) { richText = true };
                            if (chosen.missing)
                                EditorGUILayout.LabelField("<color=#E6C84A>Selected binding is missing under Animator Root</color>", warn);

                            using (new EditorGUILayout.VerticalScope("box"))
                            {
                                EditorGUILayout.LabelField("Selected Binding Path");
                                DrawSelectableMultiline(chosen.binding.path ?? "");

                                EditorGUILayout.LabelField("Selected Property");
                                DrawSelectableMultiline($"{chosen.binding.type?.Name} : {chosen.binding.propertyName}");
                            }

                            if (advancedInputMode == AdvancedInputMode.SelectFromBindings)
                            {
                                EditorGUILayout.Space(4);

                                manualToUseObject = EditorGUILayout.ToggleLeft("To Path from Hierarchy", manualToUseObject);

                                if (manualToUseObject)
                                {
                                    manualToObject = (Transform)EditorGUILayout.ObjectField("To Object (Hierarchy)", manualToObject, typeof(Transform), true);

                                    string computed = "";
                                    bool ok = false;

                                    if (animatorRoot != null && manualToObject != null)
                                    {
                                        var rootT = animatorRoot.transform;
                                        if (IsDescendantOrSame(manualToObject, rootT))
                                        {
                                            computed = CalcPath(manualToObject, rootT);
                                            ok = true;
                                        }
                                    }

                                    using (new EditorGUI.DisabledScope(true))
                                        EditorGUILayout.TextField("To Path", ok ? computed : "");

                                    if (ok) advancedToPath = computed;

                                    DrawPathExistenceCheck(advancedToPath);
                                }
                                else
                                {
                                    advancedToPath = EditorGUILayout.TextField("To Path", advancedToPath ?? "");
                                    DrawPathExistenceCheck(advancedToPath);
                                }
                            }
                        }
                    }
                }

                if (advancedInputMode == AdvancedInputMode.FullManual)
                {
                    using (new EditorGUILayout.VerticalScope("box"))
                    {
                        EditorGUILayout.LabelField("Manual Edit", EditorStyles.miniBoldLabel);

                        var wrap = new GUIStyle(EditorStyles.textArea) { wordWrap = true };


                        if (advancedBindings != null && advancedBindings.Count > 0 &&
    advancedBindingIndex >= 0 && advancedBindingIndex < advancedBindings.Count)
                        {
                            using (new EditorGUILayout.HorizontalScope())
                            {
                                using (new EditorGUI.DisabledScope(true))
                                    EditorGUILayout.TextField("From Binding", advancedBindings[advancedBindingIndex].binding.path ?? "");

                                if (GUILayout.Button("Use", GUILayout.Width(60)))
                                    advancedManualFromPath = (advancedBindings[advancedBindingIndex].binding.path ?? "");
                            }
                            EditorGUILayout.Space(4);
                        }


                        EditorGUILayout.LabelField("From Path");
                        advancedManualFromPath = EditorGUILayout.TextArea(advancedManualFromPath ?? "", wrap);

                        EditorGUILayout.LabelField("To Path");
                        advancedManualToPath = EditorGUILayout.TextArea(advancedManualToPath ?? "", wrap);

                        DrawPathExistenceCheck(advancedManualToPath);
                    }
                }
            }
        }

        bool CanRun_Manual(out string title, out string detail)
        {
            title = "Manual";

            var inspect = GetInspectClip();
            if (inspect == null)
            {
                detail = "Inspect Clip を先に選んでください";
                return false;
            }

            if (advancedInputMode == AdvancedInputMode.SelectFromBindings)
            {
                if (advancedBindings == null || advancedBindings.Count == 0)
                {
                    detail = "Inspect Clip から binding を選んでください";
                    return false;
                }

                if (advancedBindingIndex < 0 || advancedBindingIndex >= advancedBindings.Count)
                {
                    detail = "From Binding が不正です";
                    return false;
                }

                detail = $"From: {TruncatePath(advancedBindings[advancedBindingIndex].binding.path ?? "", 56)}";
                return true;
            }

            advancedManualFromPath ??= "";
            advancedManualToPath ??= "";

            if (advancedManualFromPath.Trim().Length == 0 && advancedManualToPath.Trim().Length == 0)
            {
                detail = "From/To の入力をしてください";
                return false;
            }

            detail = $"From: {TruncatePath(advancedManualFromPath.Trim(), 56)}";
            return true;
        }

        Func<string, (bool changed, string to)> BuildMap_Manual()
        {
            string fromPath;
            string toPath;
            bool includeChildren = advancedIncludeChildren;

            if (advancedInputMode == AdvancedInputMode.SelectFromBindings)
            {
                if (advancedBindings == null || advancedBindings.Count == 0) return null;
                if (advancedBindingIndex < 0 || advancedBindingIndex >= advancedBindings.Count) return null;

                fromPath = advancedBindings[advancedBindingIndex].binding.path ?? "";
                toPath = (advancedToPath ?? "").Trim();
            }
            else
            {
                fromPath = (advancedManualFromPath ?? "").Trim();
                toPath = (advancedManualToPath ?? "").Trim();
            }

            var reps = new List<(string oldPrefix, string newPrefix)> { (fromPath, toPath) };

            return (string p) =>
            {
                if (TryReplaceAny(p ?? "", reps, includeChildren, out var replaced))
                    return (true, replaced);
                return (false, p ?? "");
            };
        }

        void DrawPathExistenceCheck(string toPath)
        {
            if (animatorRoot == null)
            {
                EditorGUILayout.HelpBox("Animator Root is not set. Existence check is skipped.", MessageType.Info);
                return;
            }

            var rootT = animatorRoot.transform;
            string p = (toPath ?? "").Trim();

            if (string.IsNullOrEmpty(p))
            {
                EditorGUILayout.HelpBox("To Path is empty. (Root object itself)", MessageType.None);
                return;
            }

            bool ok = rootT.Find(p) != null;
            if (ok) EditorGUILayout.HelpBox("To Path exists under Animator Root.", MessageType.None);
            else EditorGUILayout.HelpBox("To Path was not found under Animator Root. (実行可能ですが、現時点で指定のパス先にオブジェクトは存在しません。)", MessageType.Warning);
        }

        void BuildAdvancedBindingsForClip(AnimationClip clip)
        {
            advancedBindings.Clear();
            advancedBindingsBuilt = true;

            if (clip == null) return;

            var list = new List<EditorCurveBinding>();
            list.AddRange(AnimationUtility.GetCurveBindings(clip));
            list.AddRange(AnimationUtility.GetObjectReferenceCurveBindings(clip));

            Transform root = animatorRoot != null ? animatorRoot.transform : null;

            foreach (var b in list)
            {
                string path = b.path ?? "";
                bool isMissing = false;

                if (root != null && !string.IsNullOrEmpty(path))
                    isMissing = (root.Find(path) == null);

                string typeName = b.type != null ? b.type.Name : "(null)";
                string prop = b.propertyName ?? "";

                string shownPath = TruncatePath(path, 72);
                string shownProp = prop.Length > 64 ? (prop.Substring(0, 64) + "…") : prop;

                string label = $"{shownPath}   [{typeName}]   {shownProp}";
                string tooltip = $"{path}\nType: {typeName}\nProperty: {prop}";

                advancedBindings.Add(new BindingEntry
                {
                    clip = clip,
                    binding = b,
                    missing = isMissing,
                    label = label,
                    tooltip = tooltip
                });
            }
        }

        bool HasManualTargetCollisions(
            AnimationClip clip,
            List<(string oldPrefix, string newPrefix)> reps,
            bool includeChildren,
            Type filterType,
            out string message
        )
        {
            message = "";

            if (clip == null) { message = "Clip is null."; return true; }
            if (reps == null || reps.Count == 0) { message = "No replacements."; return true; }

            var cmp = new BindingComparer();

            var existing = new HashSet<EditorCurveBinding>(cmp);
            foreach (var b in AnimationUtility.GetCurveBindings(clip)) existing.Add(b);
            foreach (var b in AnimationUtility.GetObjectReferenceCurveBindings(clip)) existing.Add(b);

            int collisions = 0;
            const int maxShow = 6;
            var lines = new List<string>();

            void Check(EditorCurveBinding b)
            {
                if (filterType != null && b.type != filterType) return;

                if (!TryReplaceAny(b.path ?? "", reps, includeChildren, out var replaced))
                    return;

                var nb = b;
                nb.path = replaced;

                if (cmp.Equals(nb, b)) return;

                if (existing.Contains(nb))
                {
                    collisions++;
                    if (lines.Count < maxShow)
                    {
                        lines.Add(
                            $"- {b.type?.Name}  {b.propertyName}\n" +
                            $"  from: {b.path}\n" +
                            $"  to:   {nb.path}"
                        );
                    }
                }
            }

            foreach (var b in AnimationUtility.GetCurveBindings(clip)) Check(b);
            foreach (var b in AnimationUtility.GetObjectReferenceCurveBindings(clip)) Check(b);

            if (collisions > 0)
            {
                message =
                    $"Target binding already exists. Blocked.\n" +
                    $"Clip: {clip.name}\n" +
                    $"Collisions: {collisions}\n\n" +
                    string.Join("\n\n", lines);
                return true;
            }

            return false;
        }

        void Apply_Manual(AnimationClip targetClip)
        {
            if (targetClip == null) return;

            string fromPath;
            string toPath;
            bool includeChildren = advancedIncludeChildren;

            Type filterType = null;

            if (advancedInputMode == AdvancedInputMode.SelectFromBindings)
            {
                if (advancedBindings == null || advancedBindings.Count == 0) return;
                if (advancedBindingIndex < 0 || advancedBindingIndex >= advancedBindings.Count) return;

                var chosen = advancedBindings[advancedBindingIndex].binding;

                fromPath = chosen.path ?? "";
                toPath = (advancedToPath ?? "").Trim();

                if (manualOnlySelectedType)
                    filterType = chosen.type;
            }
            else
            {
                fromPath = (advancedManualFromPath ?? "").Trim();
                toPath = (advancedManualToPath ?? "").Trim();
                filterType = null;
            }

            var reps = new List<(string oldPrefix, string newPrefix)> { (fromPath, toPath) };

            if (manualBlockIfTargetExists)
            {
                if (HasManualTargetCollisions(targetClip, reps, includeChildren, filterType, out var msg))
                {
                    UnityEngine.Debug.LogError("[FixClipPaths] Manual blocked\n" + msg);
                    EditorUtility.DisplayDialog("Manual Fix blocked", msg, "OK");
                    return;
                }
            }

            ApplyPathReplacements(targetClip, reps, includeChildren, copyAnimationEvents, filterType);
        }

        ModeSpec CreateSpec_Manual()
        {
            return new ModeSpec
            {
                Id = "Manual",
                Label = "[Advance] Manual",
                UndoGroupName = "Fix Clip Paths (Manual)",
                UndoRecordName = "Fix Clip Paths (Manual)",
                DrawUI = DrawModeUI_Manual,
                CanRun = () => { var ok = CanRun_Manual(out var t, out var d); return (ok, t, d); },
                GetSources = GetInspectClipOnly,
                BuildMapForPreview = (clip) => BuildMap_Manual(),
                Apply = (src, target) => Apply_Manual(target),
            };
        }
    }
}
