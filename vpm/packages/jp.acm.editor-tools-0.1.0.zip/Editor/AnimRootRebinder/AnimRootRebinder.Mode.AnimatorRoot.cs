using System;
using UnityEditor;
using UnityEngine;

namespace ACM
{
    public partial class AnimRootRebinderWindow
    {
        void DrawModeUI_AnimatorRoot()
        {
            using (new EditorGUILayout.VerticalScope("box"))
            {
                fromRoot = (GameObject)EditorGUILayout.ObjectField("From Old Root", fromRoot, typeof(GameObject), true);
                toRoot = (GameObject)EditorGUILayout.ObjectField("To New Root", toRoot, typeof(GameObject), true);
            }
        }




        bool CanRun_AnimatorRoot(out string title, out string detail)
        {
            title = "";
            detail = "";

            if (fromRoot == null || toRoot == null)
            {
                detail = "From Root / To Root �̂����ꂩ�����w��ł�";
                return false;
            }

            var a = fromRoot.transform;
            var b = toRoot.transform;

            if (!IsDescendantOrSame(a, b))
            {
                detail = "From Root �� To Root �̔z���ɂ��܂���";
                return false;
            }

            string prefix = GetPrefixPath(a, b);
            title = "Rebase Animator Root";
            detail = $"Prefix (From -> To): \"{prefix}\"";
            return true;
        }

        Func<string, (bool changed, string to)> BuildMap_AnimatorRoot()
        {
            if (fromRoot == null || toRoot == null) return null;

            string prefix = GetPrefixPath(fromRoot.transform, toRoot.transform);
            return (string p) =>
            {
                var np = ComposeNewPath(prefix, p ?? "");
                return (np != (p ?? ""), np);
            };
        }

        void Apply_AnimatorRoot(AnimationClip clip)
        {
            if (clip == null) return;

            string prefix = GetPrefixPath(fromRoot.transform, toRoot.transform);

            var reps = new System.Collections.Generic.List<(string oldPrefix, string newPrefix)>
            {
                ("", prefix)
            };


            ApplyRebase(clip, prefix, copyAnimationEvents);
        }

        static void ApplyRebase(AnimationClip clip, string prefix, bool copyEvents)
        {
            if (clip == null) return;

            var curveBindings = AnimationUtility.GetCurveBindings(clip);
            var objectBindings = AnimationUtility.GetObjectReferenceCurveBindings(clip);

            var curveMoves = new System.Collections.Generic.List<(EditorCurveBinding oldB, EditorCurveBinding newB, AnimationCurve curve)>();
            foreach (var b in curveBindings)
            {
                var c = AnimationUtility.GetEditorCurve(clip, b);
                if (c == null) continue;

                var nb = b;
                nb.path = ComposeNewPath(prefix, b.path);
                if (nb.path == b.path) continue;

                curveMoves.Add((b, nb, c));
            }

            var objMoves = new System.Collections.Generic.List<(EditorCurveBinding oldB, EditorCurveBinding newB, ObjectReferenceKeyframe[] keys)>();
            foreach (var b in objectBindings)
            {
                var k = AnimationUtility.GetObjectReferenceCurve(clip, b);
                if (k == null) continue;

                var nb = b;
                nb.path = ComposeNewPath(prefix, b.path);
                if (nb.path == b.path) continue;

                objMoves.Add((b, nb, k));
            }

            foreach (var m in curveMoves)
            {
                AnimationUtility.SetEditorCurve(clip, m.oldB, null);
                AnimationUtility.SetEditorCurve(clip, m.newB, m.curve);
            }

            foreach (var m in objMoves)
            {
                AnimationUtility.SetObjectReferenceCurve(clip, m.oldB, null);
                AnimationUtility.SetObjectReferenceCurve(clip, m.newB, m.keys);
            }

            if (copyEvents)
            {
                var ev = AnimationUtility.GetAnimationEvents(clip);
                AnimationUtility.SetAnimationEvents(clip, ev);
            }
        }

        ModeSpec CreateSpec_AnimatorRoot()
        {
            return new ModeSpec
            {
                Id = "AnimatorRoot",
                Label = "AnimatorRoot",
                UndoGroupName = "Fix Clip Paths (Rebase Animator Root)",
                UndoRecordName = "Fix Clip Paths (Rebase Animator Root)",
                DrawUI = DrawModeUI_AnimatorRoot,
                CanRun = () => { var ok = CanRun_AnimatorRoot(out var t, out var d); return (ok, t, d); },
                GetSources = GetAllClips,
                BuildMapForPreview = (clip) => BuildMap_AnimatorRoot(),
                Apply = (src, target) => Apply_AnimatorRoot(target),
            };
        }

    }
}
