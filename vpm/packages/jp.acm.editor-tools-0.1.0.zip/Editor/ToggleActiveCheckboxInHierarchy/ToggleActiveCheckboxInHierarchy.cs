using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

[InitializeOnLoad]
public static class ToggleActiveCheckboxInHierarchy
{
    static Texture2D activeIcon;
    static Texture2D inactiveIcon;
    static GameObject lastToggleObj;
    static GameObject lastLockObj;

    private static HierarchyToggleSettings settings;
    private const string settingsPath = "Assets/ACM/Data/HierarchyToggleSettings.asset";

    private struct CachedIcon
    {
        public Component component;
        public Texture icon;
        public bool isChild;
        public bool alwaysShow;
    }

    private static readonly Dictionary<int, CachedIcon[]> componentIconCache = new Dictionary<int, CachedIcon[]>();

    private static GUIStyle badgeStyle;

    static ToggleActiveCheckboxInHierarchy()
    {
        LoadOrCreateSettings();

        if (settings.isVisible)
            EditorApplication.hierarchyWindowItemOnGUI += HierarchyItemOnGUI;

        EditorApplication.hierarchyChanged += ClearCache;
        ObjectChangeEvents.changesPublished += OnObjectChanges;

        activeIcon = EditorGUIUtility.IconContent("d_toggle_on").image as Texture2D;
        inactiveIcon = EditorGUIUtility.IconContent("d_toggle_bg").image as Texture2D;
    }

    private static void ClearCache() => componentIconCache.Clear();

    private static void OnObjectChanges(ref ObjectChangeEventStream stream)
    {
        for (int i = 0; i < stream.length; i++)
        {
            switch (stream.GetEventType(i))
            {
                case ObjectChangeKind.CreateGameObjectHierarchy:
                case ObjectChangeKind.DestroyGameObjectHierarchy:
                    ClearCache();
                    return;
                case ObjectChangeKind.ChangeGameObjectOrComponentProperties:
                    stream.GetChangeGameObjectOrComponentPropertiesEvent(i, out var e);
                    componentIconCache.Remove(e.instanceId);
                    break;
            }
        }
    }

    private static void LoadOrCreateSettings()
    {
        settings = AssetDatabase.LoadAssetAtPath<HierarchyToggleSettings>(settingsPath);
        if (settings == null)
        {
            if (!AssetDatabase.IsValidFolder("Assets/ACM")) AssetDatabase.CreateFolder("Assets", "ACM");
            if (!AssetDatabase.IsValidFolder("Assets/ACM/Data")) AssetDatabase.CreateFolder("Assets/ACM", "Data");

            settings = ScriptableObject.CreateInstance<HierarchyToggleSettings>();
            string[] types = new[] {
                "MeshRenderer", "SkinnedMeshRenderer", "MeshFilter",
                "Collider", "AudioSource", "AudioListener", "Camera"
            };
            foreach (var t in types)
                settings.iconSettings.Add(new HierarchyToggleSettings.IconSetting { typeName = t, isVisible = true });

            AssetDatabase.CreateAsset(settings, settingsPath);
            AssetDatabase.SaveAssets();
        }
    }

    // --- Visible ---
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Visible", false, 5)]
    private static void ToggleVisible()
    {
        settings.isVisible = !settings.isVisible;
        if (settings.isVisible)
            EditorApplication.hierarchyWindowItemOnGUI += HierarchyItemOnGUI;
        else
            EditorApplication.hierarchyWindowItemOnGUI -= HierarchyItemOnGUI;
        EditorUtility.SetDirty(settings);
        EditorApplication.RepaintHierarchyWindow();
    }
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Visible", true)]
    private static bool ValidateVisible()
    {
        Menu.SetChecked("Tools/ACM/ToggleActiveCheckboxInHierarchy/Visible", settings.isVisible);
        return true;
    }

    // --- Component Icons ---
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Component Icons", false, 10)]
    private static void ToggleComponentIcons()
    {
        settings.showComponentIcons = !settings.showComponentIcons;
        EditorUtility.SetDirty(settings);
        EditorApplication.RepaintHierarchyWindow();
    }
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Component Icons", true)]
    private static bool ValidateComponentIcons()
    {
        Menu.SetChecked("Tools/ACM/ToggleActiveCheckboxInHierarchy/Component Icons", settings.showComponentIcons);
        return true;
    }

    // --- Lock Icons ---
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Lock Icons", false, 11)]
    private static void ToggleLockIcons()
    {
        settings.showLockIcons = !settings.showLockIcons;
        EditorUtility.SetDirty(settings);
        EditorApplication.RepaintHierarchyWindow();
    }
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Lock Icons", true)]
    private static bool ValidateLockIcons()
    {
        Menu.SetChecked("Tools/ACM/ToggleActiveCheckboxInHierarchy/Lock Icons", settings.showLockIcons);
        return true;
    }

    // --- Expand On Hover ---
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Expand On Hover", false, 15)]
    private static void ToggleExpandOnHover()
    {
        settings.expandOnHover = !settings.expandOnHover;
        EditorUtility.SetDirty(settings);
        EditorApplication.RepaintHierarchyWindow();
    }
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Expand On Hover", true)]
    private static bool ValidateExpandOnHover()
    {
        Menu.SetChecked("Tools/ACM/ToggleActiveCheckboxInHierarchy/Expand On Hover", settings.expandOnHover);
        return true;
    }

    // --- Max Icons ---
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/3",         false, 20)]
    private static void SetMaxIcons3()         => ApplyMaxIcons(3);
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/5",         false, 21)]
    private static void SetMaxIcons5()         => ApplyMaxIcons(5);
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/8",         false, 22)]
    private static void SetMaxIcons8()         => ApplyMaxIcons(8);
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/Unlimited", false, 23)]
    private static void SetMaxIconsUnlimited() => ApplyMaxIcons(0);

    private static void ApplyMaxIcons(int count)
    {
        settings.maxIconCount = count;
        EditorUtility.SetDirty(settings);
        EditorApplication.RepaintHierarchyWindow();
    }

    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/3",         true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/5",         true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/8",         true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/Unlimited", true)]
    private static bool ValidateMaxIcons()
    {
        Menu.SetChecked("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/3",         settings.maxIconCount == 3);
        Menu.SetChecked("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/5",         settings.maxIconCount == 5);
        Menu.SetChecked("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/8",         settings.maxIconCount == 8);
        Menu.SetChecked("Tools/ACM/ToggleActiveCheckboxInHierarchy/Max Icons/Unlimited", settings.maxIconCount == 0);
        return true;
    }

    // --- Per-type visibility ---
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/MeshRenderer",         false, 30)]
    private static void ToggleMeshRenderer()   => ToggleType("MeshRenderer");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/SkinnedMeshRenderer",  false, 31)]
    private static void ToggleSkinned()        => ToggleType("SkinnedMeshRenderer");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/MeshFilter",           false, 32)]
    private static void ToggleMeshFilter()     => ToggleType("MeshFilter");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Collider",             false, 33)]
    private static void ToggleCollider()       => ToggleType("Collider");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/AudioSource",          false, 34)]
    private static void ToggleAudioSource()    => ToggleType("AudioSource");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/AudioListener",        false, 35)]
    private static void ToggleAudioListener()  => ToggleType("AudioListener");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Camera",               false, 36)]
    private static void ToggleCamera()         => ToggleType("Camera");

    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/MeshRenderer",        true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/SkinnedMeshRenderer", true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/MeshFilter",          true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Collider",            true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/AudioSource",         true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/AudioListener",       true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Camera",              true)]
    private static bool ValidateToggle()
    {
        foreach (var s in settings.iconSettings)
            Menu.SetChecked("Tools/ACM/ToggleActiveCheckboxInHierarchy/" + s.typeName, s.isVisible);
        return true;
    }

    // --- Always Show ---
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/MeshRenderer",        false, 40)]
    private static void AlwaysMeshRenderer()  => ToggleAlwaysShow("MeshRenderer");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/SkinnedMeshRenderer", false, 41)]
    private static void AlwaysSkinned()       => ToggleAlwaysShow("SkinnedMeshRenderer");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/MeshFilter",          false, 42)]
    private static void AlwaysMeshFilter()    => ToggleAlwaysShow("MeshFilter");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/Collider",            false, 43)]
    private static void AlwaysCollider()      => ToggleAlwaysShow("Collider");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/AudioSource",         false, 44)]
    private static void AlwaysAudioSource()   => ToggleAlwaysShow("AudioSource");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/AudioListener",       false, 45)]
    private static void AlwaysAudioListener() => ToggleAlwaysShow("AudioListener");
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/Camera",              false, 46)]
    private static void AlwaysCamera()        => ToggleAlwaysShow("Camera");

    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/MeshRenderer",        true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/SkinnedMeshRenderer", true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/MeshFilter",          true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/Collider",            true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/AudioSource",         true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/AudioListener",       true)]
    [MenuItem("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/Camera",              true)]
    private static bool ValidateAlwaysShow()
    {
        foreach (var s in settings.iconSettings)
            Menu.SetChecked("Tools/ACM/ToggleActiveCheckboxInHierarchy/Always Show/" + s.typeName, s.alwaysShow);
        return true;
    }

    private static void ToggleType(string typeName)
    {
        settings.SetIconVisibility(typeName, !settings.GetIconVisibility(typeName));
        ClearCache();
        EditorUtility.SetDirty(settings);
        EditorApplication.RepaintHierarchyWindow();
    }

    private static void ToggleAlwaysShow(string typeName)
    {
        settings.SetAlwaysShow(typeName, !settings.GetAlwaysShow(typeName));
        ClearCache();
        EditorUtility.SetDirty(settings);
        EditorApplication.RepaintHierarchyWindow();
    }

    private static void HierarchyItemOnGUI(int instanceID, Rect selectionRect)
    {
        GameObject obj = EditorUtility.InstanceIDToObject(instanceID) as GameObject;
        if (obj == null) return;

        const float iconSize = 14f;
        const float spacing = 4f;

        if (Event.current.type == EventType.MouseUp)
        {
            lastToggleObj = null;
            lastLockObj = null;
        }

        bool isHovered = settings.expandOnHover && selectionRect.Contains(Event.current.mousePosition);

        if (settings.showLockIcons)
        {
            if ((obj.hideFlags & HideFlags.NotEditable) != 0)
                EditorGUI.DrawRect(selectionRect, new Color(1f, 1f, 0.5f, 0.15f));

            Rect lockRect = new Rect(
                selectionRect.xMax - iconSize * 2 - spacing * 2 + 2f,
                selectionRect.y + (selectionRect.height - iconSize) / 2f,
                iconSize, iconSize
            );

            bool isLocked = (obj.hideFlags & HideFlags.NotEditable) != 0;
            Texture lockIcon = EditorGUIUtility.IconContent(isLocked ? "LockIcon-On" : "LockIcon").image;
            GUI.DrawTexture(lockRect, lockIcon, ScaleMode.ScaleToFit);

            if (isLocked)
                EditorGUI.DrawRect(lockRect, new Color(1f, 1f, 0.4f, 0.35f));

            if (Event.current.type == EventType.MouseDown && lockRect.Contains(Event.current.mousePosition))
            {
                obj.hideFlags ^= HideFlags.NotEditable;
                EditorUtility.SetDirty(obj);
                lastLockObj = obj;
                Event.current.Use();
            }
            else if (Event.current.type == EventType.MouseDrag && lastLockObj != null && obj != lastLockObj)
            {
                Rect mouseRect = new Rect(Event.current.mousePosition, Vector2.one);
                if (mouseRect.Overlaps(lockRect))
                {
                    bool shift = (Event.current.modifiers & EventModifiers.Shift) != 0;
                    bool ctrl = (Event.current.modifiers & EventModifiers.Control) != 0;
                    bool? newState = shift ? true : ctrl ? false : !(obj.hideFlags.HasFlag(HideFlags.NotEditable));

                    if (newState.HasValue)
                    {
                        if (newState.Value) obj.hideFlags |= HideFlags.NotEditable;
                        else obj.hideFlags &= ~HideFlags.NotEditable;
                        EditorUtility.SetDirty(obj);
                        EditorApplication.RepaintHierarchyWindow();
                    }
                    lastLockObj = obj;
                    Event.current.Use();
                }
            }

            if (settings.showComponentIcons)
            {
                Rect drawRect = new Rect(selectionRect);
                drawRect.xMax = lockRect.xMin - spacing + 2f;
                DrawComponentIcons(obj, ref drawRect, isHovered);
            }
        }
        else
        {
            if (settings.showComponentIcons)
            {
                Rect drawRect = new Rect(selectionRect);
                drawRect.xMax = selectionRect.xMax - iconSize - spacing * 2;
                DrawComponentIcons(obj, ref drawRect, isHovered);
            }
        }

        //チェックボックス
        Texture2D toggleIcon = obj.activeSelf ? activeIcon : inactiveIcon;
        Rect toggleRect = new Rect(
            selectionRect.xMax - iconSize - spacing,
            selectionRect.y + (selectionRect.height - iconSize) / 2f,
            iconSize, iconSize
        );

        if (Event.current.type == EventType.MouseDown && toggleRect.Contains(Event.current.mousePosition))
        {
            Undo.RecordObject(obj, "Toggle Active");
            obj.SetActive(!obj.activeSelf);
            lastToggleObj = obj;
            Event.current.Use();
        }

        if (Event.current.type == EventType.MouseDrag && lastToggleObj != null && obj != lastToggleObj)
        {
            Rect mouseRect = new Rect(Event.current.mousePosition, Vector2.one);
            if (mouseRect.Overlaps(toggleRect))
            {
                bool shift = (Event.current.modifiers & EventModifiers.Shift) != 0;
                bool ctrl = (Event.current.modifiers & EventModifiers.Control) != 0;
                bool? newState = shift ? true : ctrl ? false : !obj.activeSelf;

                if (newState.HasValue && obj.activeSelf != newState.Value)
                {
                    Undo.RecordObject(obj, "Drag Toggle Active");
                    obj.SetActive(newState.Value);
                    EditorApplication.RepaintHierarchyWindow();
                }
                lastToggleObj = obj;
                Event.current.Use();
            }
        }

        GUI.DrawTexture(toggleRect, toggleIcon, ScaleMode.ScaleToFit);
    }

    private static void DrawComponentIcons(GameObject obj, ref Rect drawRect, bool isHovered)
    {
        if (!settings.showComponentIcons || obj == null) return;

        int id = obj.GetInstanceID();
        if (!componentIconCache.TryGetValue(id, out var cached))
        {
            cached = BuildComponentIconCache(obj);
            componentIconCache[id] = cached;
        }
        if (cached.Length == 0) return;

        const float iconSize = 16f;
        const float spacing = 1f;
        const float separatorSpacing = 4f;
        const float separatorOffset = 1f;
        const float badgeWidth = 26f;

        // 表示するアイコンを決定
        bool limited = !isHovered && settings.maxIconCount > 0;
        List<CachedIcon> toShow;
        int overflowCount = 0;

        if (limited)
        {
            toShow = new List<CachedIcon>();
            int alwaysCount = 0;
            foreach (var c in cached)
                if (c.alwaysShow) alwaysCount++;

            int normalSlots = Mathf.Max(0, settings.maxIconCount - alwaysCount);
            int normalUsed = 0;

            foreach (var c in cached)
            {
                if (c.alwaysShow)
                    toShow.Add(c);
                else if (normalUsed < normalSlots)
                { toShow.Add(c); normalUsed++; }
                else
                    overflowCount++;
            }
        }
        else
        {
            toShow = new List<CachedIcon>(cached);
        }

        // +N バッジ座標を先に確保・保存（アイコン描画で xMax が動くため）
        Rect badgeRect = default;
        if (overflowCount > 0)
        {
            drawRect.xMax -= badgeWidth;
            badgeRect = new Rect(drawRect.xMax, drawRect.y, badgeWidth, drawRect.height);
        }

        bool separatorDrawn = false;

        foreach (var entry in toShow)
        {
            float displaySize = entry.isChild ? iconSize * 0.8f : iconSize;
            float offsetY = (drawRect.height - displaySize) / 2f;

            if (entry.isChild && !separatorDrawn)
            {
                float separatorX = drawRect.xMax - spacing / 2f - separatorOffset;
                Handles.BeginGUI();
                Handles.color = new Color(0.7f, 0.7f, 0.7f, 0.5f);
                Handles.DrawLine(
                    new Vector3(separatorX, drawRect.y),
                    new Vector3(separatorX, drawRect.y + drawRect.height)
                );
                Handles.EndGUI();
                drawRect.xMax -= separatorSpacing;
                separatorDrawn = true;
            }

            drawRect.xMax -= displaySize;
            Rect iconRect = new Rect(drawRect.xMax, drawRect.y + offsetY, displaySize, displaySize);
            GUI.DrawTexture(iconRect, entry.icon, ScaleMode.ScaleToFit);

            // enabled状態はキャッシュせず毎回チェック
            bool isInactive =
                !entry.component.gameObject.activeInHierarchy ||
                (entry.component is Behaviour b && !b.enabled) ||
                (entry.component is Collider c && !c.enabled) ||
                (entry.component is Renderer r && !r.enabled);

            if (isInactive)
            {
                Handles.BeginGUI();
                Handles.color = new Color(1f, 0f, 0f, 0.8f);
                Handles.DrawLine(
                    new Vector3(iconRect.xMin, iconRect.yMax),
                    new Vector3(iconRect.xMax, iconRect.yMin)
                );
                Handles.EndGUI();
                EditorGUI.DrawRect(iconRect, new Color(0f, 0f, 0f, 0.3f));
            }

            drawRect.xMax -= spacing;
        }

        // +N バッジ描画
        if (overflowCount > 0)
        {
            if (badgeStyle == null)
            {
                badgeStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    alignment = TextAnchor.MiddleCenter,
                    normal = { textColor = new Color(1f, 0.8f, 0.2f) }
                };
            }
            GUI.Label(badgeRect, $"+{overflowCount}", badgeStyle);
        }
    }

    private static CachedIcon[] BuildComponentIconCache(GameObject obj)
    {
        var allComponents = obj.GetComponentsInChildren<Component>(true);
        var ownIcons = new List<CachedIcon>();
        var childIcons = new List<CachedIcon>();
        var shownTypes = new HashSet<string>();
        var shownIcons = new HashSet<Texture>();

        foreach (var comp in allComponents)
        {
            if (comp == null || comp is Transform) continue;

            bool isChild = comp.gameObject != obj;
            string typeName = comp.GetType().Name;

            if (!settings.GetIconVisibility(typeName)) continue;
            if (shownTypes.Contains(typeName)) continue;
            shownTypes.Add(typeName);

            Texture icon = AssetPreview.GetMiniThumbnail(comp);
            if (icon == null) continue;
            if (shownIcons.Contains(icon)) continue;
            shownIcons.Add(icon);

            var entry = new CachedIcon
            {
                component = comp,
                icon = icon,
                isChild = isChild,
                alwaysShow = settings.GetAlwaysShow(typeName)
            };

            if (isChild) childIcons.Add(entry);
            else ownIcons.Add(entry);
        }

        // alwaysShow を先頭に並べる（own・child それぞれで）
        ownIcons.Sort((a, b) => b.alwaysShow.CompareTo(a.alwaysShow));
        childIcons.Sort((a, b) => b.alwaysShow.CompareTo(a.alwaysShow));

        var result = new List<CachedIcon>(ownIcons);
        result.AddRange(childIcons);
        return result.ToArray();
    }
}
