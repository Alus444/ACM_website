using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(fileName = "HierarchyToggleSettings", menuName = "ACM/Hierarchy Toggle Settings")]
public class HierarchyToggleSettings : ScriptableObject
{
    public bool isVisible = true;
    public bool showComponentIcons = true;
    public bool showLockIcons = true;
    public int maxIconCount = 5;
    public bool expandOnHover = true;

    [System.Serializable]
    public class IconSetting
    {
        public string typeName;
        public bool isVisible = true;
        public bool alwaysShow = false;
    }

    public List<IconSetting> iconSettings = new List<IconSetting>();

    public bool GetIconVisibility(string typeName)
    {
        var entry = iconSettings.Find(e => e.typeName == typeName);
        return entry == null || entry.isVisible;
    }

    public bool GetAlwaysShow(string typeName)
    {
        var entry = iconSettings.Find(e => e.typeName == typeName);
        return entry != null && entry.alwaysShow;
    }

    public void SetIconVisibility(string typeName, bool visible)
    {
        var entry = iconSettings.Find(e => e.typeName == typeName);
        if (entry == null)
            iconSettings.Add(new IconSetting { typeName = typeName, isVisible = visible });
        else
            entry.isVisible = visible;
    }

    public void SetAlwaysShow(string typeName, bool always)
    {
        var entry = iconSettings.Find(e => e.typeName == typeName);
        if (entry == null)
            iconSettings.Add(new IconSetting { typeName = typeName, isVisible = true, alwaysShow = always });
        else
            entry.alwaysShow = always;
    }
}
