# License

Copyright (c) 2026 ACM. All rights reserved.

This package may be installed and used by recipients who obtained it from an authorized ACM distribution channel. Redistribution, resale, sublicensing, or publication of this package or modified versions is not permitted without prior written permission from ACM.

Third-party software and assets, if any, remain subject to their respective licenses.
